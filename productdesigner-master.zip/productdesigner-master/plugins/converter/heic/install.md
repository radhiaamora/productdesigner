Download binary from `monostream/tifig` in github

Click on the releases tab and download the latest binary
 
Then place in `/usr/local/bin` or anywhere you want in the server

Give it execute permission (chmod) to all users 

`chmod +x /usr/local/bin/tifig`
