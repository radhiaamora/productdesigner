install inkscape on your server like so  

`sudo apt install inkscape`
