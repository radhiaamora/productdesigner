import { getProductLink } from "../../../support/functions";

describe("Product Options No Attributes", () => {

  before(() => {
    cy.task("db:seed", {spec: "no-attributes"});
    cy.visit(getProductLink("front"));
  });

  it("should not show attributes when product has no attributes", () => {
    cy.get(".dsn-product-attributes").should("not.exist");
  });
});
