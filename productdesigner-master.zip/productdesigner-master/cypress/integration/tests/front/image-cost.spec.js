import { getProductLink } from "../../../support/functions";

describe("Image cost", () => {

  before(() => {
    Cypress.Cookies.defaults({
      whitelist: /PrestaShop/
    });
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /module\/productdesigner\/imagegroup/).as("imagegroup");
    cy.route("POST", /module\/productdesigner\/userupload/).as("userupload");
    Cypress.on("uncaught:exception", (err, runnable) => {
      if (/ResizeObserver loop limit exceeded/.test(err)) {
        return false;
      }
    });
  });

  it("should calculate image cost by area", function () {
    cy.task("db:seed", {spec: "image-cost/image-cost-area"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-tab-image").click();
    cy.get(".dsn-image-group-item:eq(0)").click();
    cy.wait("@imagegroup");
    cy.get(".dsn-area-panel-content .dsn-image-item:eq(1)").click();
    cy.get(".dsn-pricing").contains("1.78");
  });

  it("should calculate upload cost by area", function () {
    cy.task("db:seed", {spec: "image-cost/image-cost-area"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-tab-image").click();
    cy.get(".dsn-user-upload-item:eq(0)").click();
    cy.wait("@userupload");
    cy.get(".dsn-area-panel-content .dsn-image-item:eq(0)").click();
    cy.get(".dsn-pricing").contains("0.9");
  });

  it("should calculate image cost directly", function () {
    cy.task("db:seed", {spec: "image-cost/image-cost"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-tab-image").click();
    cy.get(".dsn-image-group-item:eq(0)").click();
    cy.wait("@imagegroup");
    cy.get(".dsn-area-panel-content .dsn-image-item:eq(1)").click();
    cy.get(".dsn-pricing").contains("360");
  });

  it("should calculate upload cost directly", function () {
    cy.task("db:seed", {spec: "image-cost/image-cost"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-tab-image").click();
    cy.get(".dsn-user-upload-item:eq(0)").click();
    cy.wait("@userupload");
    cy.get(".dsn-area-panel-content .dsn-image-item:eq(0)").click();
    cy.get(".dsn-pricing").contains("240");
  });

});
