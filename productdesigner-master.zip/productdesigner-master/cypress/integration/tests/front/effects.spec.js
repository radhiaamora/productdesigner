import { getProductLink } from "../../../support/functions";

describe("Effects", () => {

  before(() => {
    cy.task("db:seed", {spec: "effects"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-container.booted");
  });

  it("should apply effects to images", function () {

    cy.get("#dsn-item-1").click()
    .get(`.dsn-image-brightness .dsn-brightness`).then((slider) => {
      expect(slider.slider("value")).to.equal(28);
    })
    .get(`.dsn-image-contrast .dsn-contrast`).then((slider) => {
      expect(slider.slider("value")).to.equal(55);
    })

    .get("#dsn-item-2").click()
    .get(`.dsn-image-brightness .dsn-brightness`).then((slider) => {
      expect(slider.slider("value")).to.equal(-27);
    })
    .get(`.dsn-image-contrast .dsn-contrast`).then((slider) => {
      expect(slider.slider("value")).to.equal(50);
    })

    .get("#dsn-item-1").within(() => {
      cy.get(".dsn-brightness").should("have.attr", "filter", "url(#brightness1)")
      .get(".dsn-contrast").should("have.attr", "filter", "url(#contrast1)")
      .get("#brightness1").within(() => {
        cy.get("feFuncR").should("have.attr", "slope", "1.28")
        .get("feFuncG").should("have.attr", "slope", "1.28")
        .get("feFuncB").should("have.attr", "slope", "1.28");
      })
      .get("#contrast1").within(() => {
        cy.get("feFuncR").should("have.attr", "slope", "1.55").should("have.attr", "intercept", "-0.275")
        .get("feFuncG").should("have.attr", "slope", "1.55").should("have.attr", "intercept", "-0.275")
        .get("feFuncB").should("have.attr", "slope", "1.55").should("have.attr", "intercept", "-0.275");
      });
    })

    .get("#dsn-item-2").within(() => {
      cy.get(".dsn-brightness").should("have.attr", "filter", "url(#brightness2)")
      .get(".dsn-contrast").should("have.attr", "filter", "url(#contrast2)")
      .get("#brightness2").within(() => {
        cy.get("feFuncR").should("have.attr", "slope", "0.73")
        .get("feFuncG").should("have.attr", "slope", "0.73")
        .get("feFuncB").should("have.attr", "slope", "0.73");
      })
      .get("#contrast2").within(() => {
        cy.get("feFuncR").should("have.attr", "slope", "1.5").should("have.attr", "intercept", "-0.25")
        .get("feFuncG").should("have.attr", "slope", "1.5").should("have.attr", "intercept", "-0.25")
        .get("feFuncB").should("have.attr", "slope", "1.5").should("have.attr", "intercept", "-0.25");
      });
    });
  });
});
