import { getProductLink } from "../../../support/functions";

describe("Popup", () => {

  it("should open popup on btn click", function () {
    cy.task("db:seed", {spec: "popup"});
    cy.visit(getProductLink("front-noscroll"));
    cy.get(".dsn-customize").click()
    .get("#dsn-popup").should("be.visible");
  });

  it("should open popup automatically", function () {
    cy.task("db:seed", {spec: "popup-auto"});
    cy.visit(getProductLink("front-noscroll"));
    cy.get("#dsn-popup").should("be.visible");
  });
});
