import { getProductLink } from "../../../support/functions";

describe("Item dimensions", () => {

  before(() => {
    cy.task("db:seed", {spec: "item-dimensions"});
    cy.visit(getProductLink("front"));
  });

  it("should display item dimensions", function () {
    cy.get(".dsn-design-area .dsn-dimension-width").should("contain", "10.0");
  });

  it("should display item dimensions after window resize", function () {
    cy.viewport(1199, 900);
    cy.get(".dsn-design-area .dsn-dimension-width").should("contain", "10.0");
  });

  it("should display item dimensions with product custom size", function () {
    cy.task("db:seed", {spec: "item-dimensions-with-product-size"});
    cy.visit(getProductLink("front"));
    cy.get(".dsn-design-area .dsn-dimension-width").should("contain", "10.0");
    cy.get("#dsn-tab-product").click();

    cy.get("#dsn-product-size-width").clear().type(20).blur();
    cy.get("#dsn-product-size-apply").click();
    cy.get(".dsn-design-area .dsn-dimension-width").should("contain", "20.0");

    cy.get("#dsn-product-size-width").clear().type(10).blur();
    cy.get("#dsn-product-size-apply").click();
    cy.get(".dsn-design-area .dsn-dimension-width").should("contain", "10.0");
  });
});
