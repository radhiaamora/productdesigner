import "cypress-wait-until";
import { getProductLink } from "../../../support/functions";

describe("Design Download", () => {

  before(() => {
    cy.task("db:seed", {spec: "download"});
    cy.visit(getProductLink("front"));
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /productdesigner\/designdownload/).as("download");
  });

  it("should show error when design is empty", () => {
    cy.get(`.dsn-product-color-list .dsn-color-item[data-id="-1"]`).click();
    cy.get("#dsn-download").click();
    cy.get(".dsn-area-error-message").should("be.visible");
  });

  it.skip("should download design", () => {
    cy.get("#dsn-tab-text").click();
    cy.get("#dsn-text-input").type("hello");
    cy.get("#dsn-text-add").click();
    cy.get("#dsn-download").click();

    const path = "~/Downloads/1-0.svg";
    cy.exec(`rm ${path}`, {failOnNonZeroExit: false});
    cy.wait("@download").its("responseBody").then((response) => {
      expect(response.download_link).to.not.be.empty;
      cy.waitUntil(() => cy.task("fileExists", path), {timeout: 20000});
    });
  });
});
