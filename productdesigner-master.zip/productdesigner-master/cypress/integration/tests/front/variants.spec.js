import { getProductLink } from "../../../support/functions";

describe("Product Options No Attributes", () => {

  before(() => {
    cy.task("db:seed", {spec: "variants"});
    cy.visit(getProductLink("front"));
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /index.php\?controller=product/).as("attribute");
  });

  it("should change module attribute", function () {
    cy.get(".product-information .product-actions select#group_1").select("M");
    cy.wait("@attribute");
    cy.get("#dsn-container select#group_1").should("have.value", "2");
  });

  it("should change product attribute", function () {
    cy.get("#dsn-container select#group_1").select("L");
    cy.wait("@attribute");
    cy.get(".product-actions select#group_1").should("have.value", "3");
  });
});
