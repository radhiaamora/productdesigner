import { getProductLink } from "../../../support/functions";

describe("Product Designer Text", () => {

  before(() => {
    cy.task("db:seed", {spec: "text"});
    cy.visit(getProductLink("front"));
  });

  it("should open text tab", () => {
    cy.get("#dsn-tabs").then((element) => {
      cy.waitForEventHandler(element, "click", ".dsn-tab");
    });
    cy.get("#dsn-tab-text").click();
    cy.get("#dsn-tab-content-text");
  });

  it("should show error when text is empty", () => {
    cy.get(".dsn-text-input").clear()
      .get("#dsn-text-add").click()
      .get(".dsn-area-error");
  });

  it("should add text", () => {
    cy.get(".dsn-text-input").type("hello")
      .get("#dsn-text-add").click()
      .get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").contains("hello");
    });
  });

  it("should change text", () => {
    cy.get(".dsn-text-input").type(" world!")
      .get("#dsn-text-apply").click()
      .get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").contains("hello world!");
    });
  });

  it("should change text dimensions", () => {
    cy.get(".dsn-canvas .dsn-item-text .dsn-dimensions").click({force: true});
    cy.get("#dsn-dimension-width").type("9").blur();
    cy.get("#dsn-dimension-height").should("have.value", "2.8");
    cy.get("#dsn-dimension-apply").click();
    cy.wait(100);
    cy.get(".dsn-canvas .dsn-item-text").should((text) => {
      expect(text.css("width")).to.not.equal("100%");
    });
    cy.get(".dsn-custom-dimension .dsn-slide-panel-close").click();
  });

  it("should have correct text color", () => {
    let currentColor = null;
    cy.get(".dsn-color-items .dsn-color-item.active").then((active) => {
      currentColor = active.data("color");
    });

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").should("have.attr", "fill", currentColor);
    });
  });

  it("should change text color", () => {
    cy.get("[data-slide='.dsn-text-color-list']:eq(0)").click();
    let currentColor = null;
    cy.get(".dsn-text-color-list .dsn-color-items .dsn-color-item:eq(1)").click().then((color) => {
      currentColor = color.data("color");
    });

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").should("have.attr", "fill", currentColor);
    });
  });

  it("should change text texture", () => {
    cy.get(".dsn-text-color-list .dsn-color-items .dsn-color-item:eq(4)").click();

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").should((element) => {
        const fill = element.get(0).getAttribute("fill");
        expect(fill).to.match(/^url/);
      });
    });
  });

  it("should change color using picker", () => {
    cy.get(".dsn-text-color-picker").click();
    cy.get(".cp-z-slider").click();
    cy.get(".cp-xy-slider").click();

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      // cy.get("text").should("have.attr", "fill", "#FEFCFC");
    });
    cy.get(".dsn-text-color-list .dsn-slide-panel-close").click({force: true});
  });

  it("should change font", () => {
    cy.get("[data-slide='.dsn-text-font-list']").click();

    let family = null;
    cy.get(".dsn-text-font-list .dsn-font-item:eq(1)").click().then((item) => {
      family = item.data("family");
    });

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").should("have.attr", "font-family", `'${family}'`);
    });

    cy.get(".dsn-text-font-list .dsn-slide-panel-close").click({force: true});
  });

  it("should change text style", () => {
    cy.get("[data-text-value='bold']").click();
    cy.get("[data-text-value='italic']").click();
    cy.get("[data-text-value='underline']").click();
    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text")
        .should("have.attr", "font-weight", "bold")
        .should("have.attr", "font-style", "italic")
        .should("have.attr", "text-decoration", "underline");
    });
  });

  it("should change transparency", () => {
    cy.get("#dsn-tab-content-text .dsn-transparency").then((slider) => {
      slider.slider("value", 53).slider("option", "stop").call(slider, null, {value: 53});
    });
    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").should("have.attr", "fill-opacity", "0.47");
    });
  });

  it("should change curvature", () => {
    cy.get("#dsn-tab-content-text .dsn-curvature").then((slider) => {
      slider.slider("value", 15).slider("option", "stop").call(slider, null, {value: 15});
    });

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("path");
      cy.get("text").find("textPath");
    });
  });

  it("should change outline", () => {
    cy.get(".dsn-outline-width-spinner .ui-spinner-up").click().click();

    cy.get(".dsn-canvas .dsn-item-text").within(() => {
      cy.get("text").should("have.attr", "stroke-width", "2px");
    });
  });

  it("should remove text", () => {
    cy.get(".dsn-canvas .dsn-item-text .dsn-item-remove").click({force: true});
    cy.get(".dsn-canvas .dsn-item-text").should("have.length", 0);
  });

  it("should grow input size when it changes", () => {
    const hello = "Hello";
    const helloWorld = "Hello\nworld!";

    cy.get(".dsn-text-input").clear().type(hello)
      .get("#dsn-text-add").click();

    cy.get(".dsn-text-input").clear().type(helloWorld)
      .get("#dsn-text-add").click();

    cy.get(".dsn-design-area .dsn-item-wrapper:eq(0)").click({force: true});
    cy.get(".dsn-text-input").should("have.value", hello).and("have.css", "height", "40px");;

    cy.get(".dsn-design-area .dsn-item-wrapper:eq(1)").click({force: true});
    cy.get(".dsn-text-input").should("have.value", helloWorld).and("have.css", "height", "60px");
  });
});
