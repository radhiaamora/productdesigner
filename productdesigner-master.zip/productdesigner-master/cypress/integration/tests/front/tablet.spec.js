import { getProductLink } from "../../../support/functions";

describe("Product Designer Mobile", () => {

  before(() => {
    cy.task("db:seed", {spec: "front"});
    cy.visit(getProductLink("front"));
  });

  beforeEach(() => {
    cy.viewport("ipad-2");
  });

  it("should display tabs initially", () => {
    cy.get("#dsn-tabs").should("be.visible");
  });
});
