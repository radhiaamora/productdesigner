import { getProductLink } from "../../../support/functions";

describe("Product Designer Image", () => {

  before(() => {
    cy.task("db:seed", {spec: "front-image"});
    cy.visit(getProductLink("front"));
  });

  it("should open images tab", () => {
    cy.get("#dsn-tabs").then((element) => {
      cy.waitForEventHandler(element, "click", ".dsn-tab");
    });
    cy.get("#dsn-tab-image").click();
    cy.get("#dsn-tab-content-image");
  });

  it("should open image group", () => {
    cy.get(".dsn-image-group-item:eq(0)").click()
      .get(".dsn-area-panel-content")
      .find(".dsn-image-item");
  });

  it("should add image to design", () => {
    cy.get(".dsn-image-group-item:eq(0)").click()
      .get(".dsn-area-panel-content")
      .find(".dsn-image-item:eq(0)").as("item").then((item) => {
      cy.waitForEventHandler(item, "click");
    });
    cy.get("@item").click();
    cy.get(".dsn-canvas .dsn-item-image");
  });

  it("should change transparency", () => {
    cy.get("#dsn-tab-content-image .dsn-transparency").then((slider) => {
      slider.slider("value", 53);
    });
    cy.get("#dsn-tab-content-image .dsn-transparency .ui-slider-handle").click();

    cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get(".dsn-design-image").should("have.css", "opacity", "0.47");
    });
  });

  it("should colorize image", () => {
    cy.get("[data-slide='.dsn-image-color-list']:eq(0)").click();

    cy.get(".dsn-image-color-list .dsn-color-items .dsn-color-item:eq(1)").click();

    cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get(".dsn-colorize").should("have.attr", "filter");
    });
  });

  it("should texturize image", () => {
    cy.get(".dsn-image-color-list .dsn-color-items .dsn-color-item:eq(5)").click();

    cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get(".dsn-texture").should((element) => {
        const filter = element.get(0).getAttribute("filter");
        expect(filter).to.match(/^url/);
      });
    });
  });

  it("should colorize image using color picker", () => {
    cy.get(".dsn-image-color-picker").click();
    cy.get(".cp-z-slider").click();
    cy.get(".cp-xy-slider").click();

    /*cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get("feComponentTransfer feFuncR").should("have.attr", "slope", "0.25098039215686274");
      cy.get("feComponentTransfer feFuncG").should("have.attr", "slope", "0.5019607843137255");
      cy.get("feComponentTransfer feFuncB").should("have.attr", "slope", "0.5019607843137255");
    });*/

    cy.get(".dsn-slide-panel-close:visible").click();
  });

  it("should remove image", () => {
    cy.get(".dsn-canvas .dsn-item-image .dsn-item-remove").click({force: true});
    cy.get(".dsn-canvas .dsn-item-image").should("have.length", 0);
  });

  it("should open my uploads", () => {
    cy.get(".dsn-user-upload-item").click();
    cy.get(".dsn-area-panel-content");
  });

});
