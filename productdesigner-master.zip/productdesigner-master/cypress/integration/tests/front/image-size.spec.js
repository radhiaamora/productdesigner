import { getProductLink } from "../../../support/functions";

describe("Image size", () => {

  before(() => {
    cy.task("db:seed", {spec: "image-size-cm"});
    cy.visit(getProductLink("front"));
  });

  it("should set initial image size", function () {
    cy.get("#dsn-tab-image").click();
    cy.get(".dsn-image-group-item:eq(0)").click();
    cy.get(".dsn-images-panel .dsn-image-item:eq(0)").click();
    cy.get(".dsn-canvas .dsn-item-wrapper:eq(0)").within(()=>{
      cy.get(".dsn-dimension-width").should("contain", "5.0");
      cy.get(".dsn-dimension-height").should("contain", "5.0");
    });
  });

  it("should add non fixed image normally", function () {
    cy.get(".dsn-image-group-item:eq(0)").click();
    cy.get(".dsn-images-panel .dsn-image-item:eq(1)").click();
    cy.get(".dsn-canvas .dsn-item-wrapper:eq(1)").within(()=>{
      cy.get(".dsn-dimension-width").should("contain", "10.0");
    });
  });

});
