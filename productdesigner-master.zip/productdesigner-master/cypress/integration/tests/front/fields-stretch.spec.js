import { getProductLink } from "../../../support/functions";

describe("Fields Stretch", () => {

  it("should not stretch image", function () {
    cy.task("db:seed", {spec: "fields/fields-no-stretch"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-container").should("be.visible");
    cy.get(".dsn-canvas .dsn-design-field").as('field').within((field) => {
      cy.get(".dsn-item-wrapper").then((wrapper)=>{
        let field_element = field.get(0);
        let wrapper_element = wrapper.get(0);
        expect(wrapper_element.offsetWidth).to.be.lte(field_element.offsetWidth);
        expect(wrapper_element.offsetHeight).to.be.lte(field_element.offsetHeight);
      });
    });
  });

  it("should stretch image", function () {
    cy.task("db:seed", {spec: "fields/fields-stretch"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-container").should("be.visible");
    cy.get(".dsn-canvas .dsn-design-field").as('field').within((field) => {
      cy.get(".dsn-item-wrapper").then((wrapper)=>{
        let field_element = field.get(0);
        let wrapper_element = wrapper.get(0);
        expect(wrapper_element.offsetWidth).to.be.gte(field_element.offsetWidth);
        expect(wrapper_element.offsetHeight).to.be.gte(field_element.offsetHeight);
      });
    });
  });
});
