import { getProductLink } from "../../../support/functions";

describe("Dynamic Size", () => {

  before(() => {
    cy.task("db:seed", {spec: "size"});
    cy.visit(getProductLink("front"));
    cy.get("#dsn-container.booted");
  });

  beforeEach(() => {
    cy.viewport(1350, 900);
  });

  const diff = (first, second) => {
    return Math.abs(first - second);
  };

  it("should display product size inputs", () => {
    cy.get("#dsn-product-size-width")
    .get("#dsn-product-size-height");
  });

  it("should change product size", () => {
    // prevent typing in disabled input
    cy.wait(1000);

    const dsn_area = Cypress.$("#dsn-area");
    const area_width = dsn_area.width();
    const area_height = dsn_area.height();

    cy.get("#dsn-product-size-aspect-button").click()
    .get("#dsn-product-size-width").clear().type(100)
    .get("#dsn-product-size-height").clear().type(50)
    .get("#dsn-product-size-apply").click()

    .get(".dsn-canvas-base-placeholder:eq(0)").then((placeholder) => {
      const width = placeholder.width();
      const height = placeholder.height();
      expect(diff(width, height * 2)).to.be.lte(1);
    })

    .get(".dsn-canvas-mask:eq(0)").then((placeholder) => {
      const width = placeholder.width();
      const height = placeholder.height();
      expect(diff(width, height * 2)).to.be.lte(1);
    });

    expect(dsn_area.width()).to.equal(area_width);
    expect(dsn_area.height()).to.equal(area_height);

    cy.get("#dsn-product-size-height").clear().type(100)
    .get("#dsn-product-size-apply").click()
    .get(".dsn-canvas-base-placeholder:eq(0)").then((placeholder) => {
      const width = placeholder.width();
      const height = placeholder.height();
      expect(width).to.equal(height);
    })
    .get(".dsn-canvas-mask:eq(0)").then((placeholder) => {
      const width = placeholder.width();
      const height = placeholder.height();
      expect(width).to.equal(height);
    });

    expect(dsn_area.width()).to.equal(area_width);
    expect(dsn_area.height()).to.equal(area_height);

    cy.get("#dsn-product-size-width").clear().type(50)
    .get("#dsn-product-size-apply").click()
    .get(".dsn-canvas-base-placeholder:eq(0)").then((placeholder) => {
      const width = placeholder.width();
      const height = placeholder.height();
      expect(diff(width, height / 2)).to.lte(1);
    })
    .get(".dsn-canvas-mask:eq(0)").then((placeholder) => {
      const width = placeholder.width();
      const height = placeholder.height();
      expect(diff(width, height / 2)).to.lte(1);
    });

    expect(dsn_area.width()).to.equal(area_width);
    expect(dsn_area.height()).to.equal(area_height);
  });
});
