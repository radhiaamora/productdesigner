import { getProductLink } from "../../../support/functions";

describe("Product Designer Mobile", () => {

  before(() => {
    cy.task("db:seed", {spec: "front"});
    cy.visit(getProductLink("front"));
  });

  beforeEach(() => {
    cy.viewport("iphone-6");
  });

  it("should display footer in one row", () => {
    cy.get("#dsn-footer").should((footer) => {
      expect(footer.outerHeight()).to.equal(41);
    });
  });
});
