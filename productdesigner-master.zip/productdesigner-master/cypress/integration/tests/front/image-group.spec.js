import { getProductLink } from "../../../support/functions";

describe("Product Designer Image", () => {

  before(() => {
    cy.task("db:seed", {spec: "front-image-group"});
    cy.visit(getProductLink("front"));
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /productdesigner\/imagegroup/)
      .as("imagegroup");
  });

  it("should open images tab", () => {
    cy.get("#dsn-tabs").then((element) => {
      cy.waitForEventHandler(element, "click", ".dsn-tab");
    });
    cy.get("#dsn-tab-image").click();
    cy.get("#dsn-tab-content-image");
  });

  it("should open image group", () => {
    let items_count = 0;
    cy.get(".dsn-image-group-item:eq(0)").click();
    cy.wait("@imagegroup");
    cy.get(".dsn-area-panel-content")
      .find(".dsn-image-item").then((items) => {
      items_count = items.length;
    });

    cy.get(".dsn-image-group-item:eq(1)").click();
    cy.wait("@imagegroup");
    cy.get(".dsn-area-panel-content")
      .find(".dsn-image-item").then((items) => {
      expect(items.length).to.not.equal(items_count);
    });

  });

});
