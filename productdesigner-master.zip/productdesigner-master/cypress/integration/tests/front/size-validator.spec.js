import { getProductLink } from "../../../support/functions";

describe("Size Validation", () => {

  let dsn_product_config;

  before(() => {
    cy.task("db:seed", {spec: "size"});
    cy.visit(getProductLink("front"));
    cy.window().then((win) => {
      dsn_product_config = win.dsn_product_config;
    });
    cy.get("#dsn-product-size-aspect-button").click();
  });

  beforeEach(() => {
    Cypress.$("#dsn-product-size-width").val(dsn_product_config.min_width);
    Cypress.$("#dsn-product-size-height").val(dsn_product_config.min_height);
  }),

    it("should validate min width", () => {
      cy.get("#dsn-product-size-width").clear().type(dsn_product_config.min_width - 1);
      cy.get("#dsn-product-size-apply").click();
      cy.get(".dsn-area-error-message")
        .should("be.visible")
        .contains("minimum")
        .contains("width");
    });

  it("should validate max width", () => {
    cy.get("#dsn-product-size-width").clear().type(dsn_product_config.max_width + 1);
    cy.get("#dsn-product-size-apply").click();
    cy.get(".dsn-area-error-message")
      .should("be.visible")
      .contains("maximum")
      .contains("width");
  });

  it("should validate min height", () => {
    cy.get("#dsn-product-size-height").clear().type(dsn_product_config.min_height - 1);
    cy.get("#dsn-product-size-apply").click();
    cy.get(".dsn-area-error-message")
      .should("be.visible")
      .contains("minimum")
      .contains("height");
  });

  it("should validate max height", () => {
    cy.get("#dsn-product-size-height").clear().type(dsn_product_config.max_height + 1);
    cy.get("#dsn-product-size-apply").click();
    cy.get(".dsn-area-error-message")
      .should("be.visible")
      .contains("maximum")
      .contains("height");
  });
});
