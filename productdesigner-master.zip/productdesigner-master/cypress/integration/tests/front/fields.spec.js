import { getProductLink } from "../../../support/functions";

describe("Product Fields", () => {

  before(() => {
    cy.task("db:seed", {spec: "fields"});
    cy.visit(getProductLink("front"));
  });

  it("should find interface", () => {
    cy.get("#dsn-container");
  });

  it("show a product field", () => {
    cy.get("#dsn-container .dsn-design-field");
  });

  it("should not deselect already selected item", function () {
    cy.get("#dsn-text-input").clear().type("123");
    cy.get("#dsn-text-add").click();
    cy.get("#dsn-text-input").clear().type("456");
    cy.get("#dsn-text-add").click();
    cy.get("#dsn-text-input").clear().type("789");
    cy.get("#dsn-text-add").click();

    console.log(Cypress.$(".dsn-design-field .dsn-item-wrapper"));
    cy.get(".dsn-design-field .dsn-item-wrapper").should("have.length", 3);
    cy.get(".dsn-design-field .dsn-item-wrapper:eq(1)").click({force: true});
    cy.get("#dsn-text-input").should("have.value", "456");
  });
});
