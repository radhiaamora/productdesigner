import { getProductLink } from "../../../support/functions";

describe("Product Fields", () => {

  before(() => {
    cy.task("db:seed", {spec: "oos"});
    cy.visit(getProductLink("front"));
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /controller=product/).as("product");
  });

  it("should show error when product is out of stock", () => {
    cy.get(`select[name="group[1]"]:eq(0)`).select("S");
    cy.wait("@product");
    cy.get("#dsn-cart-add").click();
    cy.get("#dsn-error-message").should("be.visible");
  });

  it("should not show error when product is available", () => {
    cy.visit(getProductLink("front"));
    cy.get(`select[name="group[1]"]:eq(0)`).select("M");
    cy.wait("@product");
    cy.get("#dsn-cart-add").click();
    cy.get("#dsn-error-message").should("not.be.visible");
  });
});
