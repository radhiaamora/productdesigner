import { getProductLink } from "../../../support/functions";

describe("Product Designer Interface", () => {

  before(() => {
    cy.task("db:seed", {spec: "front"});
    cy.visit(getProductLink("front"));
  });

  it("should find interface", () => {
    cy.get("#dsn-container");
  });

  it("interface should have less height than window", () => {
    cy.get("#dsn-container").should(($container) => {
      expect($container.height()).to.be.lessThan(Cypress.config("viewportHeight"));
    });
  });
});
