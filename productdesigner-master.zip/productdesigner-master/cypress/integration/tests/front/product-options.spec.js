import { getProductLink } from "../../../support/functions";

describe("Product Options", () => {

  before(() => {
    cy.task("db:seed", {spec: "common"});
    cy.task("db:seed", {spec: "product-options"});
    cy.visit(getProductLink("front"));
  });

  it("should open product options", () => {
    cy.get("#dsn-tab-product").click();
    cy.get("#dsn-tab-content-product");
  });

  it("should change product options", () => {
    cy.server();
    cy.route("POST", /controller=product.*?group\[\d+\]=\d+/).as("request");
    cy.get(".dsn-product-variants:eq(0) select:eq(0)").select("M");
    cy.get(".dsn-product-variants-loader:eq(0)");
    cy.wait("@request");
  });

  it("should colorize product", () => {
    cy.get(".dsn-product-color-list .dsn-color-items .dsn-color-item:eq(1)").click();

    cy.get(".dsn-canvas .dsn-canvas-base:eq(0) .dsn-colorize").should("have.attr", "filter");
    cy.get(".dsn-canvas .dsn-canvas-base:eq(0) .dsn-texture").should("not.have.attr", "filter");
  });

  it("should texturize product", () => {
    cy.get(".dsn-product-color-list .dsn-color-items .dsn-color-item:eq(5)").click();

    cy.get(".dsn-canvas .dsn-canvas-base:eq(0) .dsn-texture").should("have.attr", "filter");
    cy.get(".dsn-canvas .dsn-canvas-base:eq(0) .dsn-colorize").should("not.have.attr", "filter");
  });

  it("should colorize product using color picker", () => {
    cy.get(".dsn-product-color-picker").click();
    cy.get(".cp-z-slider").click();
    cy.get(".cp-xy-slider").click();
  });

  it("should restore original product color", () => {
    cy.get(".dsn-product-color-list .dsn-color-items .dsn-color-item:eq(0)").click({force: true});

    cy.get(".dsn-canvas .dsn-canvas-base:eq(0) .dsn-colorize").should("have.css", "filter", "none");
  });
});
