import { getProductLink } from "../../../support/functions";

describe("Image Filter", () => {

  before(() => {
    cy.task("db:seed", {spec: "image-filter"});
    cy.visit(getProductLink("front"));
  });

  it("should open images tab", () => {
    cy.get("#dsn-tabs").then((element) => {
      cy.waitForEventHandler(element, "click", ".dsn-tab");
    });
    cy.get("#dsn-tab-image").click();
    cy.get("#dsn-tab-content-image");
  });

  it("should change image filter", () => {

    const id_item = Cypress.$(".dsn-canvas .dsn-item-image").prop("id").replace("dsn-item-", "");

    cy.get("[data-slide='.dsn-image-filter-list']:eq(0)").click();

    cy.get(`.dsn-image-filter-list .dsn-filter-items .dsn-filter-item[data-name="grayscale"]`).click();
    cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get(".dsn-filterize").should("have.attr", "filter", `url(#grayscale${id_item})`);
    });

    cy.get(`.dsn-image-filter-list .dsn-filter-items .dsn-filter-item[data-name="sepia"]`).click();
    cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get(".dsn-filterize").should("have.attr", "filter", `url(#sepia${id_item})`);
    });

    cy.get(`.dsn-image-filter-list .dsn-filter-items .dsn-filter-item[data-name=""]`).click();
    cy.get(".dsn-canvas .dsn-item-image").within(() => {
      cy.get(".dsn-filterize").should("not.have.attr", "filter");
    });
  });
});
