import { getProductLink } from "../../../support/functions";

describe("Quick view", () => {

  before(() => {
    cy.task("db:seed", {spec: "front"});
    cy.visit(getProductLink("category"));
  });

  it("should visit product when customize button is clicked", () => {
    cy.get(`article[data-id-product="1"] a.quick-view`).click({force: true});
    cy.get("a.dsn-customize-quickview").click();
    cy.url()
      .should("include", "/1-")
      .and("include", "designer_scroll=1");
  });
});
