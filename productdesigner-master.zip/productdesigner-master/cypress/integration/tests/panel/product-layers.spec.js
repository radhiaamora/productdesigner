import { getProductLink } from "../../../support/functions";

describe("Product layers", () => {

  before(() => {
    cy.task("db:seed", {spec: "product-layers"});
    cy.visit(getProductLink("back"));
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /controller=DsnLayers/).as("controller");
  });

  it("should open product layers tab", () => {
    cy.get("a[href=\"#product_layers\"]").click();
    cy.wait("@controller");
  });

  it("should clean groups", () => {
    let selector = ".dsn-layer-groups:eq(0) .dsn-layer-group .dsn-layer-group-title a[title=Delete]";
    if (Cypress.$(selector).length) {
      cy.get(selector).click({force: true, multiple: true});
      cy.wait("@controller");
      cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group").should("have.length", 0);
    }
  });

  it("should add new group", () => {
    cy.get(".dsn-layer-groups:eq(0) button.mdl-button:eq(1)").click();
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer");
  });

  it("should add new layer", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layers button.mdl-button.dsn-add-layer").click();
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer").should("have.length", 2);
  });

  it("should collapse group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-group-title a.btn-red:first").click({force: true});
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0)").should("have.class", "group_folded");
  });

  it("should expand group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) a[title='Fold/Unfold']").click({force: true});
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0)").should("not.have.class", "group_folded");
  });

  it("should copy group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-group-title a[title=Copy]").click({force: true});
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group").should("have.length", 2);
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(1) .dsn-layer-group-title a[title=Delete]").click({force: true});
    cy.wait("@controller");
  });

  it("should disable group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-group-title a[title='Enable/Disable']").click({force: true});
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0)").should("not.have.class", "active");
  });

  it("should enable group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-group-title a[title='Enable/Disable']").click({force: true});
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0)").should("have.class", "active");
  });

  it("should edit group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-group-label").click();
    cy.get(".mdl-dialog.fixed").within(() => {
      cy.get(".dsn-field-label-container:eq(0) input").clear().type("My Group");
      cy.get(".dsn-field-label-container:eq(1) input").clear().type("Mon Groupe");
      cy.get("[id^=dsn-layer-group-required]").parent().click();
      cy.get("[id^=dsn-layer-group-active]").parent().click();
      cy.get(".mdl-dialog__actions button:eq(0)").click();
    });
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0)").should("not.have.class", "active")
      .within(() => {
        cy.get(".dsn-layer-group-label").contains("My Group");
        cy.get(".dsn-layer-group-label span.required");
      });
  });

  it("should edit layer", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-label:eq(0)").click();
    cy.get(".mdl-dialog.fixed").within(() => {
      cy.get(".dsn-field-label-container:eq(0) input").clear().type("My Layer");
      cy.get(".dsn-field-label-container:eq(1) input").clear().type("Mon Calque");
      cy.get("input[type=text].dsn-layer-price").clear().type("15.02");
      cy.get("[id^=dsn-layer-active]").parent().click();
      cy.get(".mdl-dialog__actions button:eq(0)").click();
    });
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer:eq(0)").should("not.have.class", "active")
      .within(() => {
        cy.get(".dsn-layer-label").contains("My Layer");
        cy.get(".dsn-layer-price").contains("15.02");
      });
  });

  it("should delete layer", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-title:eq(1) a.btn-red").click({force: true});
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer").should("have.length", 1);
  });

  it("should delete group", () => {
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group:eq(0) .dsn-layer-group-title a[title=Delete]").click({force: true});
    cy.wait("@controller");
    cy.get(".dsn-layer-groups:eq(0) .dsn-layer-group").should("have.length", 0);
  });
});
