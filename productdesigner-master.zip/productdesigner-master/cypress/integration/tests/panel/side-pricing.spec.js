import { getProductLink } from "../../../support/functions";

describe("Side pricing", () => {

  before(() => {
    cy.task("db:seed", {spec: "side-pricing"});
    cy.visit(getProductLink("back"));
  });

  it("should open side pricing tab", () => {
    cy.get("a[href=\"#side_pricing\"]").click();
  });

  it("should show two sides", () => {
    cy.get("side-pricing tbody tr").should("have.length", 2);
  });
});
