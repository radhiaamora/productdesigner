import "cypress-wait-until";
import { getProductLink } from "../../../support/functions";

describe("SVG Summary", () => {

  before(() => {
    cy.task("db:seed", {spec: "svg-summary"});
    cy.visit(getProductLink("order"));
  });

  it("should show svg preview", function () {
    cy.get(`a[data-cy="svg-preview"] img`).should((img) => {
      expect(img.prop("src")).to.match(/designer\/design_preview\/1-0.svg$/);
    });
  });

  it("should show svg download button", function () {
    cy.get(`a[data-cy=svg-download-btn]`);
  });

  it("should display customization summary", function () {
    cy.get(`div[data-cy="summary"]`)
      .get(`div[data-cy="summary-item"]`).should("have.length", 2);
  });

  it.skip("should display svg preview button", function () {
    const path = "~/Downloads/1_cde2e771aac4cb6b8587e3608472bb27.zip";
    cy.exec(`rm ${path}`, {failOnNonZeroExit: false});
    cy.get(`a[data-cy=svg-preview-btn]`).invoke("attr", "target", "").click()
    .get(".dsn-svg-preview")
    .get(`a[data-cy="svg-download-btn"]`).click();
    cy.waitUntil(() => cy.task("fileExists", path), {timeout: 20000});
  });
});
