import "cypress-wait-until";
import { getProductLink } from "../../../support/functions";

describe("Regenerators", () => {

  before(() => {
    cy.visit(getProductLink("config"));
  });

  it("should regenerate image group thumbnail", function () {
    const file = "designer/image_group/animals.png.thumb.png";
    cy.task("getPath", file).then((path) => {
      cy.exec(`rm ${path}`);
    }).get(`a[href="#image_groups"]`).click()
      .get(`a#desc-image_group-export`).click()
      .waitUntil(() => cy.task("fileExists", file), {timeout: 20000});
  });

});
