import { getProductLink } from "../../../support/functions";

describe("Config", () => {

  before(() => {
    cy.task("db:seed", {spec: "config"});
    cy.visit(getProductLink("config"));
  });

  beforeEach(() => {
    cy.server();
    cy.route("POST", /controller=DsnConfig/).as("DsnConfig");
  });

  it("should disable option", () => {
    if (+Cypress.$(`[name="config-display_base"]:checked`).val() === 1) {
      cy.get(`label[for="config-display_base_off"]`).click();
      cy.wait("@DsnConfig");
    }
    cy.visit(getProductLink("config"));
    cy.get(`[name="config-display_base"]:checked`).should("have.value", "0");
  });

  it("should enable option", () => {
    cy.get(`label[for="config-display_base_on"]`).click();
    cy.wait("@DsnConfig");
    cy.visit(getProductLink("config"));
    cy.get(`[name="config-display_base"]:checked`).should("have.value", "1");
  });

});
