import { getProductLink } from "../../../support/functions";

describe("Image group", () => {

  before(() => {
    cy.task("db:seed", {spec: "image-group"});
    cy.visit(getProductLink("config"));
  });

  it("should open image group tab", () => {
    cy.get(`a[href="#image_groups"]`).click();
    cy.get("table#table-image_group").should("be.visible");
    cy.get(`a[title="View"]:visible:eq(0)`).click();
    cy.get('table#table-image').should("be.visible");
  });
});
