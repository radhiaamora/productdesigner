import { getProductLink } from "../../../support/functions";

describe("Help", () => {

  before(() => {
    cy.task("db:seed", {spec: "help"});
  });

  beforeEach(() => {
    cy.visit(getProductLink("config"));
    cy.get(`a[href="#help_contents"]`).click();
  });

  it("should save image upload help", () => {
    const englishHelp = "English image upload help";
    const frenchHelp = "Aide upload image en Français";

    cy.window().as('window').then((win) => {
      cy.get('@window').its("tinyMCE.editors.image_upload_help_1.setContent").then(() => {
        win.tinyMCE.editors.image_upload_help_1.setContent(englishHelp);
      });
      cy.get('@window').its("tinyMCE.editors.image_upload_help_2.setContent").then(() => {
        win.tinyMCE.editors.image_upload_help_2.setContent(frenchHelp);
      });
      cy.get(`button[name="submithelp_content"]`).click();
    });

    cy.window().as('window').then((win) => {
      cy.get('@window').its("tinyMCE.editors.image_upload_help_1.getContent").then(() => {
        expect(win.tinyMCE.editors.image_upload_help_1.getContent()).to.equal(`<p>${englishHelp}</p>`);
      });
      cy.get('@window').its("tinyMCE.editors.image_upload_help_2.getContent").then(() => {
        expect(win.tinyMCE.editors.image_upload_help_2.getContent()).to.equal(`<p>${frenchHelp}</p>`);
      });
    });

    cy.visit(getProductLink("front"));
    cy.get("#dsn-tab-image").click();
    cy.get(`a[data-area-panel="#dsn-image-upload-help"]`).click();
    cy.get("#dsn-image-upload-help").should("be.visible").within(() => {
      cy.get(".dsn-area-panel-content").contains(englishHelp);
    });
  });

  it("should save text help", () => {
    const englishHelp = "English Text help";
    const frenchHelp = "Aide texte en Français";
    cy.get(`a[href="#help_contents"]`).click();

    cy.window().as('window').then((win) => {
      cy.get('@window').its("tinyMCE.editors.text_help_1.setContent").then(() => {
        win.tinyMCE.editors.text_help_1.setContent(englishHelp);
      });
      cy.get('@window').its("tinyMCE.editors.text_help_2.setContent").then(() => {
        win.tinyMCE.editors.text_help_2.setContent(frenchHelp);
      });
      cy.get(`button[name="submithelp_content"]`).click();
    });

    cy.window().as('window').then((win) => {
      cy.get('@window').its("tinyMCE.editors.text_help_1.getContent").then(() => {
        expect(win.tinyMCE.editors.text_help_1.getContent()).to.equal(`<p>${englishHelp}</p>`);
      });
      cy.get('@window').its("tinyMCE.editors.text_help_2.getContent").then(() => {
        expect(win.tinyMCE.editors.text_help_2.getContent()).to.equal(`<p>${frenchHelp}</p>`);
      });
    });

    cy.visit(getProductLink("front"));
    cy.get("#dsn-tab-text").click();
    cy.get(`a[data-area-panel="#dsn-text-help"]`).click();
    cy.get("#dsn-text-help").should("be.visible").within(() => {
      cy.get(".dsn-area-panel-content").contains(englishHelp);
    });
  });
});
