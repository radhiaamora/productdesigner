import { getProductLink } from "../../../support/functions";

describe("Image", () => {

  before(() => {
    cy.task("db:seed", {spec: "image"});
    cy.visit(getProductLink("config"));
  });

  it("should open image tab", () => {
    cy.get(`a[href="#images"]`).click();
    cy.get("table#table-image").should("be.visible");
  });

  it("should disable image", () => {
    cy.get("table#table-image").within(() => {
      cy.get("tbody tr:eq(0) a[title=\"Enabled\"]").click();
    });
    cy.get("table#table-image").within(() => {
      cy.get("tbody tr:eq(0) a[title=\"Disabled\"]").should("be.visible");
    });
  });

  it("should open edit image", () => {
    cy.get(`a[title="Edit"]:visible:eq(0)`).click();
    cy.get(`select[name="id_image_group"]`).should("be.visible");
    cy.get(`span.switch label[for="active_on"]`).click();
    cy.get(`button[name="submitimage"]`).click();
    cy.get("table#table-image").within(() => {
      cy.get("tbody tr:eq(0) a[title=\"Enabled\"]").should("be.visible");
    });
  });
});
