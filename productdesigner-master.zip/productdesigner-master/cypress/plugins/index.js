if (process.env.WATCH) {
  require("cypress-watch-and-reload/plugins");
}

const config = require("../../config");
const fs = require("fs");
const path = require("path");
const chalk = require("chalk");

const importSql = require("./importer");

module.exports = (on) => {
  on("task", {
    "db:seed": async ({spec}) => {
      console.log(chalk.green(`Seeding ${spec}`));
      await importSql(spec);
      return true;
    },

    "fileExists": (filePath) => {
      if (filePath[0] === "~") {
        filePath = path.join(process.env.HOME, filePath.slice(1));
      }
      let exists = fs.existsSync(filePath);

      if (!exists) {
        exists = fs.existsSync(path.join(config.e2e_dir, filePath));
      }

      return exists;
    },

    "getPath": (file) => {
      return path.join(config.e2e_dir, file);
    }
  });
};

