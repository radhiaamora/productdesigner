const node_ssh = require("node-ssh");
const config = require("../../config");

const ssh = new node_ssh();

function importSql(spec) {
  const sql_command = `mysql ${config.e2e_database} < ${config.ssh_root}${config.module_name}/modules/${config.module_name}/cypress/fixtures/mysql/${spec}.sql`;
  return new Promise((resolve, reject) => {
    const username = require("os").userInfo().username;
    ssh.connect({
      host: "dev.net",
      username: "root",
      privateKey: `/home/${username}/.ssh/id_rsa`,
    }).then(() => {
      ssh.execCommand(sql_command)
      .then((result) => {
        ssh.dispose();
        if (result.code === 0) {
          resolve(result.stdout);
        } else {
          reject(`code ${result.code}: ${result.stderr}`);
        }
      });
    });
  });
}

module.exports = importSql;
