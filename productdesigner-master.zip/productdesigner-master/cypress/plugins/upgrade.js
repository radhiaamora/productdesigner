const config = require("../../config");
const axios = require("./axios");
const chalk = require("chalk");

const upgradeUrl = `${config.e2e_url}/${config.module_name}/modules/${config.module_name}/cypress/support/upgrade.php`;
axios.get(upgradeUrl, {
  responseType: "json",
}).then((result) => {
  const response = result.data;
  if (+response.success) {
    console.info(chalk.greenBright("Upgrade Success!"));
  }
  console.log(chalk.greenBright(`(${module_name}) Upgraded: ${response.number_upgraded}/${response.available_upgrade} files`));
  console.log(chalk.blueBright(`(${module_name}) Failed: ${response.version_fail} versions`));
});
