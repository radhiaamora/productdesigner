const chalk = require('chalk');

const importSql = require("./importer");
const clearCache = require("./clear-cache");

const specs = [
  'common',
  'reset-module',
];

importSpecs(specs);

async function importSpecs(specs) {
  for (const spec of specs) {
    console.log(chalk.green(`Seeding ${spec}`));
    try {
      await importSql(spec);
    } catch(ex) {
      console.log(chalk.red(ex));
    }
  }
}

clearCache();
