const fs = require("fs");
const axios = require("axios");
const https = require("https");

const httpsAgent = new https.Agent({
  ca: fs.readFileSync("/mnt/y/sv/ssl/dev.net.crt", "utf-8"),
  cert: fs.readFileSync("/mnt/y/sv/ssl/dev.net.crt", "utf-8"),
  key: fs.readFileSync("/mnt/y/sv/ssl/dev.net.key", "utf-8"),
});

module.exports = axios.create({httpsAgent});
