const config = require("../../config");
const axios = require("./axios");
const chalk = require('chalk');

module.exports = function clearCache() {
  const scriptUrl = `${config.e2e_url}/${config.module_name}/modules/${config.module_name}/cypress/support/clear-cache.php`;
  axios.get(scriptUrl).then ((response) => {
    console.log(chalk.magentaBright(response.data));
  });
};
