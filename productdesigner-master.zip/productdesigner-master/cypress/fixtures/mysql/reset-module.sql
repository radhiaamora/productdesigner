-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 21, 2019 at 11:45 AM
-- Server version: 10.1.41-MariaDB-0ubuntu0.18.04.1
-- PHP Version: 7.2.22-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e2e_designer`
--

--
-- Truncate table before insert `ps_productdesigner_color`
--

TRUNCATE TABLE `ps_productdesigner_color`;
--
-- Dumping data for table `ps_productdesigner_color`
--

INSERT INTO `ps_productdesigner_color` (`id_color`, `color`, `file`, `active`, `position`) VALUES
(1, '#f44336', '', 1, 0),
(2, '#cddc39', '', 1, 1),
(3, '#28abe3', '', 1, 2),
(4, '#ffeb3b', '', 1, 3);

--
-- Truncate table before insert `ps_productdesigner_color_lang`
--

TRUNCATE TABLE `ps_productdesigner_color_lang`;
--
-- Dumping data for table `ps_productdesigner_color_lang`
--

INSERT INTO `ps_productdesigner_color_lang` (`id_color`, `id_lang`, `label`) VALUES
(1, 1, 'Red'),
(1, 2, 'Red'),
(1, 3, 'Red'),
(2, 1, 'Green'),
(2, 2, 'Green'),
(2, 3, 'Green'),
(3, 1, 'Blue'),
(3, 2, 'Blue'),
(3, 3, 'Blue'),
(4, 1, 'Yellow'),
(4, 2, 'Yellow'),
(4, 3, 'Yellow');

--
-- Truncate table before insert `ps_productdesigner_color_theme`
--

TRUNCATE TABLE `ps_productdesigner_color_theme`;
--
-- Dumping data for table `ps_productdesigner_color_theme`
--

INSERT INTO `ps_productdesigner_color_theme` (`id_color_theme`, `primary_color`, `secondary_color`, `primary_bg_color`, `secondary_bg_color`) VALUES
(1, '#2f83a8', '#85c347', '#363b3f', '#535e64');

--
-- Truncate table before insert `ps_productdesigner_config`
--

TRUNCATE TABLE `ps_productdesigner_config`;
--
-- Dumping data for table `ps_productdesigner_config`
--

INSERT INTO `ps_productdesigner_config` (`id_config`, `display_base`, `display_mask`, `display_layers`, `preview_in_invoice`, `preview_in_email`, `hide_cart_button`, `show_custom_btn`, `show_attributes_in_tabs`, `hide_size_input`, `hide_style_buttons`, `hide_alignment`, `hide_outline`, `show_in_popup`, `auto_show_popup`, `show_dimensions`, `show_download_btn`, `field_multiple_items`, `min_dpi`, `upload_maxsize`, `enable_all_tabs`, `initial_tab`) VALUES
(1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 72, 512000, 1, 0);

--
-- Truncate table before insert `ps_productdesigner_custom_field`
--

TRUNCATE TABLE `ps_productdesigner_custom_field`;
--
-- Truncate table before insert `ps_productdesigner_design`
--

TRUNCATE TABLE `ps_productdesigner_design`;
--
-- Truncate table before insert `ps_productdesigner_design_area`
--

TRUNCATE TABLE `ps_productdesigner_design_area`;
--
-- Truncate table before insert `ps_productdesigner_design_color`
--

TRUNCATE TABLE `ps_productdesigner_design_color`;
--
-- Truncate table before insert `ps_productdesigner_design_container`
--

TRUNCATE TABLE `ps_productdesigner_design_container`;
--
-- Truncate table before insert `ps_productdesigner_design_element`
--

TRUNCATE TABLE `ps_productdesigner_design_element`;
--
-- Truncate table before insert `ps_productdesigner_design_field`
--

TRUNCATE TABLE `ps_productdesigner_design_field`;
--
-- Truncate table before insert `ps_productdesigner_design_field_lang`
--

TRUNCATE TABLE `ps_productdesigner_design_field_lang`;
--
-- Truncate table before insert `ps_productdesigner_design_image`
--

TRUNCATE TABLE `ps_productdesigner_design_image`;
--
-- Truncate table before insert `ps_productdesigner_design_layer`
--

TRUNCATE TABLE `ps_productdesigner_design_layer`;
--
-- Truncate table before insert `ps_productdesigner_design_preview`
--

TRUNCATE TABLE `ps_productdesigner_design_preview`;
--
-- Truncate table before insert `ps_productdesigner_design_size`
--

TRUNCATE TABLE `ps_productdesigner_design_size`;
--
-- Truncate table before insert `ps_productdesigner_design_text`
--

TRUNCATE TABLE `ps_productdesigner_design_text`;
--
-- Truncate table before insert `ps_productdesigner_font`
--

TRUNCATE TABLE `ps_productdesigner_font`;
--
-- Dumping data for table `ps_productdesigner_font`
--

INSERT INTO `ps_productdesigner_font` (`id_font`, `name`, `family`, `file`, `active`, `position`) VALUES
(1, 'Milkshake', 'Milkshake', 'milkshake.ttf', 1, 0),
(2, 'Mountain', 'Fire on the Mountain', 'mountain.ttf', 1, 1),
(3, '28 Days Later', '28 Days Later', 'days.ttf', 1, 2);

--
-- Truncate table before insert `ps_productdesigner_help_content`
--

TRUNCATE TABLE `ps_productdesigner_help_content`;
--
-- Dumping data for table `ps_productdesigner_help_content`
--

INSERT INTO `ps_productdesigner_help_content` (`id_help_content`) VALUES
(1);

--
-- Truncate table before insert `ps_productdesigner_help_content_lang`
--

TRUNCATE TABLE `ps_productdesigner_help_content_lang`;
--
-- Dumping data for table `ps_productdesigner_help_content_lang`
--

INSERT INTO `ps_productdesigner_help_content_lang` (`id_help_content`, `id_lang`, `image_upload_help`, `text_help`) VALUES
(1, 1, '<p>English image upload help</p>', '<p>English Text help</p>'),
(1, 2, '<p>Aide upload image en Français</p>', '<p>Aide texte en Français</p>'),
(1, 3, '', '');

--
-- Truncate table before insert `ps_productdesigner_image`
--

TRUNCATE TABLE `ps_productdesigner_image`;
--
-- Dumping data for table `ps_productdesigner_image`
--

INSERT INTO `ps_productdesigner_image` (`id_image`, `id_image_group`, `file`, `price`, `active`, `position`) VALUES
(1, 1, 'dogs.svg', '100.000000', 1, 0),
(2, 1, 'cats.svg', '200.000000', 1, 1),
(3, 1, 'birds.svg', '300.000000', 1, 2),
(4, 1, 'reindeer.svg', '400.000000', 1, 3);

--
-- Truncate table before insert `ps_productdesigner_image_area_interval`
--

TRUNCATE TABLE `ps_productdesigner_image_area_interval`;
--
-- Truncate table before insert `ps_productdesigner_image_color`
--

TRUNCATE TABLE `ps_productdesigner_image_color`;
--
-- Truncate table before insert `ps_productdesigner_image_filter`
--

TRUNCATE TABLE `ps_productdesigner_image_filter`;
--
-- Truncate table before insert `ps_productdesigner_image_group`
--

TRUNCATE TABLE `ps_productdesigner_image_group`;
--
-- Dumping data for table `ps_productdesigner_image_group`
--

INSERT INTO `ps_productdesigner_image_group` (`id_image_group`, `file`, `active`, `is_white`, `position`) VALUES
(1, 'animals.png', 1, 0, 0);

--
-- Truncate table before insert `ps_productdesigner_image_group_lang`
--

TRUNCATE TABLE `ps_productdesigner_image_group_lang`;
--
-- Dumping data for table `ps_productdesigner_image_group_lang`
--

INSERT INTO `ps_productdesigner_image_group_lang` (`id_image_group`, `id_lang`, `label`) VALUES
(1, 1, 'Animals'),
(1, 2, 'Animals'),
(1, 3, 'Animals');

--
-- Truncate table before insert `ps_productdesigner_image_lang`
--

TRUNCATE TABLE `ps_productdesigner_image_lang`;
--
-- Dumping data for table `ps_productdesigner_image_lang`
--

INSERT INTO `ps_productdesigner_image_lang` (`id_image`, `id_lang`, `label`) VALUES
(1, 1, 'Dogs'),
(1, 2, 'Dogs'),
(1, 3, 'Dogs'),
(2, 1, 'Cats'),
(2, 2, 'Cats'),
(2, 3, 'Cats'),
(3, 1, 'Birds'),
(3, 2, 'Birds'),
(3, 3, 'Birds'),
(4, 1, 'Reindeer'),
(4, 2, 'Reindeer'),
(4, 3, 'Reindeer');

--
-- Truncate table before insert `ps_productdesigner_layer`
--

TRUNCATE TABLE `ps_productdesigner_layer`;
--
-- Truncate table before insert `ps_productdesigner_layer_group`
--

TRUNCATE TABLE `ps_productdesigner_layer_group`;
--
-- Truncate table before insert `ps_productdesigner_layer_group_lang`
--

TRUNCATE TABLE `ps_productdesigner_layer_group_lang`;
--
-- Truncate table before insert `ps_productdesigner_layer_image`
--

TRUNCATE TABLE `ps_productdesigner_layer_image`;
--
-- Truncate table before insert `ps_productdesigner_layer_lang`
--

TRUNCATE TABLE `ps_productdesigner_layer_lang`;
--
-- Truncate table before insert `ps_productdesigner_product_color`
--

TRUNCATE TABLE `ps_productdesigner_product_color`;
--
-- Truncate table before insert `ps_productdesigner_product_config`
--

TRUNCATE TABLE `ps_productdesigner_product_config`;
--
-- Truncate table before insert `ps_productdesigner_product_font`
--

TRUNCATE TABLE `ps_productdesigner_product_font`;
--
-- Truncate table before insert `ps_productdesigner_product_image`
--

TRUNCATE TABLE `ps_productdesigner_product_image`;
--
-- Truncate table before insert `ps_productdesigner_product_image_group`
--

TRUNCATE TABLE `ps_productdesigner_product_image_group`;
--
-- Truncate table before insert `ps_productdesigner_product_pricing`
--

TRUNCATE TABLE `ps_productdesigner_product_pricing`;
--
-- Truncate table before insert `ps_productdesigner_product_side`
--

TRUNCATE TABLE `ps_productdesigner_product_side`;
--
-- Truncate table before insert `ps_productdesigner_product_tab`
--

TRUNCATE TABLE `ps_productdesigner_product_tab`;
--
-- Truncate table before insert `ps_productdesigner_real_size`
--

TRUNCATE TABLE `ps_productdesigner_real_size`;
--
-- Truncate table before insert `ps_productdesigner_side`
--

TRUNCATE TABLE `ps_productdesigner_side`;
--
-- Dumping data for table `ps_productdesigner_side`
--

INSERT INTO `ps_productdesigner_side` (`id_side`, `name`, `active`, `position`) VALUES
(1, 'front', 1, 0),
(2, 'back', 1, 1);

--
-- Truncate table before insert `ps_productdesigner_side_combination`
--

TRUNCATE TABLE `ps_productdesigner_side_combination`;
--
-- Truncate table before insert `ps_productdesigner_side_combination_item`
--

TRUNCATE TABLE `ps_productdesigner_side_combination_item`;
--
-- Truncate table before insert `ps_productdesigner_side_lang`
--

TRUNCATE TABLE `ps_productdesigner_side_lang`;
--
-- Dumping data for table `ps_productdesigner_side_lang`
--

INSERT INTO `ps_productdesigner_side_lang` (`id_side`, `id_lang`, `label`) VALUES
(1, 1, 'Front'),
(1, 2, 'Front'),
(1, 3, 'Front'),
(2, 1, 'Back'),
(2, 2, 'Back'),
(2, 3, 'Back');

--
-- Truncate table before insert `ps_productdesigner_side_pricing`
--

TRUNCATE TABLE `ps_productdesigner_side_pricing`;
--
-- Truncate table before insert `ps_productdesigner_text_area_interval`
--

TRUNCATE TABLE `ps_productdesigner_text_area_interval`;
--
-- Truncate table before insert `ps_productdesigner_text_color`
--

TRUNCATE TABLE `ps_productdesigner_text_color`;
--
-- Truncate table before insert `ps_productdesigner_user_upload`
--

TRUNCATE TABLE `ps_productdesigner_user_upload`;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
