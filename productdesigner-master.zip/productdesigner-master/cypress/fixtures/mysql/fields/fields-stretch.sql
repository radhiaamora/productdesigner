SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


TRUNCATE TABLE `ps_productdesigner_color`;
INSERT INTO `ps_productdesigner_color` (`id_color`, `color`, `file`, `active`, `position`) VALUES
(1, '#f44336', '', 1, 0),
(2, '#cddc39', '', 1, 1),
(3, '#28abe3', '', 1, 2),
(4, '#ffeb3b', '', 1, 3);

TRUNCATE TABLE `ps_productdesigner_color_lang`;
INSERT INTO `ps_productdesigner_color_lang` (`id_color`, `id_lang`, `label`) VALUES
(1, 1, 'Red'),
(1, 2, 'Red'),
(1, 3, 'Red'),
(2, 1, 'Green'),
(2, 2, 'Green'),
(2, 3, 'Green'),
(3, 1, 'Blue'),
(3, 2, 'Blue'),
(3, 3, 'Blue'),
(4, 1, 'Yellow'),
(4, 2, 'Yellow'),
(4, 3, 'Yellow');

TRUNCATE TABLE `ps_productdesigner_color_theme`;
INSERT INTO `ps_productdesigner_color_theme` (`id_color_theme`, `primary_color`, `secondary_color`, `primary_bg_color`, `secondary_bg_color`) VALUES
(1, '#2f83a8', '#85c347', '#363b3f', '#535e64');

TRUNCATE TABLE `ps_productdesigner_config`;
INSERT INTO `ps_productdesigner_config` (`id_config`, `display_base`, `display_mask`, `display_layers`, `preview_in_invoice`, `preview_in_email`, `hide_cart_button`, `show_custom_btn`, `show_attributes_in_tabs`, `hide_size_input`, `hide_style_buttons`, `hide_alignment`, `hide_outline`, `show_in_popup`, `auto_show_popup`, `show_dimensions`, `show_download_btn`, `field_multiple_items`, `min_dpi`, `upload_maxsize`, `enable_all_tabs`, `initial_tab`, `block_min_dpi`, `enable_text_precision`) VALUES
(1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 72, 512000, 1, 0, 1, 0);

TRUNCATE TABLE `ps_productdesigner_custom_field`;
TRUNCATE TABLE `ps_productdesigner_design`;
INSERT INTO `ps_productdesigner_design` (`id_design`, `id_cart`, `id_product`, `id_product_attribute`, `id_customization`, `quantity`, `id_customer`, `id_guest`, `is_initial`) VALUES
(1, 0, 1, 1, 0, 1, 0, 0, 1);

TRUNCATE TABLE `ps_productdesigner_design_area`;
TRUNCATE TABLE `ps_productdesigner_design_color`;
INSERT INTO `ps_productdesigner_design_color` (`id_design_color`, `id_design`, `id_color`, `color`) VALUES
(1, 1, -1, '');

TRUNCATE TABLE `ps_productdesigner_design_container`;
INSERT INTO `ps_productdesigner_design_container` (`id_design_container`, `id_design`, `id_container`, `container_type`, `id_side`) VALUES
(1, 1, 1, 'field', 0);

TRUNCATE TABLE `ps_productdesigner_design_element`;
INSERT INTO `ps_productdesigner_design_element` (`id_design_element`, `id_design_container`, `category`, `id_side`) VALUES
(1, 1, 'image', 0);

TRUNCATE TABLE `ps_productdesigner_design_field`;
INSERT INTO `ps_productdesigner_design_field` (`id_design_field`, `id_product`, `id_side`, `x`, `y`, `width`, `height`, `is_text_field`, `is_static`, `is_limited`, `include_elements_cost`, `type`, `cost`, `stretch_image`) VALUES
(1, 1, 0, '1.000000', '1.000000', '25.000000', '12.500000', 0, 0, 1, 1, 0, '0.000000', 1);

TRUNCATE TABLE `ps_productdesigner_design_field_lang`;
INSERT INTO `ps_productdesigner_design_field_lang` (`id_design_field`, `id_lang`, `label`) VALUES
(1, 1, ''),
(1, 2, ''),
(1, 3, '');

TRUNCATE TABLE `ps_productdesigner_design_image`;
INSERT INTO `ps_productdesigner_design_image` (`id_design_image`, `id_design_item`, `id_image`, `upload`, `type`, `id_side`, `x`, `y`, `width`, `height`, `angle`, `transparency`, `id_color`, `color`, `filter`, `id_filter`, `filter_percent`, `svg_width`, `svg_height`) VALUES
(1, 1, 1, 0, 'svg', 0, '0.000000000000', '-64.062500000000', '100.508000000000', '228.283000000000', '0.000000000000', 0, 0, '', '', 0, 0, '262.801696777340', '302.265350341800');

TRUNCATE TABLE `ps_productdesigner_design_layer`;
TRUNCATE TABLE `ps_productdesigner_design_preview`;
TRUNCATE TABLE `ps_productdesigner_design_size`;
INSERT INTO `ps_productdesigner_design_size` (`id_design_size`, `id_design`, `width`, `height`) VALUES
(1, 1, '0.000000', '0.000000');

TRUNCATE TABLE `ps_productdesigner_design_text`;
TRUNCATE TABLE `ps_productdesigner_font`;
INSERT INTO `ps_productdesigner_font` (`id_font`, `name`, `family`, `file`, `active`, `position`) VALUES
(1, 'Milkshake', 'Milkshake', 'milkshake.ttf', 1, 0),
(2, 'Mountain', 'Fire on the Mountain', 'mountain.ttf', 1, 1),
(3, '28 Days Later', '28 Days Later', 'days.ttf', 1, 2);

TRUNCATE TABLE `ps_productdesigner_help_content`;
INSERT INTO `ps_productdesigner_help_content` (`id_help_content`) VALUES
(1);

TRUNCATE TABLE `ps_productdesigner_help_content_lang`;
INSERT INTO `ps_productdesigner_help_content_lang` (`id_help_content`, `id_lang`, `image_upload_help`, `text_help`) VALUES
(1, 1, '<p>English image upload help</p>', '<p>English Text help</p>'),
(1, 2, '<p>Aide upload image en Français</p>', '<p>Aide texte en Français</p>'),
(1, 3, '', '');

TRUNCATE TABLE `ps_productdesigner_image`;
INSERT INTO `ps_productdesigner_image` (`id_image`, `id_image_group`, `file`, `price`, `active`, `position`, `width`, `height`) VALUES
(1, 1, 'dogs.svg', '100.000000', 1, 0, '0.000000', '0.000000'),
(2, 1, 'cats.svg', '200.000000', 1, 1, '0.000000', '0.000000'),
(3, 1, 'birds.svg', '300.000000', 1, 2, '0.000000', '0.000000'),
(4, 1, 'reindeer.svg', '400.000000', 1, 3, '0.000000', '0.000000');

TRUNCATE TABLE `ps_productdesigner_image_area_interval`;
TRUNCATE TABLE `ps_productdesigner_image_color`;
TRUNCATE TABLE `ps_productdesigner_image_filter`;
TRUNCATE TABLE `ps_productdesigner_image_group`;
INSERT INTO `ps_productdesigner_image_group` (`id_image_group`, `file`, `active`, `is_white`, `position`) VALUES
    (1, 'animals.png', 1, 0, 0);

TRUNCATE TABLE `ps_productdesigner_image_group_lang`;
INSERT INTO `ps_productdesigner_image_group_lang` (`id_image_group`, `id_lang`, `label`)
VALUES (1, 1, 'Animals'),
       (1, 2, 'Animals'),
       (1, 3, 'Animals');

TRUNCATE TABLE `ps_productdesigner_image_lang`;
INSERT INTO `ps_productdesigner_image_lang` (`id_image`, `id_lang`, `label`)
VALUES (1, 1, 'Dogs'),
       (1, 2, 'Dogs'),
       (1, 3, 'Dogs'),
       (2, 1, 'Cats'),
       (2, 2, 'Cats'),
       (2, 3, 'Cats'),
       (3, 1, 'Birds'),
       (3, 2, 'Birds'),
       (3, 3, 'Birds'),
       (4, 1, 'Reindeer'),
       (4, 2, 'Reindeer'),
       (4, 3, 'Reindeer');

TRUNCATE TABLE `ps_productdesigner_layer`;
TRUNCATE TABLE `ps_productdesigner_layer_group`;
TRUNCATE TABLE `ps_productdesigner_layer_group_lang`;
TRUNCATE TABLE `ps_productdesigner_layer_image`;
TRUNCATE TABLE `ps_productdesigner_layer_lang`;
TRUNCATE TABLE `ps_productdesigner_product_color`;
TRUNCATE TABLE `ps_productdesigner_product_config`;
INSERT INTO `ps_productdesigner_product_config` (`id_product_config`, `id_product`, `active`, `required`,
                                                 `tabs_use_global_config`, `enable_all_tabs`, `initial_tab`,
                                                 `enable_all_text_colors`, `enable_all_image_colors`,
                                                 `enable_all_image_filters`, `enable_all_product_colors`,
                                                 `enable_all_fonts`, `enable_all_image_groups`, `small_image_groups`,
                                                 `enable_text_colorpickers`, `enable_text_transparency`,
                                                 `enable_text_curvature`, `text_maxlength`, `text_default_align`,
                                                 `enable_image_colors`, `enable_image_colorpickers`,
                                                 `enable_image_transparency`, `initial_image_color`,
                                                 `enable_image_filters`, `enable_product_colors`,
                                                 `enable_product_colorpickers`, `initial_product_color`, `allow_upload`,
                                                 `enable_design_fields`, `enable_layers`, `single_color`,
                                                 `enable_product_size`, `allow_change_product_size_aspect`,
                                                 `initial_width`, `initial_height`, `min_width`, `min_height`,
                                                 `max_width`, `max_height`, `min_text_size`, `min_image_size`,
                                                 `enable_resize_image`, `enable_drag_image`, `enable_resize_text`,
                                                 `enable_drag_text`)
VALUES (1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
        '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', 0, 0, 0, 0);

TRUNCATE TABLE `ps_productdesigner_product_font`;
TRUNCATE TABLE `ps_productdesigner_product_image`;
TRUNCATE TABLE `ps_productdesigner_product_image_group`;
TRUNCATE TABLE `ps_productdesigner_product_pricing`;
TRUNCATE TABLE `ps_productdesigner_product_side`;
TRUNCATE TABLE `ps_productdesigner_product_tab`;
TRUNCATE TABLE `ps_productdesigner_real_size`;
TRUNCATE TABLE `ps_productdesigner_side`;
INSERT INTO `ps_productdesigner_side` (`id_side`, `name`, `active`, `position`)
VALUES (1, 'front', 1, 0),
       (2, 'back', 1, 1);

TRUNCATE TABLE `ps_productdesigner_side_combination`;
TRUNCATE TABLE `ps_productdesigner_side_combination_item`;
TRUNCATE TABLE `ps_productdesigner_side_lang`;
INSERT INTO `ps_productdesigner_side_lang` (`id_side`, `id_lang`, `label`) VALUES
(1, 1, 'Front'),
(1, 2, 'Front'),
(1, 3, 'Front'),
(2, 1, 'Back'),
(2, 2, 'Back'),
(2, 3, 'Back');

TRUNCATE TABLE `ps_productdesigner_side_pricing`;
TRUNCATE TABLE `ps_productdesigner_text_area_interval`;
TRUNCATE TABLE `ps_productdesigner_text_color`;
TRUNCATE TABLE `ps_productdesigner_user_upload`;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
