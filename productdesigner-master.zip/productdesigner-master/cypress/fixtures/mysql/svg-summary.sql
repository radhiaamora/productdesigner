SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


TRUNCATE TABLE `ps_address`;
INSERT INTO `ps_address` (`id_address`, `id_country`, `id_state`, `id_customer`, `id_manufacturer`, `id_supplier`,
                          `id_warehouse`, `alias`, `company`, `lastname`, `firstname`, `address1`, `address2`,
                          `postcode`, `city`, `other`, `phone`, `phone_mobile`, `vat_number`, `dni`, `date_add`,
                          `date_upd`, `active`, `deleted`)
VALUES (1, 8, 0, 1, 0, 0, 0, 'My Address', '', 'Doe', 'John', 'Rue 1', '', '50000', 'Paris', '', '0451235566', '', '',
        '', '2020-01-14 12:45:11', '2020-01-14 12:45:11', 1, 0);

TRUNCATE TABLE `ps_cart`;
INSERT INTO `ps_cart` (`id_cart`, `id_shop_group`, `id_shop`, `id_carrier`, `delivery_option`, `id_lang`,
                       `id_address_delivery`, `id_address_invoice`, `id_currency`, `id_customer`, `id_guest`,
                       `secure_key`, `recyclable`, `gift`, `gift_message`, `mobile_theme`, `allow_seperated_package`,
                       `date_add`, `date_upd`, `checkout_session_data`)
VALUES (1, 1, 1, 1, '{\"1\":\"1,\"}', 1, 1, 1, 1, 1, 1, 'd2c078be7110c994b28ce38844aa6f73', 0, 0, '', 0, 0,
        '2020-01-14 12:44:43', '2020-01-14 12:45:13',
        '{\"checkout-personal-information-step\":{\"step_is_reachable\":true,\"step_is_complete\":true},\"checkout-addresses-step\":{\"step_is_reachable\":true,\"step_is_complete\":true,\"use_same_address\":true},\"checkout-delivery-step\":{\"step_is_reachable\":true,\"step_is_complete\":true},\"checkout-payment-step\":{\"step_is_reachable\":true,\"step_is_complete\":false},\"checksum\":\"53b5e70b18bb7935ae2640603572ee7029bb5f3f\"}');

TRUNCATE TABLE `ps_cart_product`;
INSERT INTO `ps_cart_product` (`id_cart`, `id_product`, `id_address_delivery`, `id_shop`, `id_product_attribute`,
                               `id_customization`, `quantity`, `date_add`)
VALUES (1, 1, 1, 1, 1, 1, 1, '2020-01-14 12:44:43');

TRUNCATE TABLE `ps_customer`;
INSERT INTO `ps_customer` (`id_customer`, `id_shop_group`, `id_shop`, `id_gender`, `id_default_group`, `id_lang`,
                           `id_risk`, `company`, `siret`, `ape`, `firstname`, `lastname`, `email`, `passwd`,
                           `last_passwd_gen`, `birthday`, `newsletter`, `ip_registration_newsletter`,
                           `newsletter_date_add`, `optin`, `website`, `outstanding_allow_amount`, `show_public_prices`,
                           `max_payment_days`, `secure_key`, `note`, `active`, `is_guest`, `deleted`, `date_add`,
                           `date_upd`, `reset_password_token`, `reset_password_validity`)
VALUES (1, 1, 1, 1, 3, 1, 0, '', '', '', 'Module', 'Test', 'amxmodx.unloco@gmail.com',
        '$2y$10$Bre/ecz4MG5q0BtNxZ.miObQZhtgACspbeftHLnIAaOCq4y98lTfG', '2020-01-14 06:45:04', '0000-00-00', 0, '',
        '0000-00-00 00:00:00', 0, '', '0.000000', 0, 0, 'd2c078be7110c994b28ce38844aa6f73', '', 1, 0, 0,
        '2020-01-14 12:45:04', '2020-01-14 12:45:04', '', '0000-00-00 00:00:00');

TRUNCATE TABLE `ps_customer_group`;
INSERT INTO `ps_customer_group` (`id_customer`, `id_group`)
VALUES (1, 3);

TRUNCATE TABLE `ps_customization`;
INSERT INTO `ps_customization` (`id_customization`, `id_product_attribute`, `id_address_delivery`, `id_cart`,
                                `id_product`, `quantity`, `quantity_refunded`, `quantity_returned`, `in_cart`)
VALUES (1, 1, 1, 1, 1, 1, 0, 0, 1);

TRUNCATE TABLE `ps_customization_field`;
INSERT INTO `ps_customization_field` (`id_customization_field`, `id_product`, `type`, `required`, `is_module`,
                                      `is_deleted`)
VALUES (1, 1, 1, 0, 1, 0);

TRUNCATE TABLE `ps_customization_field_lang`;
INSERT INTO `ps_customization_field_lang` (`id_customization_field`, `id_lang`, `id_shop`, `name`)
VALUES (1, 1, 1, 'Design'),
       (1, 2, 1, 'Design'),
       (1, 3, 1, 'Design');

TRUNCATE TABLE `ps_customized_data`;
INSERT INTO `ps_customized_data` (`id_customization`, `type`, `index`, `value`, `id_module`, `price`, `weight`)
VALUES (1, 1, 1, '1', 30, '0.422624', '0.000000');

TRUNCATE TABLE `ps_guest`;
TRUNCATE TABLE `ps_orders`;
INSERT INTO `ps_orders` (`id_order`, `reference`, `id_shop_group`, `id_shop`, `id_carrier`, `id_lang`, `id_customer`,
                         `id_cart`, `id_currency`, `id_address_delivery`, `id_address_invoice`, `current_state`,
                         `secure_key`, `payment`, `conversion_rate`, `module`, `recyclable`, `gift`, `gift_message`,
                         `mobile_theme`, `shipping_number`, `total_discounts`, `total_discounts_tax_incl`,
                         `total_discounts_tax_excl`, `total_paid`, `total_paid_tax_incl`, `total_paid_tax_excl`,
                         `total_paid_real`, `total_products`, `total_products_wt`, `total_shipping`,
                         `total_shipping_tax_incl`, `total_shipping_tax_excl`, `carrier_tax_rate`, `total_wrapping`,
                         `total_wrapping_tax_incl`, `total_wrapping_tax_excl`, `round_mode`, `round_type`,
                         `invoice_number`, `delivery_number`, `invoice_date`, `delivery_date`, `valid`, `date_add`,
                         `date_upd`)
VALUES (1, 'LXRBCMXXE', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 'd2c078be7110c994b28ce38844aa6f73', 'Payments by check',
        '1.000000', 'ps_checkpayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '0.510000', '0.510000',
        '0.420000', '0.000000', '0.420000', '0.510000', '0.000000', '0.000000', '0.000000', '20.000', '0.000000',
        '0.000000', '0.000000', 2, 2, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2020-01-14 12:45:16',
        '2020-01-14 12:45:16');

TRUNCATE TABLE `ps_order_carrier`;
INSERT INTO `ps_order_carrier` (`id_order_carrier`, `id_order`, `id_carrier`, `id_order_invoice`, `weight`,
                                `shipping_cost_tax_excl`, `shipping_cost_tax_incl`, `tracking_number`, `date_add`)
VALUES (1, 1, 1, 0, '0.000000', '0.000000', '0.000000', '', '2020-01-14 12:45:16');

TRUNCATE TABLE `ps_order_detail`;
INSERT INTO `ps_order_detail` (`id_order_detail`, `id_order`, `id_order_invoice`, `id_warehouse`, `id_shop`,
                               `product_id`, `product_attribute_id`, `id_customization`, `product_name`,
                               `product_quantity`, `product_quantity_in_stock`, `product_quantity_refunded`,
                               `product_quantity_return`, `product_quantity_reinjected`, `product_price`,
                               `reduction_percent`, `reduction_amount`, `reduction_amount_tax_incl`,
                               `reduction_amount_tax_excl`, `group_reduction`, `product_quantity_discount`,
                               `product_ean13`, `product_isbn`, `product_upc`, `product_reference`,
                               `product_supplier_reference`, `product_weight`, `id_tax_rules_group`,
                               `tax_computation_method`, `tax_name`, `tax_rate`, `ecotax`, `ecotax_tax_rate`,
                               `discount_quantity_applied`, `download_hash`, `download_nb`, `download_deadline`,
                               `total_price_tax_incl`, `total_price_tax_excl`, `unit_price_tax_incl`,
                               `unit_price_tax_excl`, `total_shipping_price_tax_incl`, `total_shipping_price_tax_excl`,
                               `purchase_supplier_price`, `original_product_price`, `original_wholesale_price`)
VALUES (1, 1, 0, 0, 1, 1, 1, 1, 'product designer - Size : S- Color : Red', 1, 1, 0, 0, 0, '0.000000', '0.00',
        '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', '', '0.000000', 1, 0, '', '0.000',
        '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '0.510000', '0.420000', '0.507149', '0.422624',
        '0.000000', '0.000000', '0.000000', '0.000000', '0.000000');

TRUNCATE TABLE `ps_order_detail_tax`;
INSERT INTO `ps_order_detail_tax` (`id_order_detail`, `id_tax`, `unit_amount`, `total_amount`)
VALUES (1, 1, '0.084525', '0.090000');

TRUNCATE TABLE `ps_productdesigner_color`;
INSERT INTO `ps_productdesigner_color` (`id_color`, `color`, `file`, `active`, `position`)
VALUES (1, '#f44336', '', 1, 0),
       (2, '#cddc39', '', 1, 1),
       (3, '#28abe3', '', 1, 2),
       (4, '#ffeb3b', '', 1, 3);

TRUNCATE TABLE `ps_productdesigner_color_lang`;
INSERT INTO `ps_productdesigner_color_lang` (`id_color`, `id_lang`, `label`)
VALUES (1, 1, 'Red'),
       (1, 2, 'Red'),
       (1, 3, 'Red'),
       (2, 1, 'Green'),
       (2, 2, 'Green'),
       (2, 3, 'Green'),
       (3, 1, 'Blue'),
       (3, 2, 'Blue'),
       (3, 3, 'Blue'),
       (4, 1, 'Yellow'),
       (4, 2, 'Yellow'),
       (4, 3, 'Yellow');

TRUNCATE TABLE `ps_productdesigner_color_theme`;
INSERT INTO `ps_productdesigner_color_theme` (`id_color_theme`, `primary_color`, `secondary_color`, `primary_bg_color`,
                                              `secondary_bg_color`)
VALUES (1, '#2f83a8', '#85c347', '#363b3f', '#535e64');

TRUNCATE TABLE `ps_productdesigner_config`;
INSERT INTO `ps_productdesigner_config` (`id_config`, `display_base`, `display_mask`, `display_layers`,
                                         `preview_in_invoice`, `preview_in_email`, `hide_cart_button`,
                                         `show_custom_btn`, `show_attributes_in_tabs`, `hide_size_input`,
                                         `hide_style_buttons`, `hide_alignment`, `hide_outline`, `show_in_popup`,
                                         `auto_show_popup`, `show_dimensions`, `show_download_btn`,
                                         `field_multiple_items`, `min_dpi`, `upload_maxsize`, `enable_all_tabs`,
                                         `initial_tab`, `block_min_dpi`, `enable_text_precision`)
VALUES (1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 72, 512000, 1, 0, 1, 0);

TRUNCATE TABLE `ps_productdesigner_custom_field`;
INSERT INTO `ps_productdesigner_custom_field` (`id_custom_field`, `id_product`, `id_customization_field`)
VALUES (1, 1, 1);

TRUNCATE TABLE `ps_productdesigner_design`;
INSERT INTO `ps_productdesigner_design` (`id_design`, `id_cart`, `id_product`, `id_product_attribute`,
                                         `id_customization`, `quantity`, `id_customer`, `id_guest`, `is_initial`)
VALUES (1, 1, 1, 1, 1, 1, 0, 1, 0);

TRUNCATE TABLE `ps_productdesigner_design_area`;
TRUNCATE TABLE `ps_productdesigner_design_color`;
INSERT INTO `ps_productdesigner_design_color` (`id_design_color`, `id_design`, `id_color`, `color`)
VALUES (1, 1, -1, '');

TRUNCATE TABLE `ps_productdesigner_design_container`;
INSERT INTO `ps_productdesigner_design_container` (`id_design_container`, `id_design`, `id_container`, `container_type`,
                                                   `id_side`)
VALUES (1, 1, 0, 'area', 0);

TRUNCATE TABLE `ps_productdesigner_design_element`;
INSERT INTO `ps_productdesigner_design_element` (`id_design_element`, `id_design_container`, `category`, `id_side`)
VALUES (1, 1, 'text', 0),
       (2, 1, 'image', 0);

TRUNCATE TABLE `ps_productdesigner_design_field`;
TRUNCATE TABLE `ps_productdesigner_design_field_lang`;
TRUNCATE TABLE `ps_productdesigner_design_image`;
INSERT INTO `ps_productdesigner_design_image` (`id_design_image`, `id_design_item`, `id_image`, `upload`, `type`,
                                               `id_side`, `x`, `y`, `width`, `height`, `angle`, `transparency`,
                                               `id_color`, `color`, `filter`, `id_filter`, `filter_percent`,
                                               `svg_width`, `svg_height`)
VALUES (1, 2, 3, 0, 'svg', 0, '33.018200000000', '51.772200000000', '35.443000000000', '39.746800000000',
        '0.000000000000', 0, 0, '', '', 0, 0, '270.153564453120', '302.412872314450');

TRUNCATE TABLE `ps_productdesigner_design_layer`;
TRUNCATE TABLE `ps_productdesigner_design_preview`;
INSERT INTO `ps_productdesigner_design_preview` (`id_design_preview`, `id_design`, `id_side`, `file`, `preview`,
                                                 `date_add`)
VALUES (1, 1, 0, '1-0.svg', '', '2020-01-14 12:44:43');

TRUNCATE TABLE `ps_productdesigner_design_size`;
INSERT INTO `ps_productdesigner_design_size` (`id_design_size`, `id_design`, `width`, `height`)
VALUES (1, 1, '0.000000', '0.000000');

TRUNCATE TABLE `ps_productdesigner_design_text`;
INSERT INTO `ps_productdesigner_design_text` (`id_design_text`, `id_design_item`, `type`, `id_side`, `x`, `y`, `width`,
                                              `height`, `angle`, `svg_x`, `svg_y`, `svg_width`, `svg_height`, `text_x`,
                                              `text_y`, `transparency`, `curvature`, `text`, `id_color`, `color`,
                                              `id_font`, `bold`, `italic`, `underline`, `align`, `id_outline_color`,
                                              `outline_color`, `outline_width`, `size`, `path`)
VALUES (1, 1, 'text', 0, '23.797500000000', '1.518990000000', '52.405100000000', '52.405100000000', '0.000000000000',
        '6.562500000000', '-319.440000000000', '453.421875000000', '452.880000000000', '-6.562500000000',
        '319.440000000000', 0, 0, '123', 1, '#f44336', 1, 0, 0, 0, 'center', 1, '#f44336', 0, 300, '');

TRUNCATE TABLE `ps_productdesigner_font`;
INSERT INTO `ps_productdesigner_font` (`id_font`, `name`, `family`, `file`, `active`, `position`)
VALUES (1, 'Milkshake', 'Milkshake', 'milkshake.ttf', 1, 0),
       (2, 'Mountain', 'Fire on the Mountain', 'mountain.ttf', 1, 1),
       (3, '28 Days Later', '28 Days Later', 'days.ttf', 1, 2);

TRUNCATE TABLE `ps_productdesigner_help_content`;
INSERT INTO `ps_productdesigner_help_content` (`id_help_content`)
VALUES (1);

TRUNCATE TABLE `ps_productdesigner_help_content_lang`;
INSERT INTO `ps_productdesigner_help_content_lang` (`id_help_content`, `id_lang`, `image_upload_help`, `text_help`)
VALUES (1, 1, '<p>English image upload help</p>', '<p>English Text help</p>'),
       (1, 2, '<p>Aide upload image en Français</p>', '<p>Aide texte en Français</p>'),
       (1, 3, '', '');

TRUNCATE TABLE `ps_productdesigner_image`;
INSERT INTO `ps_productdesigner_image` (`id_image`, `id_image_group`, `file`, `price`, `active`, `position`, `width`,
                                        `height`)
VALUES (1, 1, 'dogs.svg', '100.000000', 1, 0, '0.000000', '0.000000'),
       (2, 1, 'cats.svg', '200.000000', 1, 1, '0.000000', '0.000000'),
       (3, 1, 'birds.svg', '300.000000', 1, 2, '0.000000', '0.000000'),
       (4, 1, 'reindeer.svg', '400.000000', 1, 3, '0.000000', '0.000000');

TRUNCATE TABLE `ps_productdesigner_image_area_interval`;
TRUNCATE TABLE `ps_productdesigner_image_color`;
TRUNCATE TABLE `ps_productdesigner_image_filter`;
TRUNCATE TABLE `ps_productdesigner_image_group`;
INSERT INTO `ps_productdesigner_image_group` (`id_image_group`, `file`, `active`, `is_white`, `position`)
VALUES (1, 'animals.png', 1, 0, 0);

TRUNCATE TABLE `ps_productdesigner_image_group_lang`;
INSERT INTO `ps_productdesigner_image_group_lang` (`id_image_group`, `id_lang`, `label`)
VALUES (1, 1, 'Animals'),
       (1, 2, 'Animals'),
       (1, 3, 'Animals');

TRUNCATE TABLE `ps_productdesigner_image_lang`;
INSERT INTO `ps_productdesigner_image_lang` (`id_image`, `id_lang`, `label`)
VALUES (1, 1, 'Dogs'),
       (1, 2, 'Dogs'),
       (1, 3, 'Dogs'),
       (2, 1, 'Cats'),
       (2, 2, 'Cats'),
       (2, 3, 'Cats'),
       (3, 1, 'Birds'),
       (3, 2, 'Birds'),
       (3, 3, 'Birds'),
       (4, 1, 'Reindeer'),
       (4, 2, 'Reindeer'),
       (4, 3, 'Reindeer');

TRUNCATE TABLE `ps_productdesigner_layer`;
TRUNCATE TABLE `ps_productdesigner_layer_group`;
TRUNCATE TABLE `ps_productdesigner_layer_group_lang`;
TRUNCATE TABLE `ps_productdesigner_layer_image`;
TRUNCATE TABLE `ps_productdesigner_layer_lang`;
TRUNCATE TABLE `ps_productdesigner_product_color`;
TRUNCATE TABLE `ps_productdesigner_product_config`;
INSERT INTO `ps_productdesigner_product_config` (`id_product_config`, `id_product`, `active`, `required`,
                                                 `tabs_use_global_config`, `enable_all_tabs`, `initial_tab`,
                                                 `enable_all_text_colors`, `enable_all_image_colors`,
                                                 `enable_all_image_filters`, `enable_all_product_colors`,
                                                 `enable_all_fonts`, `enable_all_image_groups`, `small_image_groups`,
                                                 `enable_text_colorpickers`, `enable_text_transparency`,
                                                 `enable_text_curvature`, `text_maxlength`, `text_default_align`,
                                                 `enable_image_colors`, `enable_image_colorpickers`,
                                                 `enable_image_transparency`, `initial_image_color`,
                                                 `enable_image_filters`, `enable_product_colors`,
                                                 `enable_product_colorpickers`, `initial_product_color`, `allow_upload`,
                                                 `enable_design_fields`, `enable_layers`, `single_color`,
                                                 `enable_product_size`, `allow_change_product_size_aspect`,
                                                 `initial_width`, `initial_height`, `min_width`, `min_height`,
                                                 `max_width`, `max_height`, `min_text_size`,
                                                 `min_image_size`, `enable_resize_image`, `enable_drag_image`,
                                                 `enable_resize_text`, `enable_drag_text`)
VALUES (1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, NULL, '', 0, 0, 1, -1, 0, 0, 1, -1, 1, 0, 0, 0, 0, 1,
        '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', 1,
        1, 1, 1);

TRUNCATE TABLE `ps_productdesigner_product_font`;
TRUNCATE TABLE `ps_productdesigner_product_image`;
TRUNCATE TABLE `ps_productdesigner_product_image_group`;
TRUNCATE TABLE `ps_productdesigner_product_pricing`;
TRUNCATE TABLE `ps_productdesigner_product_side`;
TRUNCATE TABLE `ps_productdesigner_product_tab`;
TRUNCATE TABLE `ps_productdesigner_real_size`;
TRUNCATE TABLE `ps_productdesigner_side`;
INSERT INTO `ps_productdesigner_side` (`id_side`, `name`, `active`, `position`)
VALUES (1, 'front', 1, 0),
       (2, 'back', 1, 1);

TRUNCATE TABLE `ps_productdesigner_side_combination`;
TRUNCATE TABLE `ps_productdesigner_side_combination_item`;
TRUNCATE TABLE `ps_productdesigner_side_lang`;
INSERT INTO `ps_productdesigner_side_lang` (`id_side`, `id_lang`, `label`)
VALUES (1, 1, 'Front'),
       (1, 2, 'Front'),
       (1, 3, 'Front'),
       (2, 1, 'Back'),
       (2, 2, 'Back'),
       (2, 3, 'Back');

TRUNCATE TABLE `ps_productdesigner_side_pricing`;
TRUNCATE TABLE `ps_productdesigner_text_area_interval`;
TRUNCATE TABLE `ps_productdesigner_text_color`;
TRUNCATE TABLE `ps_productdesigner_user_upload`;
/*!40101 SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION */;
