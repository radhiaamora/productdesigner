SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


TRUNCATE TABLE `ps_accessory`;
TRUNCATE TABLE `ps_address`;
TRUNCATE TABLE `ps_alias`;
TRUNCATE TABLE `ps_attachment`;
TRUNCATE TABLE `ps_attachment_lang`;
TRUNCATE TABLE `ps_attribute`;
INSERT INTO `ps_attribute` VALUES
(1, 1, '', 0),
(2, 1, '', 1),
(3, 1, '', 2),
(4, 2, '#ff3c62', 0),
(5, 2, '#4c91ff', 1),
(6, 2, '#ffa22c', 2);

TRUNCATE TABLE `ps_attribute_group`;
INSERT INTO `ps_attribute_group` VALUES
(1, 0, 'select', 0),
(2, 1, 'color', 1);

TRUNCATE TABLE `ps_attribute_group_lang`;
INSERT INTO `ps_attribute_group_lang` VALUES
(1, 1, 'size', 'Size'),
(1, 2, 'size', 'Size'),
(1, 3, 'size', 'Size'),
(2, 1, 'color', 'Color'),
(2, 2, 'color', 'Color'),
(2, 3, 'color', 'Color');

TRUNCATE TABLE `ps_attribute_group_shop`;
INSERT INTO `ps_attribute_group_shop` VALUES
(1, 1),
(2, 1);

TRUNCATE TABLE `ps_attribute_impact`;
TRUNCATE TABLE `ps_attribute_lang`;
INSERT INTO `ps_attribute_lang` VALUES
(1, 1, 'S'),
(1, 2, 'S'),
(1, 3, 'S'),
(2, 1, 'M'),
(2, 2, 'M'),
(2, 3, 'M'),
(3, 1, 'L'),
(3, 2, 'L'),
(3, 3, 'L'),
(4, 1, 'Red'),
(4, 2, 'Red'),
(4, 3, 'Red'),
(5, 1, 'Blue'),
(5, 2, 'Blue'),
(5, 3, 'Blue'),
(6, 1, 'Orange'),
(6, 2, 'Orange'),
(6, 3, 'Orange');

TRUNCATE TABLE `ps_attribute_shop`;
INSERT INTO `ps_attribute_shop` VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1);

TRUNCATE TABLE `ps_cart`;
TRUNCATE TABLE `ps_cart_cart_rule`;
TRUNCATE TABLE `ps_cart_product`;
TRUNCATE TABLE `ps_cart_rule`;
TRUNCATE TABLE `ps_cart_rule_carrier`;
TRUNCATE TABLE `ps_cart_rule_combination`;
TRUNCATE TABLE `ps_cart_rule_country`;
TRUNCATE TABLE `ps_cart_rule_group`;
TRUNCATE TABLE `ps_cart_rule_lang`;
TRUNCATE TABLE `ps_cart_rule_product_rule`;
TRUNCATE TABLE `ps_cart_rule_product_rule_group`;
TRUNCATE TABLE `ps_cart_rule_product_rule_value`;
TRUNCATE TABLE `ps_cart_rule_shop`;

TRUNCATE TABLE `ps_category_product`;
INSERT INTO `ps_category_product` VALUES
(2, 1, 1);

TRUNCATE TABLE `ps_connections`;
TRUNCATE TABLE `ps_connections_page`;
TRUNCATE TABLE `ps_connections_source`;

TRUNCATE TABLE `ps_customer`;
TRUNCATE TABLE `ps_customer_group`;
TRUNCATE TABLE `ps_customer_message`;
TRUNCATE TABLE `ps_customer_message_sync_imap`;
TRUNCATE TABLE `ps_customer_thread`;
TRUNCATE TABLE `ps_customization`;
TRUNCATE TABLE `ps_customization_field`;
TRUNCATE TABLE `ps_customization_field_lang`;
TRUNCATE TABLE `ps_customized_data`;
TRUNCATE TABLE `ps_date_range`;
TRUNCATE TABLE `ps_delivery`;
TRUNCATE TABLE `ps_emailsubscription`;

TRUNCATE TABLE `ps_feature`;
TRUNCATE TABLE `ps_feature_lang`;
TRUNCATE TABLE `ps_feature_product`;
TRUNCATE TABLE `ps_feature_shop`;
TRUNCATE TABLE `ps_feature_value`;
TRUNCATE TABLE `ps_feature_value_lang`;

TRUNCATE TABLE `ps_guest`;

TRUNCATE TABLE `ps_image`;
INSERT INTO `ps_image` VALUES
(1, 1, 1, 1);

TRUNCATE TABLE `ps_image_lang`;
INSERT INTO `ps_image_lang` VALUES
(1, 1, ''),
(1, 2, ''),
(1, 3, '');

TRUNCATE TABLE `ps_image_shop`;
INSERT INTO `ps_image_shop` VALUES
(1, 1, 1, 1);

TRUNCATE TABLE `ps_import_match`;

TRUNCATE TABLE `ps_lang`;
INSERT INTO `ps_lang` VALUES
(1, 'English (English)', 1, 'en', 'en-us', 'en-US', 'm/d/Y', 'm/d/Y H:i:s', 0),
(2, 'Français (French)', 1, 'fr', 'fr', 'fr-FR', 'd/m/Y', 'd/m/Y H:i:s', 0),
(3, 'Español (Spanish)', 1, 'es', 'es-es', 'es-ES', 'Y-m-d', 'Y-m-d H:i:s', 0);

TRUNCATE TABLE `ps_lang_shop`;
INSERT INTO `ps_lang_shop` VALUES
(1, 1),
(2, 1),
(3, 1);

TRUNCATE TABLE `ps_layered_category`;
TRUNCATE TABLE `ps_layered_filter`;
TRUNCATE TABLE `ps_layered_filter_block`;
TRUNCATE TABLE `ps_layered_filter_shop`;
TRUNCATE TABLE `ps_layered_indexable_attribute_group`;
TRUNCATE TABLE `ps_layered_indexable_attribute_group_lang_value`;
TRUNCATE TABLE `ps_layered_indexable_attribute_lang_value`;
TRUNCATE TABLE `ps_layered_indexable_feature`;
TRUNCATE TABLE `ps_layered_indexable_feature_lang_value`;
TRUNCATE TABLE `ps_layered_indexable_feature_value_lang_value`;
TRUNCATE TABLE `ps_layered_price_index`;
INSERT INTO `ps_layered_price_index` VALUES
(1, 1, 1, '0.00000', '0.00000', 8);

TRUNCATE TABLE `ps_layered_product_attribute`;
INSERT INTO `ps_layered_product_attribute` VALUES
(1, 1, 1, 1),
(2, 1, 1, 1),
(3, 1, 1, 1),
(4, 1, 2, 1),
(5, 1, 2, 1),
(6, 1, 2, 1);

TRUNCATE TABLE `ps_mail`;
TRUNCATE TABLE `ps_manufacturer`;
TRUNCATE TABLE `ps_manufacturer_lang`;
TRUNCATE TABLE `ps_manufacturer_shop`;
TRUNCATE TABLE `ps_memcached_servers`;
TRUNCATE TABLE `ps_message`;
TRUNCATE TABLE `ps_message_readed`;

TRUNCATE TABLE `ps_orders`;
TRUNCATE TABLE `ps_order_carrier`;
TRUNCATE TABLE `ps_order_cart_rule`;
TRUNCATE TABLE `ps_order_detail`;
TRUNCATE TABLE `ps_order_detail_tax`;
TRUNCATE TABLE `ps_order_history`;
TRUNCATE TABLE `ps_order_invoice`;
TRUNCATE TABLE `ps_order_invoice_payment`;
TRUNCATE TABLE `ps_order_invoice_tax`;
TRUNCATE TABLE `ps_order_message`;
TRUNCATE TABLE `ps_order_message_lang`;
TRUNCATE TABLE `ps_order_payment`;
TRUNCATE TABLE `ps_order_return`;
TRUNCATE TABLE `ps_order_return_detail`;

TRUNCATE TABLE `ps_order_slip`;
TRUNCATE TABLE `ps_order_slip_detail`;
TRUNCATE TABLE `ps_order_slip_detail_tax`;

TRUNCATE TABLE `ps_pack`;
TRUNCATE TABLE `ps_page`;
TRUNCATE TABLE `ps_pagenotfound`;
TRUNCATE TABLE `ps_page_type`;
TRUNCATE TABLE `ps_page_viewed`;
TRUNCATE TABLE `ps_product`;
INSERT INTO `ps_product` VALUES
(1, 0, 0, 2, 1, 1, 0, 0, '', '', '', '0.000000', 0, 1, NULL, 0, '0.000000', '0.000000', '', '0.000000', '0.00', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 1, 0, 0, 0, 0, 1, '301-category', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 1, '2019-11-26 12:50:18', '2019-11-26 13:05:56', 0, 3, 1);

TRUNCATE TABLE `ps_productdesigner_color`;
INSERT INTO `ps_productdesigner_color` (`id_color`, `color`, `file`, `active`, `position`) VALUES
(1, '#f44336', '', 1, 0),
(2, '#cddc39', '', 1, 1),
(3, '#28abe3', '', 1, 2),
(4, '#ffeb3b', '', 1, 3);

TRUNCATE TABLE `ps_productdesigner_color_lang`;
INSERT INTO `ps_productdesigner_color_lang` (`id_color`, `id_lang`, `label`) VALUES
(1, 1, 'Red'),
(1, 2, 'Red'),
(1, 3, 'Red'),
(2, 1, 'Green'),
(2, 2, 'Green'),
(2, 3, 'Green'),
(3, 1, 'Blue'),
(3, 2, 'Blue'),
(3, 3, 'Blue'),
(4, 1, 'Yellow'),
(4, 2, 'Yellow'),
(4, 3, 'Yellow');

TRUNCATE TABLE `ps_productdesigner_color_theme`;
INSERT INTO `ps_productdesigner_color_theme` (`id_color_theme`, `primary_color`, `secondary_color`, `primary_bg_color`, `secondary_bg_color`) VALUES
(1, '#2f83a8', '#85c347', '#363b3f', '#535e64');

TRUNCATE TABLE `ps_productdesigner_config`;
TRUNCATE TABLE `ps_productdesigner_custom_field`;
TRUNCATE TABLE `ps_productdesigner_design`;
TRUNCATE TABLE `ps_productdesigner_design_area`;
TRUNCATE TABLE `ps_productdesigner_design_color`;
TRUNCATE TABLE `ps_productdesigner_design_container`;
TRUNCATE TABLE `ps_productdesigner_design_element`;
TRUNCATE TABLE `ps_productdesigner_design_field`;
TRUNCATE TABLE `ps_productdesigner_design_field_lang`;
TRUNCATE TABLE `ps_productdesigner_design_image`;
TRUNCATE TABLE `ps_productdesigner_design_layer`;
TRUNCATE TABLE `ps_productdesigner_design_preview`;
TRUNCATE TABLE `ps_productdesigner_design_size`;
TRUNCATE TABLE `ps_productdesigner_design_text`;
TRUNCATE TABLE `ps_productdesigner_font`;
INSERT INTO `ps_productdesigner_font` (`id_font`, `name`, `family`, `file`, `active`, `position`) VALUES
(1, 'Milkshake', 'Milkshake', 'milkshake.ttf', 1, 0),
(2, 'Mountain', 'Fire on the Mountain', 'mountain.ttf', 1, 1),
(3, '28 Days Later', '28 Days Later', 'days.ttf', 1, 2);

TRUNCATE TABLE `ps_productdesigner_help_content`;
INSERT INTO `ps_productdesigner_help_content` (`id_help_content`) VALUES
(1);

TRUNCATE TABLE `ps_productdesigner_help_content_lang`;
INSERT INTO `ps_productdesigner_help_content_lang` (`id_help_content`, `id_lang`, `image_upload_help`, `text_help`) VALUES
(1, 1, '<p>English image upload help</p>', '<p>English Text help</p>'),
(1, 2, '<p>Aide upload image en Français</p>', '<p>Aide texte en Français</p>'),
(1, 3, '', '');

TRUNCATE TABLE `ps_productdesigner_image`;
INSERT INTO `ps_productdesigner_image` (`id_image`, `id_image_group`, `file`, `price`, `active`, `position`) VALUES
(1, 1, 'dogs.svg', '100.000000', 1, 0),
(2, 1, 'cats.svg', '200.000000', 1, 1),
(3, 1, 'birds.svg', '300.000000', 1, 2),
(4, 1, 'reindeer.svg', '400.000000', 1, 3);

TRUNCATE TABLE `ps_productdesigner_image_area_interval`;
TRUNCATE TABLE `ps_productdesigner_image_color`;
TRUNCATE TABLE `ps_productdesigner_image_filter`;
TRUNCATE TABLE `ps_productdesigner_image_group`;
INSERT INTO `ps_productdesigner_image_group` (`id_image_group`, `file`, `active`, `is_white`, `position`) VALUES
(1, 'animals.png', 1, 0, 0);

TRUNCATE TABLE `ps_productdesigner_image_group_lang`;
INSERT INTO `ps_productdesigner_image_group_lang` (`id_image_group`, `id_lang`, `label`) VALUES
(1, 1, 'Animals'),
(1, 2, 'Animals'),
(1, 3, 'Animals');

TRUNCATE TABLE `ps_productdesigner_image_lang`;
INSERT INTO `ps_productdesigner_image_lang` (`id_image`, `id_lang`, `label`) VALUES
(1, 1, 'Dogs'),
(1, 2, 'Dogs'),
(1, 3, 'Dogs'),
(2, 1, 'Cats'),
(2, 2, 'Cats'),
(2, 3, 'Cats'),
(3, 1, 'Birds'),
(3, 2, 'Birds'),
(3, 3, 'Birds'),
(4, 1, 'Reindeer'),
(4, 2, 'Reindeer'),
(4, 3, 'Reindeer');

TRUNCATE TABLE `ps_productdesigner_layer`;
TRUNCATE TABLE `ps_productdesigner_layer_group`;
TRUNCATE TABLE `ps_productdesigner_layer_group_lang`;
TRUNCATE TABLE `ps_productdesigner_layer_image`;
TRUNCATE TABLE `ps_productdesigner_layer_lang`;
TRUNCATE TABLE `ps_productdesigner_product_color`;
TRUNCATE TABLE `ps_productdesigner_product_config`;
TRUNCATE TABLE `ps_productdesigner_product_font`;
TRUNCATE TABLE `ps_productdesigner_product_image`;
TRUNCATE TABLE `ps_productdesigner_product_image_group`;
TRUNCATE TABLE `ps_productdesigner_product_pricing`;
TRUNCATE TABLE `ps_productdesigner_product_side`;
TRUNCATE TABLE `ps_productdesigner_product_tab`;
TRUNCATE TABLE `ps_productdesigner_real_size`;
TRUNCATE TABLE `ps_productdesigner_side`;
INSERT INTO `ps_productdesigner_side` (`id_side`, `name`, `active`, `position`) VALUES
(1, 'front', 1, 0),
(2, 'back', 1, 1);

TRUNCATE TABLE `ps_productdesigner_side_combination`;
TRUNCATE TABLE `ps_productdesigner_side_combination_item`;
TRUNCATE TABLE `ps_productdesigner_side_lang`;
INSERT INTO `ps_productdesigner_side_lang` (`id_side`, `id_lang`, `label`) VALUES
(1, 1, 'Front'),
(1, 2, 'Front'),
(1, 3, 'Front'),
(2, 1, 'Back'),
(2, 2, 'Back'),
(2, 3, 'Back');

TRUNCATE TABLE `ps_productdesigner_side_pricing`;
TRUNCATE TABLE `ps_productdesigner_text_area_interval`;
TRUNCATE TABLE `ps_productdesigner_text_color`;
TRUNCATE TABLE `ps_productdesigner_user_upload`;

TRUNCATE TABLE `ps_product_attachment`;
TRUNCATE TABLE `ps_product_attribute`;
INSERT INTO `ps_product_attribute` VALUES
(1, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', 1, 1, NULL, 1, '0000-00-00'),
(2, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(3, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(4, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(5, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(6, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(7, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(8, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(9, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00');

TRUNCATE TABLE `ps_product_attribute_combination`;
INSERT INTO `ps_product_attribute_combination` VALUES
(1, 1),
(1, 4),
(1, 7),
(2, 2),
(2, 5),
(2, 8),
(3, 3),
(3, 6),
(3, 9),
(4, 1),
(4, 2),
(4, 3),
(5, 4),
(5, 5),
(5, 6),
(6, 7),
(6, 8),
(6, 9);

TRUNCATE TABLE `ps_product_attribute_image`;
TRUNCATE TABLE `ps_product_attribute_shop`;
INSERT INTO `ps_product_attribute_shop` VALUES
(1, 1, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 1, '0000-00-00'),
(1, 2, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 3, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 4, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 5, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 6, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 7, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 8, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 9, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00');

TRUNCATE TABLE `ps_product_carrier`;
TRUNCATE TABLE `ps_product_country_tax`;
TRUNCATE TABLE `ps_product_download`;
TRUNCATE TABLE `ps_product_group_reduction_cache`;
TRUNCATE TABLE `ps_product_lang`;
INSERT INTO `ps_product_lang` VALUES
(1, 1, 1, '', '', 'product-designer', '', '', '', 'product designer', '', '', '', ''),
(1, 1, 2, '', '', 'product-designer', '', '', '', 'product designer', '', '', '', ''),
(1, 1, 3, '', '', 'product-designer', '', '', '', 'product designer', '', '', '', '');

TRUNCATE TABLE `ps_product_sale`;
TRUNCATE TABLE `ps_product_shop`;
INSERT INTO `ps_product_shop` VALUES
(1, 1, 2, 1, 0, 0, '0.000000', 1, NULL, 0, '0.000000', '0.000000', '', '0.000000', '0.00', 0, 0, 0, 1, '301-category', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 1, 0, '2019-11-26 12:50:18', '2019-11-26 13:05:56', 3);

TRUNCATE TABLE `ps_product_supplier`;
TRUNCATE TABLE `ps_product_tag`;
TRUNCATE TABLE `ps_profile`;
INSERT INTO `ps_profile` VALUES
(1);

TRUNCATE TABLE `ps_range_price`;
TRUNCATE TABLE `ps_range_weight`;
TRUNCATE TABLE `ps_referrer`;
TRUNCATE TABLE `ps_referrer_cache`;
TRUNCATE TABLE `ps_referrer_shop`;
TRUNCATE TABLE `ps_request_sql`;
TRUNCATE TABLE `ps_required_field`;

TRUNCATE TABLE `ps_smarty_cache`;
TRUNCATE TABLE `ps_smarty_last_flush`;
TRUNCATE TABLE `ps_smarty_lazy_cache`;
TRUNCATE TABLE `ps_specific_price`;
TRUNCATE TABLE `ps_specific_price_priority`;
INSERT INTO `ps_specific_price_priority` VALUES
(1, 1, 'id_shop;id_currency;id_country;id_group');

TRUNCATE TABLE `ps_specific_price_rule`;
TRUNCATE TABLE `ps_specific_price_rule_condition`;
TRUNCATE TABLE `ps_specific_price_rule_condition_group`;

TRUNCATE TABLE `ps_stock`;
TRUNCATE TABLE `ps_stock_available`;
INSERT INTO `ps_stock_available` VALUES
(1, 1, 0, 1, 0, 90000, 0, 0, 0, 2, ''),
(2, 1, 1, 1, 0, 10000, 0, 0, 0, 2, ''),
(3, 1, 2, 1, 0, 10000, 0, 0, 0, 2, ''),
(4, 1, 3, 1, 0, 10000, 0, 0, 0, 2, ''),
(5, 1, 4, 1, 0, 10000, 0, 0, 0, 2, ''),
(6, 1, 5, 1, 0, 10000, 0, 0, 0, 2, ''),
(7, 1, 6, 1, 0, 10000, 0, 0, 0, 2, ''),
(8, 1, 7, 1, 0, 10000, 0, 0, 0, 2, ''),
(9, 1, 8, 1, 0, 10000, 0, 0, 0, 2, ''),
(10, 1, 9, 1, 0, 10000, 0, 0, 0, 2, '');

TRUNCATE TABLE `ps_store`;
TRUNCATE TABLE `ps_store_lang`;
TRUNCATE TABLE `ps_store_shop`;
TRUNCATE TABLE `ps_supplier`;
TRUNCATE TABLE `ps_supplier_lang`;
TRUNCATE TABLE `ps_supplier_shop`;
TRUNCATE TABLE `ps_supply_order`;
TRUNCATE TABLE `ps_supply_order_detail`;
TRUNCATE TABLE `ps_supply_order_history`;
TRUNCATE TABLE `ps_supply_order_receipt_history`;

TRUNCATE TABLE `ps_tab_module_preference`;
TRUNCATE TABLE `ps_tag`;
TRUNCATE TABLE `ps_tag_count`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
