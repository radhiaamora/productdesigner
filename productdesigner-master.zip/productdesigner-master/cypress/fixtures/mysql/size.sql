SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

TRUNCATE TABLE `ps_image`;
INSERT INTO `ps_image` (`id_image`, `id_product`, `position`, `cover`) VALUES
(2, 1, 1, 1);

TRUNCATE TABLE `ps_image_lang`;
INSERT INTO `ps_image_lang` (`id_image`, `id_lang`, `legend`) VALUES
(2, 1, ''),
(2, 2, ''),
(2, 3, '');

TRUNCATE TABLE `ps_image_shop`;
INSERT INTO `ps_image_shop` (`id_product`, `id_image`, `id_shop`, `cover`) VALUES
(1, 2, 1, 1);

TRUNCATE TABLE `ps_lang`;
INSERT INTO `ps_lang` (`id_lang`, `name`, `active`, `iso_code`, `language_code`, `locale`, `date_format_lite`, `date_format_full`, `is_rtl`) VALUES
(1, 'English (English)', 1, 'en', 'en-us', 'en-US', 'm/d/Y', 'm/d/Y H:i:s', 0),
(2, 'Français (French)', 1, 'fr', 'fr-fr', 'fr-FR', 'd/m/Y', 'd/m/Y H:i:s', 0),
(3, 'Español (Spanish)', 1, 'es', 'es-es', 'es-ES', 'd/m/Y', 'd/m/Y H:i:s', 0);

TRUNCATE TABLE `ps_lang_shop`;
INSERT INTO `ps_lang_shop` (`id_lang`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1);

TRUNCATE TABLE `ps_product`;
INSERT INTO `ps_product` (`id_product`, `id_supplier`, `id_manufacturer`, `id_category_default`, `id_shop_default`, `id_tax_rules_group`, `on_sale`, `online_only`, `ean13`, `isbn`, `upc`, `ecotax`, `quantity`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `price`, `wholesale_price`, `unity`, `unit_price_ratio`, `additional_shipping_cost`, `reference`, `supplier_reference`, `location`, `width`, `height`, `depth`, `weight`, `out_of_stock`, `additional_delivery_times`, `quantity_discount`, `customizable`, `uploadable_files`, `text_fields`, `active`, `redirect_type`, `id_type_redirected`, `available_for_order`, `available_date`, `show_condition`, `condition`, `show_price`, `indexed`, `visibility`, `cache_is_pack`, `cache_has_attachments`, `is_virtual`, `cache_default_attribute`, `date_add`, `date_upd`, `advanced_stock_management`, `pack_stock_type`, `state`) VALUES
(1, 0, 0, 2, 1, 1, 0, 0, '', '', '', '0.000000', 0, 1, NULL, 0, '0.000000', '0.000000', '', '0.000000', '0.00', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 1, 0, 1, 0, 1, 1, '301-category', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 1, '2019-11-21 12:01:00', '2019-11-21 13:39:35', 0, 3, 1);

TRUNCATE TABLE `ps_product_attribute`;
INSERT INTO `ps_product_attribute` (`id_product_attribute`, `id_product`, `reference`, `supplier_reference`, `location`, `ean13`, `isbn`, `upc`, `wholesale_price`, `price`, `ecotax`, `quantity`, `weight`, `unit_price_impact`, `default_on`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `available_date`) VALUES
(1, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', 1, 1, NULL, 1, '0000-00-00'),
(2, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(3, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(4, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(5, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(6, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(7, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(8, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(9, 1, '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 0, '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00');

TRUNCATE TABLE `ps_product_attribute_combination`;
INSERT INTO `ps_product_attribute_combination` (`id_attribute`, `id_product_attribute`) VALUES
(1, 1),
(1, 4),
(1, 7),
(2, 2),
(2, 5),
(2, 8),
(3, 3),
(3, 6),
(3, 9),
(13, 1),
(13, 2),
(13, 3),
(14, 4),
(14, 5),
(14, 6),
(15, 7),
(15, 8),
(15, 9);

TRUNCATE TABLE `ps_product_attribute_shop`;
INSERT INTO `ps_product_attribute_shop` (`id_product`, `id_product_attribute`, `id_shop`, `wholesale_price`, `price`, `ecotax`, `weight`, `unit_price_impact`, `default_on`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `available_date`) VALUES
(1, 1, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 1, '0000-00-00'),
(1, 2, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 3, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 4, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 5, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 6, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 7, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 8, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00'),
(1, 9, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 1, '0000-00-00');

TRUNCATE TABLE `ps_product_lang`;
INSERT INTO `ps_product_lang` (`id_product`, `id_shop`, `id_lang`, `description`, `description_short`, `link_rewrite`, `meta_description`, `meta_keywords`, `meta_title`, `name`, `available_now`, `available_later`, `delivery_in_stock`, `delivery_out_stock`) VALUES
(1, 1, 1, '', '', 'product-designer', '', '', '', 'product designer', '', '', '', ''),
(1, 1, 2, '', '', 'product-designer', '', '', '', 'product designer', '', '', '', ''),
(1, 1, 3, '', '', 'product-designer', '', '', '', 'product designer', '', '', '', '');

TRUNCATE TABLE `ps_stock_available`;
INSERT INTO `ps_stock_available` (`id_stock_available`, `id_product`, `id_product_attribute`, `id_shop`, `id_shop_group`, `quantity`, `physical_quantity`, `reserved_quantity`, `depends_on_stock`, `out_of_stock`, `location`) VALUES
(1, 1, 0, 1, 0, 9000, 0, 0, 0, 2, ''),
(2, 1, 1, 1, 0, 1000, 0, 0, 0, 2, ''),
(3, 1, 2, 1, 0, 1000, 0, 0, 0, 2, ''),
(4, 1, 3, 1, 0, 1000, 0, 0, 0, 2, ''),
(5, 1, 4, 1, 0, 1000, 0, 0, 0, 2, ''),
(6, 1, 5, 1, 0, 1000, 0, 0, 0, 2, ''),
(7, 1, 6, 1, 0, 1000, 0, 0, 0, 2, ''),
(8, 1, 7, 1, 0, 1000, 0, 0, 0, 2, ''),
(9, 1, 8, 1, 0, 1000, 0, 0, 0, 2, ''),
(10, 1, 9, 1, 0, 1000, 0, 0, 0, 2, '');

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


TRUNCATE TABLE `ps_productdesigner_color`;
INSERT INTO `ps_productdesigner_color` (`id_color`, `color`, `file`, `active`, `position`) VALUES
(1, '#f44336', '', 1, 0),
(2, '#cddc39', '', 1, 1),
(3, '#28abe3', '', 1, 2),
(4, '#ffeb3b', '', 1, 3);

TRUNCATE TABLE `ps_productdesigner_color_lang`;
INSERT INTO `ps_productdesigner_color_lang` (`id_color`, `id_lang`, `label`) VALUES
(1, 1, 'Red'),
(1, 2, 'Red'),
(1, 3, 'Red'),
(2, 1, 'Green'),
(2, 2, 'Green'),
(2, 3, 'Green'),
(3, 1, 'Blue'),
(3, 2, 'Blue'),
(3, 3, 'Blue'),
(4, 1, 'Yellow'),
(4, 2, 'Yellow'),
(4, 3, 'Yellow');

TRUNCATE TABLE `ps_productdesigner_color_theme`;
INSERT INTO `ps_productdesigner_color_theme` (`id_color_theme`, `primary_color`, `secondary_color`, `primary_bg_color`, `secondary_bg_color`) VALUES
(1, '#2f83a8', '#85c347', '#363b3f', '#535e64');

TRUNCATE TABLE `ps_productdesigner_config`;
INSERT INTO `ps_productdesigner_config` (`id_config`, `display_base`, `display_mask`, `display_layers`, `preview_in_invoice`, `preview_in_email`, `hide_cart_button`, `show_custom_btn`, `show_attributes_in_tabs`, `hide_size_input`, `hide_style_buttons`, `hide_alignment`, `hide_outline`, `show_in_popup`, `auto_show_popup`, `show_dimensions`, `show_download_btn`, `field_multiple_items`, `min_dpi`, `upload_maxsize`, `enable_all_tabs`, `initial_tab`) VALUES
(1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 72, 512000, 1, 0);

TRUNCATE TABLE `ps_productdesigner_custom_field`;
TRUNCATE TABLE `ps_productdesigner_design`;
TRUNCATE TABLE `ps_productdesigner_design_area`;
TRUNCATE TABLE `ps_productdesigner_design_color`;
TRUNCATE TABLE `ps_productdesigner_design_container`;
TRUNCATE TABLE `ps_productdesigner_design_element`;
TRUNCATE TABLE `ps_productdesigner_design_field`;
TRUNCATE TABLE `ps_productdesigner_design_field_lang`;
TRUNCATE TABLE `ps_productdesigner_design_image`;
TRUNCATE TABLE `ps_productdesigner_design_layer`;
TRUNCATE TABLE `ps_productdesigner_design_preview`;
TRUNCATE TABLE `ps_productdesigner_design_size`;
TRUNCATE TABLE `ps_productdesigner_design_text`;
TRUNCATE TABLE `ps_productdesigner_font`;
INSERT INTO `ps_productdesigner_font` (`id_font`, `name`, `family`, `file`, `active`, `position`) VALUES
(1, 'Milkshake', 'Milkshake', 'milkshake.ttf', 1, 0),
(2, 'Mountain', 'Fire on the Mountain', 'mountain.ttf', 1, 1),
(3, '28 Days Later', '28 Days Later', 'days.ttf', 1, 2);

TRUNCATE TABLE `ps_productdesigner_help_content`;
INSERT INTO `ps_productdesigner_help_content` (`id_help_content`) VALUES
(1);

TRUNCATE TABLE `ps_productdesigner_help_content_lang`;
INSERT INTO `ps_productdesigner_help_content_lang` (`id_help_content`, `id_lang`, `image_upload_help`, `text_help`) VALUES
(1, 1, '<p>English image upload help</p>', '<p>English Text help</p>'),
(1, 2, '<p>Aide upload image en Français</p>', '<p>Aide texte en Français</p>'),
(1, 3, '', '');

TRUNCATE TABLE `ps_productdesigner_image`;
INSERT INTO `ps_productdesigner_image` (`id_image`, `id_image_group`, `file`, `price`, `active`, `position`) VALUES
(1, 1, 'dogs.svg', '100.000000', 1, 0),
(2, 1, 'cats.svg', '200.000000', 1, 1),
(3, 1, 'birds.svg', '300.000000', 1, 2),
(4, 1, 'reindeer.svg', '400.000000', 1, 3);

TRUNCATE TABLE `ps_productdesigner_image_area_interval`;
TRUNCATE TABLE `ps_productdesigner_image_color`;
TRUNCATE TABLE `ps_productdesigner_image_filter`;
TRUNCATE TABLE `ps_productdesigner_image_group`;
INSERT INTO `ps_productdesigner_image_group` (`id_image_group`, `file`, `active`, `is_white`, `position`) VALUES
(1, 'animals.png', 1, 0, 0);

TRUNCATE TABLE `ps_productdesigner_image_group_lang`;
INSERT INTO `ps_productdesigner_image_group_lang` (`id_image_group`, `id_lang`, `label`) VALUES
(1, 1, 'Animals'),
(1, 2, 'Animals'),
(1, 3, 'Animals');

TRUNCATE TABLE `ps_productdesigner_image_lang`;
INSERT INTO `ps_productdesigner_image_lang` (`id_image`, `id_lang`, `label`) VALUES
(1, 1, 'Dogs'),
(1, 2, 'Dogs'),
(1, 3, 'Dogs'),
(2, 1, 'Cats'),
(2, 2, 'Cats'),
(2, 3, 'Cats'),
(3, 1, 'Birds'),
(3, 2, 'Birds'),
(3, 3, 'Birds'),
(4, 1, 'Reindeer'),
(4, 2, 'Reindeer'),
(4, 3, 'Reindeer');

TRUNCATE TABLE `ps_productdesigner_layer`;
TRUNCATE TABLE `ps_productdesigner_layer_group`;
TRUNCATE TABLE `ps_productdesigner_layer_group_lang`;
TRUNCATE TABLE `ps_productdesigner_layer_image`;
TRUNCATE TABLE `ps_productdesigner_layer_lang`;
TRUNCATE TABLE `ps_productdesigner_product_color`;
TRUNCATE TABLE `ps_productdesigner_product_config`;
INSERT INTO `ps_productdesigner_product_config` (`id_product_config`, `id_product`, `active`, `required`, `tabs_use_global_config`, `enable_all_tabs`, `initial_tab`, `enable_all_text_colors`, `enable_all_image_colors`, `enable_all_image_filters`, `enable_all_product_colors`, `enable_all_fonts`, `enable_all_image_groups`, `small_image_groups`, `enable_text_colorpickers`, `enable_text_transparency`, `enable_text_curvature`, `text_maxlength`, `text_default_align`, `enable_image_colors`, `enable_image_colorpickers`, `enable_image_transparency`, `initial_image_color`, `enable_image_filters`, `enable_product_colors`, `enable_product_colorpickers`, `initial_product_color`, `allow_upload`, `enable_design_fields`, `enable_layers`, `single_color`, `enable_product_size`, `allow_change_product_size_aspect`, `initial_width`, `initial_height`, `min_width`, `min_height`, `max_width`, `max_height`) VALUES
(1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, '10.000000', '5.000000', '1.000000', '1.000000', '100.000000', '100.000000');

TRUNCATE TABLE `ps_productdesigner_product_font`;
TRUNCATE TABLE `ps_productdesigner_product_image`;
INSERT INTO `ps_productdesigner_product_image` (`id_product_image`, `id_product`, `id_image`, `id_side`, `canvas`, `mask`, `canvas_width`, `canvas_height`, `date_upd`) VALUES
(1, 1, 2, 0, '1-canvas.jpg', '', 1000, 500, '2019-11-21 13:41:41');

TRUNCATE TABLE `ps_productdesigner_product_image_group`;
TRUNCATE TABLE `ps_productdesigner_product_pricing`;
INSERT INTO `ps_productdesigner_product_pricing` (`id_product_pricing`, `id_product`, `product_cost_per_area`, `text_cost_per_area`, `text_cost`, `text_character_cost`, `text_minimal_cost`, `texts_total_cost`, `image_cost_per_area`, `upload_cost_per_area`, `image_cost`, `image_minimal_cost`, `images_total_cost`) VALUES
(1, 1, '1000.000000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

TRUNCATE TABLE `ps_productdesigner_product_side`;
TRUNCATE TABLE `ps_productdesigner_product_tab`;
TRUNCATE TABLE `ps_productdesigner_real_size`;
TRUNCATE TABLE `ps_productdesigner_side`;
INSERT INTO `ps_productdesigner_side` (`id_side`, `name`, `active`, `position`) VALUES
(1, 'front', 1, 0),
(2, 'back', 1, 1);

TRUNCATE TABLE `ps_productdesigner_side_combination`;
TRUNCATE TABLE `ps_productdesigner_side_combination_item`;
TRUNCATE TABLE `ps_productdesigner_side_lang`;
INSERT INTO `ps_productdesigner_side_lang` (`id_side`, `id_lang`, `label`) VALUES
(1, 1, 'Front'),
(1, 2, 'Front'),
(1, 3, 'Front'),
(2, 1, 'Back'),
(2, 2, 'Back'),
(2, 3, 'Back');

TRUNCATE TABLE `ps_productdesigner_side_pricing`;
TRUNCATE TABLE `ps_productdesigner_text_area_interval`;
TRUNCATE TABLE `ps_productdesigner_text_color`;
TRUNCATE TABLE `ps_productdesigner_user_upload`;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
