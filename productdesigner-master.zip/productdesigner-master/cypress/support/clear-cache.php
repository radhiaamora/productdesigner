<?php

/** @noinspection PhpIncludeInspection */
require dirname(__FILE__, 5).'/config/config.inc.php';

Tools::clearSmartyCache();
Tools::clearXMLCache();
Media::clearCache();
Tools::generateIndex();

exit('Cleared cache');
