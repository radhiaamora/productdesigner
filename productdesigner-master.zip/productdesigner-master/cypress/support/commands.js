/// <reference types="Cypress" />

// add new command to the existing Cypress interface
import { waitForEventHandler } from "./functions";

Cypress.Commands.add("waitForEventHandler", waitForEventHandler);
