export async function getProductLink (context = "admin") {
  // @ts-ignore
  return Cypress.config("links")[context];
}

export function waitForEventHandler (element, type, selector) {
  return new Cypress.Promise((resolve, reject) => {
    // tiemout of 5000ms
    let timedout = false;
    setTimeout(() => {
      timedout = true;
    }, 5000);

    const elem = element.get(0);
    const win = elem.ownerDocument.defaultView;
    const checkEvent = () => {
      if (typeof win.$ === "function") {
        const events = win.$._data(elem, "events");
        if (events) {
          const event_list = events[type];
          if (event_list) {
            for (const event of event_list) {
              if (event.selector === selector) {
                resolve();
                return;
              }
            }
          }
        }
      }
      if (!timedout) {
        setTimeout(checkEvent, 0);
      } else {
        reject(
          `Timed out after 5000 ms. ${ type } event handler not found ${ selector ? `for selector ${ selector }` : "" }`
        );
      }
    };
    checkEvent();
  });
}
