<?php

require dirname(__FILE__, 5).'/config/config.inc.php';
$module_name = 'productdesigner';
$module = Module::getInstanceByName($module_name);
$module->installed = true;
$module->database_version = Db::getInstance()->getValue("SELECT version FROM ps_module WHERE name=\"$module_name\"");
Module::initUpgradeModule($module);
$result = $module->runUpgradeModule();

exit(json_encode($result));
