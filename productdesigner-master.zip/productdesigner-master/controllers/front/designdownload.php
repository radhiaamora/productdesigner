<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerFrontController;
use classes\helpers\DesignHelper;
use classes\models\design\Design;
use ExtendedZip\ExtendedZip;

class ProductDesignerDesignDownloadModuleFrontController extends DesignerFrontController
{
    public function ajaxProcessGetDownloadLink()
    {
        $design_data = Tools::getValue('design_data');
        $id_edit_design = (int)Tools::getValue('id_edit_design');

        $design = null;
        $design_helper = new DesignHelper($this->module, $this->context);
        try {
            $design = $design_helper->saveDesignFromRequest($this->id_product, $design_data, $id_edit_design);
        } catch (Exception $e) {
            $this->respond(array(
                'error'   => true,
                'message' => $e->getMessage()
            ));
        }

        $design_previews = $design->saveSvgCodes(true);

        $this->respond(array(
            'design'        => $design,
            'has_previews'  => count($design_previews) > 0,
            'download_link' => $this->context->link->getModuleLink($this->module->name, 'designdownload', array(
                'action'    => 'download_design',
                'id_design' => $design->id,
            ))
        ));
    }

    public function ajaxProcessDownloadDesign()
    {
        $id_design = (int)Tools::getValue('id_design');
        $design = new Design($id_design);
        $design_previews = $design->getPreviews();
        $path = null;
        if (count($design_previews) > 1) {
            $download_name = md5(uniqid('dsn', true));
            $svg_dir = $this->module->provider->getDataDir("output/{$download_name}");
            if (!mkdir($svg_dir) && !is_dir($svg_dir)) {
                throw new RuntimeException(sprintf('Directory "%s" was not created', $svg_dir));
            }
            $path = $this->module->provider->getDataDir('output') . $download_name . '.zip';
            if (is_file($path)) {
                unlink($path);
            }
            foreach ($design_previews as $design_preview) {
                $preview_path = $design_preview->getPath();
                copy($preview_path, $svg_dir . basename($preview_path));
            }
            ExtendedZip::zipTree($svg_dir, $path, 'design-' . $design->id, ZipArchive::CREATE);
            header('Content-Type: application/zip');
        } else {
            $design_preview = $design_previews[0];
            $path = $design_preview->getPath();
            header('Content-Type: application/svg');
        }

        header('Content-Transfer-Encoding: binary');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime($path)) . ' GMT');
        header('Accept-Ranges: bytes');
        header('Content-Length: ' . filesize($path));
        header('Content-Encoding: none');
        header('Content-Disposition: attachment; filename=' . basename($path));
        readfile($path);
        exit();
    }
}
