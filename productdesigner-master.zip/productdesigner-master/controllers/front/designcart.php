<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerFrontController;
use classes\DesignerTools;
use classes\helpers\DesignHelper;
use classes\helpers\DesignPricingHelper;
use classes\models\design\Design;
use classes\models\design\DesignCustomField;

class ProductDesignerDesignCartModuleFrontController extends DesignerFrontController
{
    public function ajaxProcessGetSvgCodes()
    {
        $id_design = (int)Tools::getValue('id_design');
        $design = new Design($id_design);
        $svg_codes = $design->getSvgCodes();
        foreach ($svg_codes as $svg_code) {
            echo $svg_code['code'];
        }
        exit();
    }

    public function ajaxProcessSaveDesignData()
    {
        $id_customization = (int)Tools::getValue('id_customization');
        $id_customization_field = DesignCustomField::getOrCreateCustomField($this->id_product)->id_customization_field;

        $design_data = Tools::getValue('design_data');
        $id_edit_design = (int)Tools::getValue('id_edit_design');

        $design = null;
        $design_helper = new DesignHelper($this->module, $this->context);
        try {
            $design = $design_helper->saveDesignFromRequest($this->id_product, $design_data, $id_edit_design);
        } catch (Exception $e) {
            $this->respond(array(
                'error'   => true,
                'message' => $e->getMessage()
            ));
        }

        $design->addToCart($id_customization, $id_customization_field);

        $design_previews = $design->saveSvgCodes(true);

        $this->respond(array(
            'design'                 => $design,
            'design_previews'        => $design_previews,
            'id_module'              => $this->module->id,
            'id_customization'       => $design->id_customization,
        ));
    }

    public function ajaxProcessSaveInitialDesignData()
    {
        $design_data = Tools::getValue('design_data');
        $containers = $design_data['containers'];
        if (Design::isEmpty($containers)) {
            $this->respond(array(
                'error'   => true,
                'message' => $this->module->l('Please add some design items first', DesignerTools::getSource())
            ));
        }

        $design = Design::getInitialDesign($this->id_product);
        if (Validate::isLoadedObject($design)) {
            $design->delete();
        }

        $design = DesignHelper::collectData($design_data);
        $design->id_customer = 0;
        $design->id_guest = 0;
        $design->is_initial = true;
        $design->saveAll();

        $this->respond();
    }

    public function ajaxProcessDeleteInitialDesign()
    {
        $design = Design::getInitialDesign($this->id_product);
        if (Validate::isLoadedObject($design)) {
            $design->delete();
        }
        $this->respond();
    }

    public function ajaxProcessDisplayPrice()
    {
        $id_product_attribute = (int)Tools::getValue('id_product_attribute');
        $quantity = (int)Tools::getValue('quantity');
        $adapter_data = Tools::getValue('adapter_data');

        $pricing_helper = new DesignPricingHelper($this->module, $this->context);

        $customization_prices = array(
            'price_ht'     => 0,
            'price_ht_nr'  => 0,
            'price_ttc'    => 0,
            'price_ttc_nr' => 0,
        );

        $design_data = Tools::getValue('design_data');
        if ($design_data) {
            $design = DesignHelper::collectData($design_data);
            $customization_prices = $design->getCustomizationPrices();
        }

        $modules_prices = $pricing_helper->getCustomizationPrices($customization_prices, $adapter_data);
        $product_prices = $pricing_helper->getProductPrices($this->id_product, $id_product_attribute, $quantity);
        $combined_prices = $pricing_helper->combinePrices($modules_prices, $product_prices);
        $formatted_prices = $pricing_helper->formatPrices($combined_prices);

        $this->respond(array(
            'use_tax'              => !Product::getTaxCalculationMethod(),
            'formatted_prices'     => $formatted_prices,
            'customization_prices' => $customization_prices
        ));
    }
}
