<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerAdminController;
use classes\DesignerTools;
use classes\helpers\LayerHelper;
use classes\helpers\ProductImageHelper;
use classes\models\DesignerColor;
use classes\models\layers\Layer;
use classes\models\layers\LayerGroup;
use classes\models\layers\LayerImage;
use classes\svg\ColorizerHelper;

Module::getInstanceByName('productdesigner');

class DsnLayersController extends DesignerAdminController
{
    public function ajaxProcessGetLayerSides()
    {
        $layer_helper = new LayerHelper($this->module, $this->context);

        $product_image_helper = new ProductImageHelper($this->module, $this->context);
        $product_images = $product_image_helper->getProductImages($this->id_product);

        $this->respond(array(
            'layer_sides' => $layer_helper->getLayerSides($this->id_product, $this->id_default_lang),
            'has_images'  => count($product_images)
        ));
    }

    public function ajaxProcessAddLayerGroup()
    {
        $source = DesignerTools::getSource();
        $layer_group = new LayerGroup();
        $layer_group->label[$this->id_default_lang] = $this->module->l('New group', $source);
        $layer_group->id_product = $this->id_product;
        $layer_group->position = 1 + $layer_group->getHighestPosition(array(
                'key'   => 'id_product',
                'value' => $this->id_product
            ));
        $layer_group->save();

        $layer = new Layer();
        $layer->id_product = $this->id_product;
        $layer->id_layer_group = $layer_group->id;
        $layer->label[$this->id_default_lang] = $this->module->l('New layer', $source);
        $layer->position = 1 + $layer->getHighestPosition(array(
                'key'   => 'id_layer_group',
                'value' => $layer_group->id
            ));
        $layer->save();

        $this->respond(array(
            'layer_group' => new LayerGroup($layer_group->id, $this->id_default_lang)
        ));
    }

    public function ajaxProcessAddDesignLayer()
    {
        $source = DesignerTools::getSource();
        if (LayerGroup::getProductDesignLayer($this->id_product)) {
            $this->respond(array(
                'error'   => true,
                'message' => $this->module->l('This product already has a design layer', $source),
            ));
        }
        $layer_group = new LayerGroup();
        $layer_group->label[$this->id_default_lang] = $this->module->l('Design layer', $source);
        $layer_group->id_product = $this->id_product;
        $layer_group->is_design_layer = true;
        $layer_group->position = 1 + $layer_group->getHighestPosition(array(
                'key'   => 'id_product',
                'value' => $this->id_product
            ));
        $layer_group->save();

        $this->respond(array(
            'layer_group' => new LayerGroup($layer_group->id, $this->id_default_lang)
        ));
    }

    public function ajaxProcessCopyLayerGroup()
    {
        $id_layer_group = (int)Tools::getValue('id_layer_group');
        $layer_group = new LayerGroup($id_layer_group);
        $new_layer_group = $layer_group->copyToProduct($this->id_product);
        LayerGroup::fixPositions(LayerGroup::getByProduct($this->id_product));
        $this->respond(array(
            'layer_group' => new LayerGroup($new_layer_group->id, $this->id_default_lang)
        ));
    }

    public function ajaxProcessGetLayerGroup()
    {
        $id_layer_group = (int)Tools::getValue('id_layer_group');
        $this->respond(array(
            'layer_group'      => new LayerGroup($id_layer_group),
            'languages'        => Language::getLanguages(),
            'language_img_dir' => _PS_IMG_ . 'l/'
        ));
    }

    public function ajaxProcessSaveLayerGroup()
    {
        $layer_group_data = Tools::getValue('layer_group');
        $layer_group = new LayerGroup($layer_group_data['id']);
        $layer_group->label = $layer_group_data['label'];
        $layer_group->active = $layer_group_data['active'] === 'true' || (int)$layer_group_data['active'];
        $layer_group->required = $layer_group_data['required'] === 'true' || (int)$layer_group_data['required'];
        $layer_group->save();

        $this->respond(array(
            'layer_group' => new LayerGroup($layer_group->id, $this->id_default_lang)
        ));
    }

    public function ajaxProcessReorderLayerGroups()
    {
        $order = Tools::getValue('order');
        foreach ($order as $position => $id_layer_group) {
            $layer_group = new LayerGroup((int)$id_layer_group);
            $layer_group->position = $position;
            $layer_group->save();
        }
        $this->respond(array(
            'layer_groups' => LayerGroup::getByProduct($this->id_product, $this->id_default_lang)
        ));
    }

    public function ajaxProcessToggleGroupActive()
    {
        $id_layer_group = (int)Tools::getValue('id_layer_group');
        $layer_group = new LayerGroup($id_layer_group, $this->id_default_lang);
        $layer_group->active = !$layer_group->active;
        $layer_group->save();
        $this->respond(array(
            'layer_group' => $layer_group,
        ));
    }

    public function ajaxProcessDeleteLayerGroup()
    {
        $id_layer_group = (int)Tools::getValue('id_layer_group');
        $layer_group = new LayerGroup($id_layer_group);
        $layer_group->delete();

        LayerGroup::fixPositions(LayerGroup::getByProduct($this->id_product));

        $this->respond(array(
            'layer_groups' => LayerGroup::getByProduct($this->id_product, $this->id_default_lang)
        ));
    }

    public function ajaxProcessAddLayer()
    {
        $source = DesignerTools::getSource();
        $id_layer_group = (int)Tools::getValue('id_layer_group');

        $layer = new Layer();
        $layer->id_product = $this->id_product;
        $layer->id_layer_group = $id_layer_group;
        $layer->label[$this->id_default_lang] = $this->module->l('New layer', $source);
        $layer->position = 1 + $layer->getHighestPosition(array(
                'key'   => 'id_layer_group',
                'value' => $id_layer_group
            ));
        $layer->save();

        $this->respond(array(
            'layer' => new Layer($layer->id, $this->id_default_lang)
        ));
    }

    public function ajaxProcessGetLayer()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $this->respond(array(
            'layer'            => new Layer($id_layer),
            'languages'        => Language::getLanguages(),
            'language_img_dir' => _PS_IMG_ . 'l/'
        ));
    }

    public function ajaxProcessSaveLayer()
    {
        $layer_data = Tools::getValue('layer');
        $layer = new Layer($layer_data['id']);
        $layer->label = $layer_data['label'];
        $layer->price = (float)$layer_data['price'];
        $layer->active = $layer_data['active'] === 'true' || (int)$layer_data['active'];
        $layer->save();

        $this->respond(array(
            'layer' => new Layer($layer->id, $this->id_default_lang)
        ));
    }

    public function ajaxProcessReorderLayers()
    {
        $id_layer_group = (int)Tools::getValue('id_layer_group');
        $order = Tools::getValue('order');
        foreach ($order as $position => $id_layer) {
            $layer = new Layer($id_layer);
            $layer->position = $position;
            $layer->save();
        }
        $this->respond(array(
            'layers' => Layer::getByLayerGroup($id_layer_group, $this->id_default_lang)
        ));
    }

    public function ajaxProcessToggleLayerActive()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $layer = new Layer($id_layer, $this->id_default_lang);
        $layer->active = !$layer->active;
        $layer->save();
        $this->respond(array(
            'layer' => $layer,
        ));
    }

    public function ajaxProcessToggleLayerSelected()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $layer = new Layer($id_layer, $this->id_default_lang);
        Layer::unselectLayersByGroup($layer->id_layer_group);
        $layer->selected = !$layer->selected;
        $layer->save();
        $this->respond(array(
            'layer'       => $layer,
            'layer_group' => new LayerGroup($layer->id_layer_group, $this->id_default_lang)
        ));
    }

    public function ajaxProcessDeleteLayer()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $layer = new Layer($id_layer);
        $layer->delete();

        Layer::fixPositions(Layer::getByLayerGroup($layer->id_layer_group));

        $this->respond(array(
            'layers' => Layer::getByLayerGroup($layer->id_layer_group, $this->id_default_lang),
        ));
    }

    public function ajaxProcessSaveLayerImageFile()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $id_side = (int)Tools::getValue('id_side');
        $layer_image = LayerImage::getByLayerAndSide($id_layer, $id_side);
        $layer_image->saveFromPost();

        if (!$layer_image->icon) {
            $filename = $layer_image->image;
            $extension = pathinfo($filename, PATHINFO_EXTENSION);
            $layer_image->icon = $filename . '.icon.' . $extension;
            copy($layer_image->getPath('image'), $layer_image->getPathForCreation('icon'));
            $layer_image->createNewThumbnails();
            $layer_image->save();
        }

        $source = DesignerTools::getSource();
        $layer = new Layer($id_layer);
        if ($layer->label[$this->id_default_lang] === $this->module->l('New layer', $source)) {
            $layer->label = array();
            $languages = Language::getLanguages();
            foreach ($languages as $language) {
                $layer->label[(int)$language['id_lang']] = DesignerTools::capitalizeFilename($_FILES['image']['name']);
            }
            $layer->save();
        }

        $this->respond(array(
            'layer'       => new Layer($id_layer, $this->id_default_lang),
            'layer_image' => new LayerImage($layer_image->id)
        ));
    }

    public function ajaxProcessSaveLayerIconFile()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $id_side = (int)Tools::getValue('id_side');
        $layer_image = LayerImage::getByLayerAndSide($id_layer, $id_side);
        $layer_image->saveFromPost();

        $this->respond(array(
            'layer_image' => new LayerImage($layer_image->id)
        ));
    }

    public function ajaxProcessSaveLayerImageColor()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $id_side = (int)Tools::getValue('id_side');
        $color = Tools::getValue('color');

        $layer_image = LayerImage::getByLayerAndSide($id_layer, $id_side);
        $layer_image->color = $color;
        $layer_image->save();

        $this->respond(array(
            'layer_image' => new LayerImage($layer_image->id)
        ));
    }

    public function ajaxProcessDeleteLayerImageFile()
    {
        $name = Tools::getValue('name');
        $id_layer = (int)Tools::getValue('id_layer');
        $id_side = (int)Tools::getValue('id_side');
        $layer_image = LayerImage::getByLayerAndSide($id_layer, $id_side);
        $layer_image->deleteFile($name);
        $layer_image->save();

        $this->respond(array(
            'layer_image' => new LayerImage($layer_image->id)
        ));
    }

    public function ajaxProcessSaveLayersFiles()
    {
        $id_layer_group = (int)Tools::getValue('id_layer_group');
        $layer_group = new LayerGroup($id_layer_group);

        $id_side = (int)Tools::getValue('id_side');

        $uploader = new Uploader();
        $uploader->setName('images');
        $uploader->setAcceptTypes(LayerImage::$definition['fields']['image']['extensions']);
        $files = $uploader->process();
        foreach ($files as $file) {
            if ($file['error'] === 0) {
                $path = $file['save_path'];
                $filename = $file['name'];
                $layer_name = DesignerTools::capitalizeFilename($file['name']);
                $layer = new Layer();
                $layer->id_product = $layer_group->id_product;
                $layer->id_layer_group = $id_layer_group;
                $layer->label[$this->id_default_lang] = $layer_name;
                $layer->position = 1 + $layer->getHighestPosition(array(
                        'key'   => 'id_layer_group',
                        'value' => $id_layer_group
                    ));
                $layer->save();

                $extension = pathinfo($filename, PATHINFO_EXTENSION);

                $layer_image = LayerImage::getByLayerAndSide($layer->id, $id_side);
                $layer_image->save();
                $layer_image->image = $layer_image->id . '-image' . $extension;
                copy($path, $layer_image->getPathForCreation('image'));

                $layer_image->icon = $layer_image->id . '-icon' . $extension;
                copy($path, $layer_image->getPathForCreation('icon'));
                $layer_image->createNewThumbnails();
                $layer_image->save();
            }
        }

        $this->respond(array(
            'layer_group' => new LayerGroup($id_layer_group, $this->id_default_lang)
        ));
    }

    public function ajaxProcessGetColors()
    {
        $this->respond(array(
            'colors' => DesignerColor::getAll($this->id_default_lang)
        ));
    }

    public function ajaxProcessColorizeLayer()
    {
        $id_layer = (int)Tools::getValue('id_layer');
        $layer = new Layer($id_layer);
        $layer_images = $layer->layer_images;

        $colorizer_helper = new ColorizerHelper($this->module, $this->context);

        $colors = (array)Tools::getValue('colors');
        foreach ($colors as $id_color => $enabled) {
            if ((int)$enabled) {
                $designer_color = new DesignerColor($id_color);

                $new_layer = new Layer();
                $new_layer->label = $designer_color->label;
                $new_layer->id_product = $layer->id_product;
                $new_layer->id_layer_group = $layer->id_layer_group;
                $new_layer->price = $layer->price;
                $new_layer->position = 1 + $new_layer->getHighestPosition(array(
                        'key'   => 'id_layer_group',
                        'value' => $layer->id_layer_group
                    ));
                $new_layer->add();

                foreach ($layer_images as $layer_image) {
                    $image_path = $layer_image->getPath('image');
                    $icon_path = $layer_image->getPath('icon');


                    $new_layer_image = new LayerImage();
                    $new_layer_image->id_layer = $new_layer->id;
                    $new_layer_image->id_side = $layer_image->id_side;
                    $new_layer_image->color = $designer_color->color;
                    $new_layer_image->save();

                    $new_layer_image->image = "{$new_layer_image->id}-image.svg";
                    $new_layer_image->icon = "{$new_layer_image->id}-icon.svg";
                    $new_layer_image->save();

                    if ($image_path) {
                        $colorizer_helper->colorize(
                            $image_path,
                            $id_color,
                            $new_layer_image->getPathForCreation('image')
                        );
                    }

                    if ($icon_path) {
                        $colorizer_helper->colorize(
                            $icon_path,
                            $id_color,
                            $new_layer_image->getPathForCreation('icon')
                        );
                    }
                }
            }
        }
        $this->respond(array(
            'layer_group' => new LayerGroup($layer->id_layer_group, $this->id_default_lang)
        ));
    }
}
