<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerAdminController;
use classes\models\DesignerField;
use classes\panels\product\panels\DesignFieldsPanel;

Module::getInstanceByName('productdesigner');

class DsnProductFieldsController extends DesignerAdminController
{
    public function ajaxProcessSaveDesignField()
    {
        $id_design_field = (int)Tools::getValue('id_design_field');
        $id_side = (int)Tools::getValue('id_side');
        $design_field = new DesignerField($id_design_field);
        $design_field->id_product = (int)$this->id_product;
        $design_field->id_side = $id_side;
        $design_field->x = (float)Tools::getValue('x');
        $design_field->y = (float)Tools::getValue('y');
        $design_field->width = (float)Tools::getValue('width');
        $design_field->height = (float)Tools::getValue('height');
        $design_field->save();
        $this->respond(array(
            'design_field' => $design_field
        ));
    }

    public function ajaxProcessDeleteDesignField()
    {
        $id_design_field = (int)Tools::getValue('id_design_field');
        $design_field = new DesignerField($id_design_field);
        $design_field->delete();
        $this->respond();
    }

    public function ajaxProcessEditDesignField()
    {
        $id_design_field = (int)Tools::getValue('id_design_field');
        exit(DesignFieldsPanel::getEditForm($id_design_field));
    }

    public function ajaxProcessSaveDesignFieldOptions()
    {
        $id_design_field = (int)Tools::getValue('id_design_field');
        $design_field = new DesignerField($id_design_field);
        $design_field->saveFromPost();
        $this->respond(array(
            'design_field' => new DesignerField($id_design_field, $this->context->language->id)
        ));
    }
}
