<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerAdminController;
use classes\models\DesignerProductImage;

Module::getInstanceByName('productdesigner');

class DsnProductImagesController extends DesignerAdminController
{
    public function ajaxProcessSaveProductImage()
    {
        $name = Tools::getValue('name');
        $id_image = (int)Tools::getValue('id_image');
        $id_side = (int)Tools::getValue('id_side');

        $product_image = DesignerProductImage::getByImageAndSide($this->id_product, $id_image, $id_side);
        $product_image->saveFromPost();
        if ($name === 'canvas') {
            $canvas_path = $product_image->getPath('canvas');
            list ($width, $height) = getimagesize($canvas_path);
            $product_image->canvas_width = (int)$width;
            $product_image->canvas_height = (int)$height;
        }
        $product_image->save();
        $this->respond(array(
            'url'   => $product_image->getFileUriWithHash($name),
            'thumb' => $product_image->getThumbUri($name)
        ));
    }

    public function ajaxProcessDeleteProductImage()
    {
        $name = Tools::getValue('name');
        $id_image = (int)Tools::getValue('id_image');
        $id_side = (int)Tools::getValue('id_side');
        $product_image = DesignerProductImage::getByImageAndSide($this->id_product, $id_image, $id_side);
        $product_image->deleteFile($name);
        $product_image->save();
        $this->respond(array(
            'url' => false
        ));
    }
}
