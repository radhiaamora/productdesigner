<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerAdminController;
use classes\models\DesignerImageColor;
use classes\models\DesignerImageFilter;
use classes\models\DesignerProductColor;
use classes\models\DesignerProductFont;
use classes\models\DesignerProductImageGroup;
use classes\models\DesignerProductSide;
use classes\models\DesignerProductTab;
use classes\models\DesignerTextColor;

Module::getInstanceByName('productdesigner');

class DsnProductExtraController extends DesignerAdminController
{
    public function ajaxProcessSaveProductTabs()
    {
        DesignerProductTab::deleteAllByProduct($this->id_product);
        $tabs = (array)Tools::getValue('items');
        foreach ($tabs as $id_tab => $checked) {
            if ((int)$checked) {
                $product_tab = new DesignerProductTab();
                $product_tab->id_product = (int)$this->id_product;
                $product_tab->id_tab = (int)$id_tab;
                $product_tab->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveProductTabsValue()
    {
        $name = Tools::getValue('name');
        $id_tab = (int)str_replace('active_tabs_', '', $name);
        if ($id_tab) {
            $value = (int)Tools::getValue('value');
            /** @noinspection UnnecessaryCastingInspection */
            Db::getInstance()->delete(
                $this->module->name . '_product_tab',
                'id_product = ' . (int)$this->id_product . ' AND id_tab  = ' . (int)$id_tab
            );
            if ($value) {
                Db::getInstance()->insert(
                    $this->module->name . '_product_tab',
                    array(
                        'id_product' => (int)$this->id_product,
                        'id_tab'     => $id_tab
                    )
                );
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveProductSides()
    {
        DesignerProductSide::deleteAllByProduct($this->id_product);
        $sides = (array)Tools::getValue('items');
        foreach ($sides as $id_side => $checked) {
            if ((int)$checked) {
                $product_side = new DesignerProductSide();
                $product_side->id_product = (int)$this->id_product;
                $product_side->id_side = (int)$id_side;
                $product_side->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveTextColors()
    {
        DesignerTextColor::deleteAllByProduct($this->id_product);
        $colors = (array)Tools::getValue('items');
        foreach ($colors as $id_color => $checked) {
            if ($checked) {
                $text_color = new DesignerTextColor();
                $text_color->id_product = (int)$this->id_product;
                $text_color->id_color = (int)$id_color;
                $text_color->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveImageColors()
    {
        DesignerImageColor::deleteAllByProduct($this->id_product);
        $colors = (array)Tools::getValue('items');
        foreach ($colors as $id_color => $checked) {
            if ($checked) {
                $image_color = new DesignerImageColor();
                $image_color->id_product = (int)$this->id_product;
                $image_color->id_color = (int)$id_color;
                $image_color->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveImageFilters()
    {
        DesignerImageFilter::deleteAllByProduct($this->id_product);
        $filters = (array)Tools::getValue('items');
        foreach ($filters as $id_filter => $checked) {
            if ($checked) {
                $image_filter = new DesignerImageFilter();
                $image_filter->id_product = (int)$this->id_product;
                $image_filter->id_filter = (int)$id_filter;
                $image_filter->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveProductImageGroups()
    {
        DesignerProductImageGroup::deleteAllByProduct($this->id_product);
        $image_groups = (array)Tools::getValue('items');
        foreach ($image_groups as $id_image_group => $checked) {
            if ($checked) {
                $product_image_group = new DesignerProductImageGroup();
                $product_image_group->id_product = (int)$this->id_product;
                $product_image_group->id_image_group = (int)$id_image_group;
                $product_image_group->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveProductFonts()
    {
        DesignerProductFont::deleteAllByProduct($this->id_product);
        $fonts = (array)Tools::getValue('items');
        foreach ($fonts as $id_font => $checked) {
            if ($checked) {
                $product_font = new DesignerProductFont();
                $product_font->id_product = (int)$this->id_product;
                $product_font->id_font = (int)$id_font;
                $product_font->save();
            }
        }
        $this->respond();
    }

    public function ajaxProcessSaveProductColors()
    {
        DesignerProductColor::deleteAllByProduct($this->id_product);
        $colors = (array)Tools::getValue('items');
        foreach ($colors as $id_color => $checked) {
            if ($checked) {
                $product_color = new DesignerProductColor();
                $product_color->id_product = (int)$this->id_product;
                $product_color->id_color = (int)$id_color;
                $product_color->save();
            }
        }
        $this->respond();
    }
}
