<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/** @noinspection PhpUnused */

use classes\controllers\DesignerAdminController;
use classes\models\ImageAreaInterval;

Module::getInstanceByName('productdesigner');

class DsnImageAreaIntervalsController extends DesignerAdminController
{
    public function ajaxProcessGetIntervals()
    {
        $this->respond(array(
            'intervals' => ImageAreaInterval::getProductIntervals($this->id_product)
        ));
    }

    public function ajaxProcessSaveInterval()
    {
        $interval_data = Tools::getValue('interval');
        $interval = new ImageAreaInterval((int)$interval_data['id']);
        $interval->from = (float)$interval_data['from'];
        $interval->to = (float)$interval_data['to'];
        $interval->cost = (float)$interval_data['cost'];
        $interval->save();
        $this->respond();
    }

    public function ajaxProcessAddInterval()
    {
        $sql = new DbQuery();
        $sql->from(ImageAreaInterval::$definition['table']);
        $sql->select('MAX(`to`)');
        $sql->where('id_product = ' . (int)$this->id_product);
        $to = (float)Db::getInstance()->getValue($sql);

        $interval = new ImageAreaInterval();
        $interval->id_product = $this->id_product;
        $interval->from = $to;
        $interval->to = $to + 10;
        $interval->cost = 0;
        $interval->add();
        $this->respond(array(
            'interval' => $interval
        ));
    }

    public function ajaxProcessDeleteInterval()
    {
        $id_interval = (int)Tools::getValue('id_interval');
        $interval = new ImageAreaInterval($id_interval);
        $interval->delete();
        $this->respond();
    }
}
