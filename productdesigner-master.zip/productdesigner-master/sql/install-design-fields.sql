CREATE TABLE IF NOT EXISTS `__PREFIX_design_field` (
  `id_design_field` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  `x` DECIMAL (18, 6) NOT NULL,
  `y` DECIMAL (18, 6) NOT NULL,
  `width` DECIMAL (18, 6) NOT NULL,
  `height` DECIMAL (18, 6) NOT NULL,
  `is_text_field` tinyint(1) NOT NULL DEFAULT 0,
  `is_static` tinyint(1) NOT NULL DEFAULT 0,
  `is_limited` tinyint(1) NOT NULL DEFAULT 1,
  `include_elements_cost` tinyint(1) NOT NULL DEFAULT 1,
  `stretch_image` tinyint(1) NOT NULL DEFAULT 0,
  `type` int(3) NOT NULL DEFAULT 0,
  `cost` DECIMAL (18, 6) NOT NULL,
  PRIMARY KEY (`id_design_field`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_design_field_lang` (
  `id_design_field` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id_design_field`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
