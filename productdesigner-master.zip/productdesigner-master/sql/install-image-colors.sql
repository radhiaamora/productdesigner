CREATE TABLE IF NOT EXISTS `__PREFIX_image_color` (
  `id_image_color` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_color` int(11) NOT NULL,
  PRIMARY KEY (`id_image_color`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;