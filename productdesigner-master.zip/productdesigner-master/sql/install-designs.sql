CREATE TABLE IF NOT EXISTS `__PREFIX_design` (
  `id_design` int(11) NOT NULL AUTO_INCREMENT,
  `id_cart` int(10) NOT NULL,
  `id_product` int(10) NOT NULL,
  `id_product_attribute` int(10) NOT NULL,
  `id_customization` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `id_customer` int(10) NOT NULL,
  `id_guest` int(10) NOT NULL,
  `is_initial` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_design`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;