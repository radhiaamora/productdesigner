CREATE TABLE IF NOT EXISTS `__PREFIX_font` (
  `id_font` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `family` varchar(128) NOT NULL,
  `file` varchar(128) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_font`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;