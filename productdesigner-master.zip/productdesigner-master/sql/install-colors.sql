CREATE TABLE IF NOT EXISTS `__PREFIX_color` (
  `id_color` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(32) NOT NULL,
  `file` varchar(128) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_color`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_color_lang` (
  `id_color` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id_color`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;