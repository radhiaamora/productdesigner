CREATE TABLE IF NOT EXISTS `__PREFIX_product_font` (
  `id_product_font` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_font` int(11) NOT NULL,
  PRIMARY KEY (`id_product_font`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;