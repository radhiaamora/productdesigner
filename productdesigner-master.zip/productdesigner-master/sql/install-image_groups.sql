CREATE TABLE IF NOT EXISTS `__PREFIX_image_group` (
  `id_image_group` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(128) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `is_white` tinyint(1) NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_image_group`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_image_group_lang` (
  `id_image_group` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id_image_group`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
