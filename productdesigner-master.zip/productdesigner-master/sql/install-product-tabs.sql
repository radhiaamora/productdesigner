CREATE TABLE IF NOT EXISTS `__PREFIX_product_tab` (
  `id_product_tab` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_tab` int(11) NOT NULL,
  PRIMARY KEY (`id_product_tab`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;