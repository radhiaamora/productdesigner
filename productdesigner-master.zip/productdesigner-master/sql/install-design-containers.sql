CREATE TABLE IF NOT EXISTS `__PREFIX_design_container` (
  `id_design_container` int(11) NOT NULL AUTO_INCREMENT,
  `id_design` int(10) NOT NULL,
  `id_container` int(10) NOT NULL,
  `container_type` varchar(32) NOT NULL,
  `id_side` int(10) NOT NULL,
  PRIMARY KEY (`id_design_container`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;