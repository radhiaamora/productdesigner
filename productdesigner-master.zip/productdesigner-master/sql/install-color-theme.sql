CREATE TABLE IF NOT EXISTS `__PREFIX_color_theme` (
  `id_color_theme` int(11) NOT NULL AUTO_INCREMENT,

  `primary_color` varchar(32) NOT NULL DEFAULT '#2f83a8',
  `secondary_color` varchar(32) NOT NULL DEFAULT '#85c347',
  `primary_bg_color` varchar(32) NOT NULL DEFAULT '#363b3f',
  `secondary_bg_color` varchar(32) NOT NULL DEFAULT '#535e64',

  PRIMARY KEY (`id_color_theme`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;