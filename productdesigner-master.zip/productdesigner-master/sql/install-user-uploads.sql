CREATE TABLE IF NOT EXISTS `__PREFIX_user_upload` (
  `id_user_upload` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(128) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_guest` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `date_add` datetime NOT NULL,
  PRIMARY KEY (`id_user_upload`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;