CREATE TABLE IF NOT EXISTS `__PREFIX_product_side` (
  `id_product_side` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  PRIMARY KEY (`id_product_side`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;