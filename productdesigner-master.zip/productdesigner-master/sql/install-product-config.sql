CREATE TABLE IF NOT EXISTS `__PREFIX_product_config`
(
    `id_product_config`                  int(11)        NOT NULL AUTO_INCREMENT,
    `id_product`                         int(11)        NOT NULL,

    `active`                             tinyint(1)     NOT NULL DEFAULT 0,
    `required`                           tinyint(1)     NOT NULL DEFAULT 0,

    `tabs_use_global_config`             tinyint(1)     NOT NULL DEFAULT 1,
    `enable_all_tabs`                    tinyint(1)     NOT NULL DEFAULT 1,
    `initial_tab`                        int(11)                 DEFAULT 0,

    `enable_all_text_colors`             tinyint(1)     NOT NULL DEFAULT 1,
    `enable_all_image_colors`            tinyint(1)     NOT NULL DEFAULT 1,
    `enable_all_image_filters`           tinyint(1)     NOT NULL DEFAULT 1,
    `enable_all_product_colors`          tinyint(1)     NOT NULL DEFAULT 1,

    `enable_all_fonts`                   tinyint(1)     NOT NULL DEFAULT 1,
    `enable_all_image_groups`            tinyint(1)     NOT NULL DEFAULT 1,

    `small_image_groups`                 tinyint(1)     NOT NULL DEFAULT 0,

    `enable_text_colorpickers`           tinyint(1)     NOT NULL DEFAULT 1,
    `enable_text_transparency`           tinyint(1)     NOT NULL DEFAULT 1,
    `enable_text_curvature`              tinyint(1)     NOT NULL DEFAULT 1,
    `text_maxlength`                     int(11),
    `text_default_align`                 varchar(10)             DEFAULT 'center',

    `enable_image_colors`                tinyint(1)     NOT NULL DEFAULT 0,
    `enable_image_colorpickers`          tinyint(1)     NOT NULL DEFAULT 1,
    `enable_image_transparency`          tinyint(1)     NOT NULL DEFAULT 1,
    `enable_image_brightness`            tinyint(1)     NOT NULL DEFAULT 0,
    `enable_image_contrast`              tinyint(1)     NOT NULL DEFAULT 0,
    `enable_image_flip`                  tinyint(1)     NOT NULL DEFAULT 0,
    `initial_image_color`                int(11)                 DEFAULT -1,

    `enable_image_filters`               tinyint(1)     NOT NULL DEFAULT 0,

    `enable_product_colors`              tinyint(1)     NOT NULL DEFAULT 0,
    `enable_product_colorpickers`        tinyint(1)     NOT NULL DEFAULT 1,
    `initial_product_color`              int(11)                 DEFAULT -1,

    `allow_upload`                       tinyint(1)     NOT NULL DEFAULT 1,

    `enable_design_fields`               tinyint(1)     NOT NULL DEFAULT 0,

    `enable_layers`                      tinyint(1)     NOT NULL DEFAULT 0,

    `single_color`                       tinyint(1)     NOT NULL DEFAULT 0,
    `enable_resize_image`                tinyint(1)     NOT NULL DEFAULT 1,
    `enable_drag_image`                  tinyint(1)     NOT NULL DEFAULT 1,
    `enable_resize_text`                 tinyint(1)     NOT NULL DEFAULT 1,
    `enable_drag_text`                   tinyint(1)     NOT NULL DEFAULT 1,
    `min_text_size`                      DECIMAL(18, 6) NOT NULL DEFAULT 0,
    `min_image_size`                     DECIMAL(18, 6) NOT NULL DEFAULT 0,

    `enable_product_size`                tinyint(1)     NOT NULL DEFAULT 0,
    `allow_change_product_size_aspect`   tinyint(1)     NOT NULL DEFAULT 1,
    `product_size_aspect_locked_default` tinyint(1)     NOT NULL DEFAULT 1,
    `initial_width`                      DECIMAL(18, 6) NOT NULL DEFAULT 0,
    `initial_height`                     DECIMAL(18, 6) NOT NULL DEFAULT 0,
    `min_width`                          DECIMAL(18, 6) NOT NULL DEFAULT 0,
    `min_height`                         DECIMAL(18, 6) NOT NULL DEFAULT 0,
    `max_width`                          DECIMAL(18, 6) NOT NULL DEFAULT 0,
    `max_height`                         DECIMAL(18, 6) NOT NULL DEFAULT 0,

    PRIMARY KEY (`id_product_config`)
) ENGINE = _MYSQL_ENGINE_
  DEFAULT CHARSET = utf8;
