CREATE TABLE IF NOT EXISTS `__PREFIX_config`
(
    `id_config`                int(11)    NOT NULL AUTO_INCREMENT,

    `display_base`             tinyint(1) NOT NULL DEFAULT 1,
    `display_mask`             tinyint(1) NOT NULL DEFAULT 1,
    `display_layers`           tinyint(1) NOT NULL DEFAULT 1,
    `preview_in_invoice`       tinyint(1) NOT NULL DEFAULT 0,
    `preview_in_email`         tinyint(1) NOT NULL DEFAULT 0,
    `hide_cart_button`         tinyint(1) NOT NULL DEFAULT 0,
    `show_custom_btn`          tinyint(1) NOT NULL DEFAULT 1,
    `show_attributes_in_tabs`  tinyint(1) NOT NULL DEFAULT 1,
    `hide_size_input`          tinyint(1) NOT NULL DEFAULT 1,
    `hide_style_buttons`       tinyint(1) NOT NULL DEFAULT 0,
    `hide_alignment`           tinyint(1) NOT NULL DEFAULT 0,
    `hide_outline`             tinyint(1) NOT NULL DEFAULT 0,
    `enable_text_precision`    tinyint(1) NOT NULL DEFAULT 0,
    `show_in_popup`            tinyint(1) NOT NULL DEFAULT 0,
    `auto_show_popup`          tinyint(1) NOT NULL DEFAULT 0,
    `show_dimensions`          tinyint(1) NOT NULL DEFAULT 0,
    `show_delete_confirmation` tinyint(1) NOT NULL DEFAULT 1,
    `show_download_btn`        tinyint(1) NOT NULL DEFAULT 0,
    `field_multiple_items`     tinyint(1) NOT NULL DEFAULT 1,
    `min_dpi`                  int(10)    NOT NULL DEFAULT 72,
    `block_min_dpi`            tinyint(1) NOT NULL DEFAULT 1,
    `upload_maxsize`           INT(10)    NOT NULL DEFAULT 512000,

    `enable_all_tabs`          tinyint(1) NOT NULL DEFAULT 1,
    `initial_tab`              int(11)             DEFAULT 0,

    PRIMARY KEY (`id_config`)
) ENGINE = _MYSQL_ENGINE_
  DEFAULT CHARSET = utf8;
