CREATE TABLE IF NOT EXISTS `__PREFIX_custom_field` (
  `id_custom_field` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_customization_field` int(11) NOT NULL,
  PRIMARY KEY (`id_custom_field`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;