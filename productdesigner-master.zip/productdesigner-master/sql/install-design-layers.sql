CREATE TABLE IF NOT EXISTS `__PREFIX_design_layer` (
  `id_design_layer` int(11) NOT NULL AUTO_INCREMENT,
  `id_design` int(11) NOT NULL,
  `id_layer_group` int(11) NOT NULL,
  `id_layer` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_design_layer`)
) ENGINE=MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
