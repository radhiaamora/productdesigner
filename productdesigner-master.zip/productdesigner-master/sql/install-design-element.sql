CREATE TABLE IF NOT EXISTS `__PREFIX_design_element` (
  `id_design_element` int(11) NOT NULL AUTO_INCREMENT,

  `id_design_container` int(10) NOT NULL,

  `category` varchar(32) NOT NULL,

  `id_side` int(10) NOT NULL,

  PRIMARY KEY (`id_design_element`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;