CREATE TABLE IF NOT EXISTS `__PREFIX_design_image`
(
    `id_design_image` int(11)         NOT NULL AUTO_INCREMENT,

    `id_design_item`  int(10)         NOT NULL,

    `id_image`        int(10)         NOT NULL,
    `upload`          TINYINT(1)      NOT NULL,

    `type`            varchar(32)     NOT NULL,

    `id_side`         int(10)         NOT NULL,

    `x`               DECIMAL(18, 12) NOT NULL,
    `y`               DECIMAL(18, 12) NOT NULL,
    `width`           DECIMAL(18, 12) NOT NULL,
    `height`          DECIMAL(18, 12) NOT NULL,
    `angle`           DECIMAL(18, 12) NOT NULL,

    `transparency`    TINYINT(3)      NOT NULL,
    `brightness`      INT(10)         NOT NULL,
    `contrast`        INT(10)         NOT NULL,

    `id_color`        INT(10)         NOT NULL DEFAULT -1,
    `color`           varchar(32)     NOT NULL,

    `filter`          varchar(32)     NOT NULL,
    `id_filter`       INT(10)         NOT NULL DEFAULT 0,
    `filter_percent`  INT(10)         NOT NULL DEFAULT 0,

    `svg_width`       DECIMAL(18, 12) NOT NULL,
    `svg_height`      DECIMAL(18, 12) NOT NULL,

    `flip_horizontal` tinyint(1)      NOT NULL,
    `flip_vertical`   tinyint(1)      NOT NULL,

    PRIMARY KEY (`id_design_image`)
) ENGINE = _MYSQL_ENGINE_
  DEFAULT CHARSET = utf8;
