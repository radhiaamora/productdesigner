CREATE TABLE IF NOT EXISTS `__PREFIX_design_color` (
  `id_design_color` int(11) NOT NULL AUTO_INCREMENT,
  `id_design` int(10) NOT NULL,
  `id_color` int(10) NOT NULL DEFAULT -1,
  `color` varchar(32) NOT NULL,
  PRIMARY KEY (`id_design_color`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;