CREATE TABLE IF NOT EXISTS `__PREFIX_side_pricing` (
  `id_side_pricing` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  `cost` DECIMAL(18, 6),
  PRIMARY KEY (`id_side_pricing`, `id_product`, `id_side`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;