CREATE TABLE IF NOT EXISTS `__PREFIX_layer` (
  `id_layer` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_layer_group` int(11) NOT NULL,
  `price` decimal(18,6) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `selected` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_layer`)
) ENGINE=MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_layer_lang` (
  `id_layer` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id_layer`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
