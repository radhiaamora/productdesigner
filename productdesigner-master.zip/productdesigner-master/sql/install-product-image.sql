CREATE TABLE IF NOT EXISTS `__PREFIX_product_image` (
  `id_product_image` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_image` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  `canvas` varchar(64) NOT NULL,
  `mask` varchar(64) NOT NULL,
  `canvas_width` int(10) NOT NULL,
  `canvas_height` int(10) NOT NULL,
  `date_upd` datetime NOT NULL,
  PRIMARY KEY (`id_product_image`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;