CREATE TABLE IF NOT EXISTS `__PREFIX_design_area` (
  `id_design_area` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  `x` DECIMAL (18, 6) NOT NULL,
  `y` DECIMAL (18, 6) NOT NULL,
  `width` DECIMAL (18, 6) NOT NULL,
  `height` DECIMAL (18, 6) NOT NULL,
  PRIMARY KEY (`id_design_area`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;