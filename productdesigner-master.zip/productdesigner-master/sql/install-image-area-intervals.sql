CREATE TABLE IF NOT EXISTS `__PREFIX_image_area_interval` (
  `id_image_area_interval` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `from` decimal(18,2) NOT NULL,
  `to` decimal(18,2) NOT NULL,
  `cost` decimal(18,2) NOT NULL,
  PRIMARY KEY (`id_image_area_interval`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;