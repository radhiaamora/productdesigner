CREATE TABLE IF NOT EXISTS `__PREFIX_help_content` (
  `id_help_content` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_help_content`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_help_content_lang` (
  `id_help_content` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `image_upload_help` TEXT,
  `text_help` TEXT,
  PRIMARY KEY (`id_help_content`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `__PREFIX_help_content` (`id_help_content`) VALUES (1);