CREATE TABLE IF NOT EXISTS `__PREFIX_layer_image` (
  `id_layer_image` int(11) NOT NULL AUTO_INCREMENT,
  `id_layer` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  `image` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `color` varchar(32) NOT NULL,
  PRIMARY KEY (`id_layer_image`)
) ENGINE=MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
