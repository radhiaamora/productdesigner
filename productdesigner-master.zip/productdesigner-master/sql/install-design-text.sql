CREATE TABLE IF NOT EXISTS `__PREFIX_design_text` (
  `id_design_text` int(11) NOT NULL AUTO_INCREMENT,

  `id_design_item` int(10) NOT NULL,

  `type` varchar(32) NOT NULL,

  `id_side` int(10) NOT NULL,

  `x` DECIMAL(18, 12) NOT NULL,
  `y` DECIMAL(18, 12) NOT NULL,
  `width` DECIMAL(18, 12) NOT NULL,
  `height` DECIMAL(18, 12) NOT NULL,
  `angle` DECIMAL(18, 12) NOT NULL,

  `svg_x` DECIMAL(18, 12) NOT NULL,
  `svg_y` DECIMAL(18, 12) NOT NULL,
  `svg_width` DECIMAL(18, 12) NOT NULL,
  `svg_height` DECIMAL(18, 12) NOT NULL,
  `text_x` DECIMAL(18, 12) NOT NULL,
  `text_y` DECIMAL(18, 12) NOT NULL,

  `transparency` TINYINT(3) NOT NULL,
  `curvature` TINYINT(3) NOT NULL,

  `text` TEXT,

  `id_color` INT(10) NOT NULL,
  `color` varchar(32) NOT NULL,
  `id_font` INT(10) NOT NULL,

  `bold` TINYINT(1) NOT NULL,
  `italic` TINYINT(1) NOT NULL,
  `underline` TINYINT(1) NOT NULL,

  `align` varchar(32) NOT NULL,

  `id_outline_color` INT(10) NOT NULL,
  `outline_color` varchar(32) NOT NULL,
  `outline_width` INT(10) NOT NULL,

  `size` INT(10) NOT NULL,

  `path` text,

  PRIMARY KEY (`id_design_text`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;