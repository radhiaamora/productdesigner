CREATE TABLE IF NOT EXISTS `__PREFIX_side_combination_item` (
  `id_side_combination_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_side_combination` int(11) NOT NULL,
  `id_side` int(11) NOT NULL,
  PRIMARY KEY (`id_side_combination_item`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
