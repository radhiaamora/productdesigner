CREATE TABLE IF NOT EXISTS `__PREFIX_design_size` (
  `id_design_size` int(11) NOT NULL AUTO_INCREMENT,
  `id_design` int(10) NOT NULL,
  `width` DECIMAL(18, 6) NOT NULL DEFAULT 0,
  `height` DECIMAL(18, 6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_design_size`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
