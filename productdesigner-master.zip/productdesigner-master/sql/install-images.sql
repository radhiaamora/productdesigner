CREATE TABLE IF NOT EXISTS `__PREFIX_image` (
  `id_image` int(11) NOT NULL AUTO_INCREMENT,
  `id_image_group` int(11) NOT NULL,
  `file` varchar(128) NOT NULL,
  `price` DECIMAL (18, 6) NOT NULL,
  `width` DECIMAL (18, 6) NOT NULL,
  `height` DECIMAL (18, 6) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_image`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_image_lang` (
  `id_image` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id_image`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
