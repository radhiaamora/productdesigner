CREATE TABLE IF NOT EXISTS `__PREFIX_product_pricing` (
  `id_product_pricing` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,

  `product_cost_per_area` DECIMAL(18, 6),

  `text_cost_per_area` DECIMAL(18, 6),
  `text_cost` DECIMAL(18, 6),
  `text_character_cost` DECIMAL(18, 6),
  `text_minimal_cost` DECIMAL(18, 6),
  `texts_total_cost` DECIMAL(18, 6),

  `use_image_cost` tinyint(1) NOT NULL DEFAULT 0,
  `image_cost` DECIMAL(18, 6),
  `image_cost_per_area` DECIMAL(18, 6),
  `upload_cost` DECIMAL(18, 6),
  `upload_cost_per_area` DECIMAL(18, 6),
  `image_minimal_cost` DECIMAL(18, 6),
  `images_total_cost` DECIMAL(18, 6),

  `layers_extra_cost` DECIMAL(18, 6) DEFAULT 0,

  PRIMARY KEY (`id_product_pricing`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
