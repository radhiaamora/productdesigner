CREATE TABLE IF NOT EXISTS `__PREFIX_product_image_group` (
  `id_product_image_group` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_image_group` int(11) NOT NULL,
  PRIMARY KEY (`id_product_image_group`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;