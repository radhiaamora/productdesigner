CREATE TABLE IF NOT EXISTS `__PREFIX_design_preview` (
  `id_design_preview` int(11) NOT NULL AUTO_INCREMENT,
  `id_design` int(10) NOT NULL,
  `id_side` int(10) NOT NULL,
  `file` varchar(128) NOT NULL,
  `preview` varchar(128) NOT NULL,
  `date_add` datetime NOT NULL,
  PRIMARY KEY (`id_design_preview`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
