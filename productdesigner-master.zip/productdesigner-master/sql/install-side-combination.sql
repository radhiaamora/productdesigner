CREATE TABLE IF NOT EXISTS `__PREFIX_side_combination` (
  `id_side_combination` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `cost` DECIMAL(18, 6),
  PRIMARY KEY (`id_side_combination`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
