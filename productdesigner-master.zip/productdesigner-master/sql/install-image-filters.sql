CREATE TABLE IF NOT EXISTS `__PREFIX_image_filter` (
  `id_image_filter` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_filter` int(11) NOT NULL,
  PRIMARY KEY (`id_image_filter`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
