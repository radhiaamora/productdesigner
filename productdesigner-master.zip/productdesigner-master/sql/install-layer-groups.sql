CREATE TABLE IF NOT EXISTS `__PREFIX_layer_group` (
  `id_layer_group` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `required` tinyint(1) NOT NULL,
  `is_design_layer` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_layer_group`)
) ENGINE=MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `__PREFIX_layer_group_lang` (
  `id_layer_group` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id_layer_group`, `id_lang`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;
