CREATE TABLE IF NOT EXISTS `__PREFIX_text_color` (
  `id_text_color` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_color` int(11) NOT NULL,
  PRIMARY KEY (`id_text_color`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;