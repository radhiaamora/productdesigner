const fs = require('fs');
const findInFiles = require('find-in-files');
const {hashCode} = require('../lib/app/src/utils/trans-helper');

const dirs = ['./lib/layers', './lib/app'];

async function find() {
  let search_results;
  let promises = [];
  for (const dir of dirs) {
    promises.push(findInFiles.find({"term": `dsn_trans\\(["'].*?["']\\)`, "flags": "g"}, dir, ".(js|svelte)$"));
  }
  search_results = await Promise.all(promises);
  const results = Object.assign({}, ...search_results);
  const strings = extractStrings(results);
  const php_code = getCode(strings);
  return php_code;
}

function extractStrings(results) {
  const strings = [];
  for (var result in results) {
    var res = results[result];
    for (const match of res.matches) {
      const matches = match.match(/dsn_trans\(["'](.*)["']\)/);
      if (matches && matches[1]) {
        strings.push(matches[1]);
      }
    }
  }
  return strings;
}

function getCode(strings) {
  let hash_map = {};
  strings.map((string) => {
    hash_map[hashCode(string)] = string;
  });
  let code = '// start\n';
  const spaces = '            ';
  for (const hash in hash_map) {
    const string = hash_map[hash];
    let line = `${spaces}'${hash}' => $this->module->l('${string}', $source),\n`;
    if (line.length > 120) {
      line = line.replace('=>', `=>\n${spaces}    `);
    }
    code += line;
  }
  code += spaces + '// end';
  return code;
}

find().then((code) => {
  const file = 'lib/trans/TranslationHelper.php';
  fs.readFile(file, 'utf8', function (err, contents) {
    const new_content = contents.replace(/\/\/ start.*\/\/ end/gms, code);
    fs.writeFile(file, new_content, () => {
    });
  });
});
