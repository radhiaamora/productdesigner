<style>
  .dsn-layer-side {
    display: none;
  }

  .visible {
    display: block;
  }
</style>

<!--suppress ES6UnusedImports, EqualityComparisonWithCoercionJS -->
<script>
  export let layer_side;
  export let layer_groups;
  import LayerGroups from './LayerGroups.svelte';

  let id_side = jQuery(document.body).data('dsn-id-side');
  jQuery.subscribe('switched-side', (_, data) => {
    id_side = +data;
  });
</script>

<div class="dsn-layer-side mdl-card mdl-shadow--2dp" class:visible="{id_side == layer_side.id_side}">
  <LayerGroups id_side={layer_side.id_side} layer_groups={layer_groups} />
</div>
