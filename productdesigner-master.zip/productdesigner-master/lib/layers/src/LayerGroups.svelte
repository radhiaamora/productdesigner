<style>
</style>

<!--suppress ES6UnusedImports, JSUnusedAssignment, UnnecessaryLabelJS, LabeledStatementJS, EqualityComparisonWithCoercionJS -->
<script>
  export let id_side;
  export let layer_groups;
  export let id_expanded = 0;

  import { getContext } from 'svelte';
  import LayerGroup from './LayerGroup.svelte';

  import { reorder } from "./utils/reorder";
  import { dsn_trans } from './utils/trans-helper';

  const store = getContext('store');

  $: ordered_layer_groups = reorder(layer_groups);
  $: first_group = ordered_layer_groups.find(layer_group => +layer_group.active);
  $: id_expanded = first_group ? first_group.id : 0;
  $: $store.id_expanded = id_expanded;

  function expandGroup(event) {
    const id_layer_group = event.detail.id_layer_group;
    if (id_layer_group == id_expanded) {
      id_expanded = 0;
    } else {
      id_expanded = id_layer_group;
    }
  }
</script>

<div class="dsn-layer-groups">
  <div>
    {#each ordered_layer_groups as layer_group (layer_group.id)}
      {#if +layer_group.active}
        <LayerGroup id_side={id_side} layer_group={layer_group} on:clicked={expandGroup} />
      {/if}
    {/each}
  </div>
</div>
