<style>
  .dsn-layer-group {
    margin: 3px 0px 8px;
  }

  .dsn-layer-group:hover .clear-group {
    display: block;
  }

  .dsn-layer-group-title {
    overflow: hidden;
    cursor: pointer;
    font-weight: bold;
    padding: 5px 10px;
    margin: 3px 0px;
  }

  .required, .invalid {
    color: red;
  }

  .dsn-layers {
    padding: 0px 2px;
    display: flex;
    justify-content: flex-start;
    flex-wrap: wrap;
  }

  .clear-group {
    float: right;
    display: none;
    background-color: red;
    color: #fff;
    padding: 0px 5px;
    border-radius: 3px;
    margin-right: 10px;
  }

  .expanded-icon {
    float: right;
  }
</style>

<!--suppress JSUnusedAssignment, UnnecessaryLabelJS, LabeledStatementJS, EqualityComparisonWithCoercionJS -->
<script>
  export let id_side;
  export let layer_group;

  import { getContext } from "svelte";
  import { createEventDispatcher } from "svelte";
  import Layer from "./Layer.svelte";
  import { reorder } from "./utils/reorder";
  import { dsn_trans } from "./utils/trans-helper";

  const store = getContext("store");

  const dispatch = createEventDispatcher();

  $: ordered_layers = reorder(layer_group.layers);
  $: id_expanded = $store.id_expanded;
  $: expanded = layer_group.id == id_expanded;
  $: has_images = checkLayersImages(layer_group.layers);
  $: invalid = $store.invalid.includes(layer_group.id);

  function checkLayersImages(layers) {
    return Object.values(layers).map((layer) => {
      if (+layer.active) {
        const layer_image = layer.layer_images[id_side];
        return layer_image.image_uri;
      }
      return false;
    }).filter(Boolean).length > 0;
  }

  function expandGroup() {
    dispatch("clicked", {
      id_layer_group: layer_group.id
    });
  }

  function clearGroup() {
    store.clearGroup(layer_group.id);
    store.updateInvalidGroups();
  }
</script>

{#if has_images}
  <div class="dsn-layer-group" class:expanded>
    <div class="dsn-layer-group-title" on:click={expandGroup}>
      <span class="dsn-layer-group-label" class:invalid>
        {layer_group.label}
        <span class="required" title={dsn_trans("Required")}>{#if +layer_group.required}*{/if}</span>
      </span>
      <span class="expanded-icon">
        {#if expanded}
          <i class="fa fa-chevron-up"></i>
        {:else}
          <i class="fa fa-chevron-down"></i>
        {/if}
      </span>
      {#if !(+layer_group.required)}
        <a on:click|preventDefault|stopPropagation={clearGroup} href="_" class="clear-group"
           title="{dsn_trans('Remove the selected option in this group')}">
          <i class="fa fa-close"></i> {dsn_trans("Clear")}
        </a>
      {/if}
    </div>
    {#if expanded}
      <div class="dsn-layers">
        {#each Object.values(ordered_layers) as layer (layer.id)}
          {#if +layer.active}
            <Layer id_side={id_side} layer={layer}/>
          {/if}
        {/each}
      </div>
    {/if}
  </div>
{/if}
