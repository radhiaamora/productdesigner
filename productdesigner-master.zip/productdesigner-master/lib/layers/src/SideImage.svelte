<style>
  :global(.dsn-layers-side-image) {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
  .dsn-layer-image {
    position: absolute;
    width: 100%;
    height: 100%;
  }
</style>

<!--suppress ES6UnusedImports, UnnecessaryLabelJS, LabeledStatementJS, EqualityComparisonWithCoercionJS, JSUnusedAssignment -->
<script>
  import { reorder } from "./utils/reorder";

  export let store;
  export let id_side;
  export let design_layer_position;
  export let is_above_design;

  $: selected = $store.selected;
  $: layer_sides = $store.layer_sides;
  $: image_srcs = getImages(selected);
  $: ordered_image_srcs = reorder(image_srcs);
  $: filtered_images = filterImages(image_srcs);

  function getImages(selected) {
    return Object.entries(selected).map(([id_layer_group, {id_layer, position}]) => {
      const layer_group = layer_sides.layer_groups[id_layer_group];
      const layer_image = layer_group.layers[id_layer].layer_images[id_side];
      const image_src = layer_image.image_uri;
      return image_src ? {
        src: image_src,
        position
      } : null;
    }).filter(Boolean);
  }

  function filterImages(images) {
    return images.filter((image) => {
      // if is_above_design and image.above_design are both logically equivalent
      const above_design = image.position > design_layer_position && design_layer_position !== null;
      return is_above_design == above_design;
    });
  }

  function hideLoader() {
    jQuery.publish('hide-loader');
  }
</script>

{#if selected}
  {#each filtered_images as image}
      <img on:load={hideLoader}
           class="dsn-layer-image"
           src="{image.src}"
           alt="Preview"
      />
  {/each}
{/if}
