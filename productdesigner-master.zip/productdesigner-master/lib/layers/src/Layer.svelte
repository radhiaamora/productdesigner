<!--suppress ES6UnusedImports, JSUnusedAssignment, LabeledStatementJS, UnnecessaryLabelJS, EqualityComparisonWithCoercionJS -->
<script>
  export let id_side;
  export let layer;

  import { getContext } from 'svelte';

  import { isLayerSelected } from './utils/store'
  import { dsn_trans } from './utils/trans-helper';

  const store = getContext('store');

  const layer_image = layer.layer_images[id_side];

  const icon_thumb_src = layer_image.icon_thumb_uri;
  const image_src = layer_image.image_uri;

  $: selected = isLayerSelected($store, layer);

  function selectLayer() {
    jQuery.publish('show-loader');
    store.selectLayer(layer);
  }

</script>

{#if image_src}
  <div class="dsn-layer dsn-reactive dsn-lighter" class:selected on:click={selectLayer}>
    <div class="dsn-layer-icon">
      {#if icon_thumb_src}
        <img src="{icon_thumb_src}" alt={dsn_trans("Icon")}>
      {:else}
        <div class="dsn-layer-color" style="background-color:{layer_image.color}"></div>
      {/if}
    </div>
    <div class="dsn-layer-title">
      <div class="dsn-layer-label" title={layer.label}>{layer.label}</div>
      <div class="dsn-layer-price">{layer.display_price}</div>
    </div>
  </div>
{/if}

<style>
  .dsn-layer {
    cursor: pointer;
    display: inline-block;
    width: 78px;
    height: auto;
    vertical-align: middle;
    margin: 2px;
    text-align: center;
  }

  .dsn-layer-title {
    display: inline-block;
  }

  .dsn-layer-icon {
    margin-top: 5px;
    display: inline-block;
    width: 64px;
    height: 64px;
    background-color: #fff;
  }

  .dsn-layer-icon img {
    max-width: 100%;
    max-height: 100%;
  }

  .dsn-layer-label {
    overflow: hidden;
    text-overflow: ellipsis;
    width: 70px;
  }

  .dsn-layer-color {
    width: 100%;
    height: 100%;
  }
</style>
