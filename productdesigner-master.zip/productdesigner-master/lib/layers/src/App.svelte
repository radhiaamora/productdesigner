<style>
  .dsn-layers-list {
    font-size: 11px;
  }
</style>

<script>
  import { onMount, setContext } from "svelte";
  import LayerSide from "./LayerSide.svelte";
  import SideImage from "./SideImage.svelte";

  import { dsn_trans } from "./utils/trans-helper";
  import { createStore } from "./utils/store";
  import { PostHelper } from "./utils/post-helper";

  let store = createStore({
    layer_sides: {},
    id_expanded: 0,
    selected: {},
    invalid: []
  });
  setContext("store", store);
  window.layers_store = store;
  const postHelper = new PostHelper();

  let layer_sides = null;
  let design_layer_position = 0;

  async function getLayerSides() {
    return new Promise(async (resolve) => {
      const response = await postHelper.post(dsn_layers, {
        action: "get_layer_sides",
        no_msg: true
      });
      layer_sides = response.layer_sides;
      store.setLayerSides(layer_sides);
      design_layer_position = getDesignLayerPosition(layer_sides.layer_groups);
      store.setSelected(layer_sides.layer_groups);
      jQuery.publish(dsnTopics.LAYERS_LOADED);
      resolve();
    });
  }

  function getDesignLayerPosition(layer_groups) {
    for (let id_group in layer_groups) {
      if (layer_groups.hasOwnProperty(id_group)) {
        const layer_group = layer_groups[id_group];
        if (+layer_group.is_design_layer) {
          return +layer_group.position;
        }
      }
    }
    return null;
  }

  function mountSideImages() {
    const side_containers = jQuery(".dsn-layers-side-image");
    side_containers.each((index, side_container) => {
      const j_side_container = jQuery(side_container);
      const is_above_design = j_side_container.hasClass("dsn-above-design");
      const id_side = j_side_container.data("id_side");
      new SideImage({
        target: side_container,
        props: {
          store,
          id_side,
          design_layer_position,
          is_above_design
        }
      });
    });
  }

  onMount(async () => {
    await getLayerSides();
    mountSideImages();
    jQuery.publish(dsnTopics.LAYERS_MOUNTED);
  });
</script>

<div class="dsn-layers-list">
  {#if layer_sides}
    {#each Object.values(layer_sides.sides) as layer_side}
      <LayerSide layer_side={layer_side} layer_groups={layer_sides.layer_groups}/>
    {/each}
  {/if}
</div>
