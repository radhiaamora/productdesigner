<style>

  .dsn-side-pricing {
    position: relative;
  }

  :global(.dsn-side-pricing .mdl-data-table) {
    width: 100%;
  }

  :global(.dsn-side-pricing .mdl-spinner) {
    position: absolute;
    top: 5px;
    right: 5px;
    z-index: 1000;
  }

</style>

<script>
  import { afterUpdate } from 'svelte';
  import { PostHelper } from "./utils/post-helper";
  // noinspection ES6UnusedImports
  import { dsn_trans } from "./utils/trans-helper";
  // noinspection ES6UnusedImports
  import {select2} from "./utils/select2";

  const postHelper = new PostHelper();
  let promise = getPricing();
  let pricing = {};

  let product_list = null;
  let copy_images = false;
  let id_source_product = 0;

  let loading = false;

  function getPricing() {
    return new Promise(async(resolve) => {
      const response = await postHelper.post(dsn_controllers.side_pricing, {
        action: "get_pricing",
        no_msg: true
      });
      pricing = response.pricing;
      resolve();
    });
  }

  async function saveSideCost(pricing) {
    loading = true;
    pricing.cost = pricing.cost.replace(",", ".");
    await postHelper.post(dsn_controllers.side_pricing, {
      action: "save_pricing",
      pricing
    });
    loading = false;
  }

  afterUpdate(() => {
    setTimeout(() => {
      componentHandler.upgradeDom();
    });
  });

</script>

<div class="dsn-side-pricing">
  {#await promise}
    <div class="mdl-spinner mdl-js-spinner is-active"></div>
  {:then}
    {#if loading}
      <div class="mdl-spinner mdl-js-spinner is-active"></div>
    {/if}
    <table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
      <thead>
        <tr>
          <th>{dsn_trans("Side")}</th>
          <th>{dsn_trans("Cost")}</th>
        </tr>
      </thead>
      <tbody>
        {#each Object.values(pricing) as side_pricing}
          <tr>
            <td>{side_pricing.side}</td>
            <td>
              <div class="mdl-textfield mdl-js-textfield">
                <input class="mdl-textfield__input" type="text" value="{side_pricing.cost}" on:change="{() => saveSideCost(side_pricing)}" bind:value="{side_pricing.cost}" />
              </div>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  {:catch error}
    <p style="color: red">{error.message}</p>
  {/await}
</div>
