<style>
  .mdl-dialog {
    z-index: 100;
  }
  .mdl-dialog__content {
    margin-bottom: 20px;
  }

  .dsn-close-btn {
    position: absolute;
    top: 0;
    right: 0;
  }

  img {
    max-width: 100%;
    max-height: calc(100vh - 200px);
  }
</style>

<!--suppress ES6UnusedImports, EqualityComparisonWithCoercionJS -->
<script>
  export let src;
  export let layer_image;
  export let name;
  import { createEventDispatcher } from 'svelte';
  import { fade } from 'svelte/transition';
  import { dsn_trans } from '../utils/trans-helper';
  import { modal } from '../utils/modal';

  const dispatch = createEventDispatcher();

  let dialog;
  jQuery.subscribe('open-view-image-modal', (_, data) => {
    if (dialog && layer_image.id_layer == data.id_layer && layer_image.id_side == data.id_side && name == data.name) {
      modal(dialog);
    }
  });

  function closeModal() {
    dispatch('close');
  }
</script>

<dialog class="mdl-dialog fixed" bind:this={dialog} use:modal transition:fade>
  <button on:click={closeModal} class="dsn-close-btn mdl-button mdl-js-button mdl-button--icon mdl-button--accent">
    <i class="material-icons">close</i>
  </button>
  <div class="mdl-dialog__content">
    <img src={src} alt={dsn_trans("Preview")} />
  </div>

  <div class="mdl-dialog__actions">
    <button type="button" class="mdl-button mdl-button--raised mdl-button--accent close" on:click={closeModal}>{dsn_trans("close")}</button>
  </div>
</dialog>
