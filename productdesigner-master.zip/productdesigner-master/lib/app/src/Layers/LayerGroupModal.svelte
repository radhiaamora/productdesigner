<style>
  .mdl-dialog__content {
    margin-bottom: 20px;
  }

  .dsn-close-btn {
    position: absolute;
    top: 0;
    right: 0;
  }
</style>

<!--suppress ES6UnusedImports, EqualityComparisonWithCoercionJS -->
<script>
  export let id_layer_group;

  import { createEventDispatcher, onMount } from 'svelte';
  import { fade } from 'svelte/transition';
  import { dsn_trans } from '../utils/trans-helper';
  import { modal } from '../utils/modal';
  import { PostHelper } from '../utils/post-helper';

  const dispatch = createEventDispatcher();
  const postHelper = new PostHelper();

  let dialog;
  let layer_group;
  let languages;
  let language_img_dir;
  let promise = getLayerGroup();

  async function getLayerGroup() {
    return new Promise(async(resolve) => {
      let response = await postHelper.post(dsn_controllers.layers, {
        action: 'get_layer_group',
        no_msg: true,
        id_layer_group
      });
      layer_group = response.layer_group;
      layer_group.active = +layer_group.active;
      layer_group.required = +layer_group.required;
      languages = response.languages;
      language_img_dir = response.language_img_dir;
      setTimeout(() => {
        componentHandler.upgradeDom();
      });
      resolve();
    });
  }

  function closeModal() {
    dispatch('close');
  }

  function save() {
    dispatch('save', {
      layer_group
    });
  }

  onMount(() => {
    modal(dialog);
  });
</script>


<dialog class="mdl-dialog fixed" bind:this={dialog} use:modal transition:fade>
  <button on:click={closeModal} class="dsn-close-btn mdl-button mdl-js-button mdl-button--icon mdl-button--accent">
    <i class="material-icons">close</i>
  </button>
  <div class="mdl-dialog__content">
  {#await promise}
    <div class="mdl-spinner mdl-js-spinner is-active"></div>
  {:then}
    <div class="mdl-textfield mdl-js-textfield">
      <label class="dsn-label">{dsn_trans("Label")}</label>
      {#each languages as language, index}
      <div class="dsn-field-label-container">
        <input class="mdl-textfield__input"
               type="text"
               onclick="this.select()"
               bind:value={layer_group.label[language.id_lang]}
        >
        <img class="dsn-design-field-flag" alt={language.iso_code} height="11" src="{language_img_dir + language.id_lang}.jpg">
      </div>
      {/each}
    </div>

    <label class="mdl-checkbox mdl-js-checkbox" for="dsn-layer-group-active-{layer_group.id}">
      <input type="checkbox" id="dsn-layer-group-active-{layer_group.id}" class="mdl-checkbox__input" bind:checked={layer_group.active}>
      <span class="mdl-checkbox__label">{dsn_trans("Active")}</span>
    </label>

    <label class="mdl-checkbox mdl-js-checkbox" for="dsn-layer-group-required-{layer_group.id}">
      <input type="checkbox" id="dsn-layer-group-required-{layer_group.id}" class="mdl-checkbox__input" bind:checked={layer_group.required}>
      <span class="mdl-checkbox__label">{dsn_trans("Required")}</span>
    </label>
  {:catch error}
    <p style="color: red">{error.message}</p>
  {/await}
  </div>

  <div class="mdl-dialog__actions">
    <button type="button" class="mdl-button mdl-button--raised mdl-button--colored" on:click={save}>{dsn_trans("save")}</button>
    <button type="button" class="mdl-button mdl-button--raised mdl-button--accent close" on:click={closeModal}>{dsn_trans("close")}</button>
  </div>
</dialog>
