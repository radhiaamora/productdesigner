<style>
  .dsn-layer-groups {
    border-left: 1px solid #EEE;
  }

  .dsn-layer-groups-sortable > :global(.ui-state-highlight) {
    height: 35px;
    margin-bottom: 5px;
  }
</style>

<!--suppress ES6UnusedImports, JSUnusedAssignment, UnnecessaryLabelJS, LabeledStatementJS -->
<script>
  export let id_side;
  import { getContext } from 'svelte';
  import { createEventDispatcher } from 'svelte';
  import LayerGroup from './LayerGroup.svelte';

  import { reorder } from "../utils/reorder";
  import { PostHelper } from '../utils/post-helper';
  import { dsn_trans } from '../utils/trans-helper';

  const store = getContext('store');
  $: layer_groups = $store.layer_groups;
  $: ordered_layer_groups = reorder(layer_groups);

  const postHelper = new PostHelper();

  async function addGroup() {
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'add_layer_group'
    });
    if (response.success) {
      store.updateLayerGroup(response.layer_group);
    }
  }

  async function addDesignLayer() {
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'add_design_layer'
    });
    if (response.success) {
      store.updateLayerGroup(response.layer_group);
    }
  }

  function sortable(node) {
    jQuery(node).sortable({
      placeholder: "ui-state-highlight",
      handle: '.dsn-reorder-layer-group',
      cancel: '',
      stop: () => {
        const order = jQuery(node).sortable("toArray").map((id) => {
          return parseInt(id.replace(`dsn-layer-group-${id_side}-`, ''));
        });
        postHelper.post(dsn_controllers.layers, {
          action: 'reorder_layer_groups',
          order
        }).then((response) => store.updateLayerGroups(response.layer_groups));
      }
    }).disableSelection();
  }
</script>

<div class="dsn-layer-groups">
  <div class="dsn-layer-groups-sortable" use:sortable>
    {#each ordered_layer_groups as layer_group (layer_group.id)}
      <LayerGroup id_layer_group={layer_group.id} id_side={id_side} />
    {/each}
  </div>
  <div style="text-align: right;">
    <button on:click={addDesignLayer} style="margin-right: 10px" title="{dsn_trans('Add a design layer')}" class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary">
      <i class="material-icons">add</i>
    </button>

    <button on:click={addGroup} style="margin-right: 10px" title="{dsn_trans('Add a layer group')}" class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent">
      <i class="material-icons">add</i>
    </button>
  </div>
</div>
