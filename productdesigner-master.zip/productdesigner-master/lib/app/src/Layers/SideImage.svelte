<style>

  .dsn-side-images-container {
    position: relative;
  }

  .dsn_layer_side_canvas {
    max-width: 100%;
    max-height: 100vh;
  }

  .dsn_layer_side_title {
    background: #3f51b5;
    color: #fff;
    height: 35px;
    padding: 5px 10px;
    font-weight: bold;
    text-align: center;
    border-radius: 2px 0px 0px;
  }

  .dsn_layer_image {
    position: absolute;
    top: 0;
    left: 0;
    max-width: 100%;
    max-height: 100%;
  }
</style>

<!--suppress ES6UnusedImports, JSUnusedAssignment, UnnecessaryLabelJS, LabeledStatementJS -->
<script>
  export let layer_side;
  export let layer_groups;

  import { getContext } from 'svelte';

  import { reorder } from "../utils/reorder";

  const store = getContext('store');
  $: layer_groups = $store.layer_groups;
  $: ordered_layer_groups = reorder(layer_groups);

  $: image_srcs = ordered_layer_groups.map((layer_group) => {
    if (!+layer_group.active) {
      return false;
    }

    const layer = Object.values(layer_group.layers).find((layer) => {
      return +layer.selected;
    });

    if (layer) {
      return layer.layer_images[layer_side.id_side].image_uri;
    }

    return false;
  }).filter(Boolean);

</script>

<div class="dsn_layer_side_image">
  {#if layer_side.label}
    <div class="dsn_layer_side_title">{layer_side.label}</div>
  {/if}
  <div class="dsn-side-images-container">
    <img class="dsn_layer_side_canvas" src={layer_side.canvas} alt="canvas" />
    {#each image_srcs as image}
      <img class="dsn_layer_image" src={image} alt="layer" />
    {/each}
  </div>
</div>
