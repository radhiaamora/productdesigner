<style>
  .mdl-dialog__content {
    margin-bottom: 20px;
  }

  .dsn-close-btn {
    position: absolute;
    top: 0;
    right: 0;
  }

  .currency-sign {
    position: absolute;
    top: 13px;
    right: 0;
    color: #757575;
  }
</style>

<!--suppress ES6UnusedImports, EqualityComparisonWithCoercionJS -->
<script>
  export let id_layer;

  import { createEventDispatcher, onMount } from 'svelte';
  import { fade } from 'svelte/transition';
  import { dsn_trans } from '../utils/trans-helper';
  import { modal } from '../utils/modal';
  import { PostHelper } from '../utils/post-helper';

  const dispatch = createEventDispatcher();
  const postHelper = new PostHelper();

  let dialog;
  let layer;
  let languages;
  let language_img_dir;
  let currency_sign;
  let promise = getLayer();

  async function getLayer() {
    return new Promise(async(resolve) => {
      let response = await postHelper.post(dsn_controllers.layers, {
        action: 'get_layer',
        id_layer
      });
      layer = response.layer;
      layer.active = +layer.active;
      layer.price = +layer.price;
      languages = response.languages;
      language_img_dir = response.language_img_dir;
      currency_sign = response.currency_sign;
      setTimeout(() => {
        componentHandler.upgradeDom();
      });
      resolve();
    });
  }

  function closeModal() {
    dispatch('close');
  }

  function save() {
    dispatch('save', {
      layer
    });
  }

  onMount(() => {
    modal(dialog);
  });
</script>

<dialog class="mdl-dialog fixed" bind:this={dialog} use:modal transition:fade>
  <button on:click={closeModal} class="dsn-close-btn mdl-button mdl-js-button mdl-button--icon mdl-button--accent">
    <i class="material-icons">close</i>
  </button>
  <div class="mdl-dialog__content">
  {#await promise}
    <div class="mdl-spinner mdl-js-spinner is-active"></div>
  {:then}
    <div class="mdl-textfield mdl-js-textfield">
      <label class="dsn-label">{dsn_trans("Label")}</label>
      {#each languages as language}
      <div class="dsn-field-label-container">
        <input class="mdl-textfield__input"
               type="text"
               onclick="this.select()"
               bind:value={layer.label[language.id_lang]}
        >
        <img class="dsn-design-field-flag" alt={language.iso_code} height="11" src="{language_img_dir + language.id_lang}.jpg">
      </div>
      {/each}
    </div>

    <div>
      <label class="dsn-label">{dsn_trans("Price")}</label>
      <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
        <input class="mdl-textfield__input dsn-layer-price" type="text" bind:value={layer.price}>
        <span class="currency-sign">{window.currency.sign}</span>
      </div>
    </div>

    <label class="mdl-checkbox mdl-js-checkbox" for="dsn-layer-active-{layer.id}">
      <input type="checkbox" id="dsn-layer-active-{layer.id}" class="mdl-checkbox__input" bind:checked={layer.active}>
      <span class="mdl-checkbox__label">{dsn_trans("Active")}</span>
    </label>
  {:catch error}
    <p style="color: red">{error.message}</p>
  {/await}
  </div>

  <div class="mdl-dialog__actions">
    <button type="button" class="mdl-button mdl-button--raised mdl-button--colored" on:click={save}>{dsn_trans("save")}</button>
    <button type="button" class="mdl-button mdl-button--raised mdl-button--accent close" on:click={closeModal}>{dsn_trans("close")}</button>
  </div>
</dialog>
