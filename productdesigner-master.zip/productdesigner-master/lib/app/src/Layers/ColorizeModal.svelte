<script>
  export let id_layer;

  import { createEventDispatcher, onMount } from "svelte";
  import { fade } from "svelte/transition";
  import { dsn_trans } from "../utils/trans-helper";
  import { modal } from "../utils/modal";
  import { PostHelper } from "../utils/post-helper";

  const dispatch = createEventDispatcher();
  const postHelper = new PostHelper();

  let dialog;
  let promise = getColors();

  let selectedColors = {};

  async function getColors() {
    return new Promise(async (resolve) => {
      let response = await postHelper.post(dsn_controllers.layers, {
        action: "get_colors",
      });
      resolve(response.colors);
    });
  }

  async function generateLayers() {
    const response = await postHelper.post(dsn_controllers.layers, {
      action: "colorize_layer",
      id_layer,
      colors: selectedColors
    });
    closeModal();
    if (response.success) {
      dispatch("generate", {
        layer_group: response.layer_group
      });
    }
  }

  function closeModal() {
    dispatch("close");
  }

  onMount(() => {
    modal(dialog);
  });
</script>

<dialog class="mdl-dialog fixed" bind:this={dialog} use:modal transition:fade>
  <button on:click={closeModal} class="dsn-close-btn mdl-button mdl-js-button mdl-button--icon mdl-button--accent">
    <i class="material-icons">close</i>
  </button>
  <div class="mdl-dialog__content">
    {#await promise}
      <div class="mdl-spinner mdl-js-spinner is-active"></div>
    {:then colors}
      <div>
        <label class="dsn-label">{dsn_trans("Select the colors and textures to apply on this layer")}</label>
        <ul>
          {#each Object.values(colors) as color}
            <li title="{color.label}"
                on:click={() => selectedColors[color.id] = +!selectedColors[color.id]}
                class:selected={selectedColors[color.id]}
                        style="{color.file ? `background-image:url(${window.dsn_data_uri}color/${color.file})` : `background-color:${color.color}`}"></li>
          {/each}
        </ul>
      </div>
    {:catch error}
      <p style="color: red">{error.message}</p>
    {/await}
  </div>

  <div class="mdl-dialog__actions">
    <button type="button" class="mdl-button mdl-button--raised mdl-button--colored"
            on:click={generateLayers}>{dsn_trans("Generate layers")}</button>
    <button type="button" class="mdl-button mdl-button--raised mdl-button--accent close"
            on:click={closeModal}>{dsn_trans("close")}</button>
  </div>
</dialog>

<style>
  .mdl-dialog__content {
    margin-bottom: 20px;
  }

  .dsn-close-btn {
    position: absolute;
    top: 0;
    right: 0;
  }

  ul {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  ul li {
    display: inline-block;
    width: 48px;
    height: 48px;
    margin: 0 5px 5px 0;
    background-size: 100%;
    border: 1px solid #AAA;
  }

  li.selected {
    border: 2px solid #333;
  }
</style>
