<style>

</style>

<!--suppress JSUnusedAssignment, ES6UnusedImports, UnnecessaryLabelJS, LabeledStatementJS -->
<script>
  export let id_side;
  export let id_layer;
  export let id_layer_group;

  import { getContext } from 'svelte';

  import { retreiveFromStore } from "../utils/store";
  import { dsn_trans } from '../utils/trans-helper';
  import { debounce } from '../utils/debounce';
  import { PostHelper } from '../utils/post-helper';

  const store = getContext('store');
  $: layer_image = retreiveFromStore($store, id_layer_group, id_layer, id_side);

  const postHelper = new PostHelper();

  function colorPicker(node) {
    AColorPicker.from(node).on('change', setColor);
    jQuery(node).on('click', (event) => {
      event.stopPropagation();
    });
  }

  const saveColorDebounced = debounce(saveColor, 250);
  jQuery.subscribe('opening-picker', hidePicker);

  let show_picker = false;
  function togglePicker() {
    if (!show_picker) {
      jQuery.publish('opening-picker');
    }
    show_picker = !show_picker;
  }

  function hidePicker() {
    show_picker = false;
  }

  function setColor(picker) {
    layer_image.color = picker.rgbhex;
    saveColorDebounced();
  }

  async function saveColor() {
    await postHelper.post(dsn_controllers.layers, {
      action: 'save_layer_image_color',
      ... layer_image
    });
    store.updateLayerImage(id_layer_group, layer_image);
  }
</script>

<svelte:body on:click={hidePicker} />

<div class="dsn-layer-image" class:show_picker>
  <label>{dsn_trans("Color")}</label>
  <div class="dsn-layer-preview btn-hover-wrap" style="background-color:{layer_image.color};">
    <a href="_" on:click|preventDefault={togglePicker} class="toggle-picker btn-blue btn-hover">
      <i class="material-icons">format_color_fill</i>
    </a>
    <div use:colorPicker
         acp-color="{layer_image.color}"
         acp-show-rgb="no"
         acp-show-hsl="no"
         acp-show-hex="yes"
         acp-palette="PALETTE_MATERIAL_500"
    ></div>
  </div>
</div>
