<style>

  .dsn-layer-group {
    background-color: #EEE;
    padding: 5px 10px;
    margin-bottom: 5px;
  }

  .dsn-layer-group.active {
    background-color: #8bc34a;
    color: #FFF;
  }

  .dsn-design-layer {
    background-color: #3f51b5 !important;
  }

  .dsn-design-layer .dsn-design-layer-hide {
    display: none;
  }

  .dsn-layer-group-title {
    display: grid;
    grid-template-columns: auto 1fr repeat(4, auto);
    align-items: center;
  }

  .dsn-design-layer .dsn-layer-group-title {
    height: 26px;
    grid-template-columns: 1fr repeat(2, auto);
  }

  .dsn-layer-group-label {
    cursor: pointer;
  }

  .required {
    color: red;
  }

  .dsn-layer-group.group_folded {
    height: 35px !important;
    overflow: hidden;
  }

  .dsn-layers-sortable > :global(.ui-state-highlight) {
    height: 127px;
    margin: 5px 0;
  }

  div.file-input {
    position: fixed;
    top: -10000px;
    left: -10000px;
  }

  .mdl-spinner {
    vertical-align: middle;
  }

</style>

<script>
  export let id_layer_group;
  export let id_side;

  import { getContext, afterUpdate, createEventDispatcher } from 'svelte';
  import LayerGroupModal from './LayerGroupModal.svelte';
  import Layer from './Layer.svelte';

  import { reorder } from "../utils/reorder";
  import { retreiveFromStore } from "../utils/store";
  import { retreiveFromStore as retreiveFromFoldedGroupsStore } from "../utils/folded_groups_store";
  import { PostHelper } from '../utils/post-helper';
  import { dsn_trans } from '../utils/trans-helper';

  const store = getContext('store');
  $: layer_group = retreiveFromStore($store, id_layer_group);
  $: layer_group.active = +layer_group.active;
  $: layer_group.required = +layer_group.required;
  $: ordered_layers = reorder(layer_group.layers);

  const groups_store = getContext('groups_store');

  let loading = false;
  let show_modal = false;

  const dispatch = createEventDispatcher();

  const postHelper = new PostHelper();

  async function deleteGroup() {
    if (!confirm(dsn_message.confirm)) {
      return;
    }
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'delete_layer_group',
      id_layer_group: layer_group.id
    });
    if (response.success) {
      store.updateLayerGroups(response.layer_groups);
    }
  }

  async function addLayer() {
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'add_layer',
      id_layer_group: layer_group.id
    });
    store.updateLayer(response.layer);
  }

  let file_input;

  function importImages() {
    file_input.click();
  }

  function upload(node) {
    jQuery(node).ajaxfileupload({
      action: dsn_controllers.layers,
      valid_extensions: ["svg", "png", "jpg", "jpeg"],
      params: {
        action: `save_layers_files`,
        id_layer_group,
        id_side,
        ajax: true
      },
      onStart: () => {
        loading = true;
      },
      onComplete: (response) => {
        loading = false;
        store.updateLayerGroup(response.layer_group);
        showSuccessMessage(dsn_message.success);
        file_input.value = '';
      }
    });
    return {};
  }

  function showModal() {
    show_modal = true;
  }

  function closeModal() {
    show_modal = false;
  }

  async function save(event) {
    const layer_group_data = event.detail.layer_group;
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'save_layer_group',
      layer_group: layer_group_data
    });
    store.updateLayerGroup(response.layer_group);
    closeModal();
  }

  let group_folded = retreiveFromFoldedGroupsStore($groups_store, id_side, id_layer_group);
  function toggleGroup() {
    group_folded = !group_folded;
    groups_store.setGroupFolded(id_side, layer_group.id, group_folded);
  }

  async function toggleActive() {
    layer_group.active = !layer_group.active;
    await postHelper.post(dsn_controllers.layers, {
      action: 'toggle_group_active',
      id_layer_group: layer_group.id
    });
    store.updateLayerGroup(layer_group);
  }

  function sortable(node) {
    jQuery(node).sortable({
      placeholder: "ui-state-highlight",
      handle: '.dsn-reorder-layer',
      cancel: '',
      stop: () => {
        const order = jQuery(node).sortable("toArray").map((id) => {
          return parseInt(id.replace(`dsn-layer-${id_side}-`, ''));
        });
        postHelper.post(dsn_controllers.layers, {
          action: 'reorder_layers',
          id_layer_group: layer_group.id,
          order
        }).then((response) => store.updateLayers(id_layer_group, response.layers));
      }
    }).disableSelection();
  }

  async function copy() {
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'copy_layer_group',
      id_layer_group: layer_group.id
    });
    store.updateLayerGroup(response.layer_group);
  }

  afterUpdate(() => {
    setTimeout(() => {
      componentHandler.upgradeDom();
    });
  });
</script>

<div class="dsn-layer-group btn-hover-wrap" class:active="{+layer_group.active}" class:dsn-design-layer={+layer_group.is_design_layer} id="dsn-layer-group-{id_side}-{layer_group.id}" class:group_folded>
  <div class="dsn-layer-group-title btn-hover-middle">
    <a href="_" title={dsn_trans("Fold/Unfold")} on:click|preventDefault={toggleGroup} class="dsn-design-layer-hide btn-red">
      {#if group_folded}
        <i class="material-icons">keyboard_arrow_down</i>
      {:else}
        <i class="material-icons">keyboard_arrow_up</i>
      {/if}
    </a>
    <span class="dsn-layer-group-label dsn-truncate" on:click={showModal} title={dsn_trans("Edit")}>{layer_group.label}<span class="required" title={dsn_trans("Required")}>{#if layer_group.required}*{/if}</span></span>
    <a href="_" title={dsn_trans("Copy")} on:click|preventDefault={copy} class="btn-blue btn-hover dsn-design-layer-hide">
      <i class="material-icons">content_copy</i>
    </a>
    <a href="_" title={dsn_trans("Enable/Disable")} on:click|preventDefault={toggleActive} class="btn-blue btn-hover dsn-design-layer-hide">
      {#if +layer_group.active}
        <i class="material-icons">check_box</i>
      {:else}
        <i class="material-icons">check_box_outline_blank</i>
      {/if}
    </a>
    <a href="_" title={dsn_trans("Reorder")} class="dsn-reorder-layer-group btn-blue btn-hover">
      <i class="material-icons">reorder</i>
    </a>
    <a href="_" title={dsn_trans("Delete")} on:click|preventDefault={deleteGroup} class="btn-red btn-hover">
      <i class="material-icons">close</i>
    </a>
  </div>
  <div class="dsn-layers">
    <div class="dsn-layers-sortable" use:sortable>
      {#each Object.values(ordered_layers) as layer (layer.id)}
        <Layer id_side={id_side} id_layer_group={layer_group.id} id_layer={layer.id} />
      {/each}
    </div>
    <div style="text-align: right;">
      {#if loading}
        <div class="mdl-spinner mdl-js-spinner is-active"></div>
      {/if}
      <button on:click={importImages} title={dsn_trans("Import layer images")} class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary dsn-design-layer-hide">
        <i class="material-icons">cloud_upload</i>
      </button>
      <button on:click={addLayer} title={dsn_trans("Add a layer")} class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary dsn-add-layer dsn-design-layer-hide">
        <i class="material-icons">add</i>
      </button>
    </div>
  </div>
  <div class="file-input">
    <input type="file" name="images[]" multiple use:upload bind:this={file_input}/>
  </div>
</div>

{#if show_modal}
  <LayerGroupModal id_layer_group={layer_group.id} on:save={save} on:close={closeModal} />
{/if}
