<style>

  .dsn-layer {
    background-color: #DDD;
    padding: 5px 10px;
    margin: 5px 0;
    border: 1px solid #BBB;
  }

  .dsn-layer:hover .dsn-layer-price {
    display: none;
  }

  .dsn-layer.active {
    background-color: #FF9800;
    color: #000;
  }

  .dsn-layer-title {
    display: grid;
    grid-template-columns: auto 1fr repeat(4, auto);
    align-items: center;
  }

  .dsn-layer-label {
    cursor: pointer;
  }

  .dsn-layer-price {

  }

  .dsn-layer-images {
    display: grid;
    grid-template-columns: repeat(3, auto);
  }

  .check {
    margin-bottom: 2px;
    margin-right: 2px;
  }

</style>

<!--suppress ES6UnusedImports, JSUnusedAssignment, LabeledStatementJS, UnnecessaryLabelJS, EqualityComparisonWithCoercionJS -->
<script>
  import ColorizeModal from "./ColorizeModal.svelte";

  export let id_side;
  export let id_layer_group;
  export let id_layer;

  import { getContext } from "svelte";
  import LayerModal from "./LayerModal.svelte";
  import LayerImage from "./LayerImage.svelte";
  import LayerColor from "./LayerColor.svelte";

  import { retreiveFromStore } from "../utils/store";
  import { dsn_trans } from "../utils/trans-helper";
  import { PostHelper } from "../utils/post-helper";

  const store = getContext("store");

  $: layer = retreiveFromStore($store, id_layer_group, id_layer);
  $: layer.active = +layer.active;
  $: layer.selected = +layer.selected;
  $: layer_image = layer.layer_images[id_side] || {};

  let show_colorize_modal = false;
  let show_modal = false;

  const postHelper = new PostHelper();

  async function deleteLayer() {
    if (!confirm(dsn_message.confirm)) {
      return;
    }
    const response = await postHelper.post(dsn_controllers.layers, {
      action: "delete_layer",
      id_layer: layer.id
    });
    if (response.success) {
      store.updateLayers(layer.id_layer_group, response.layers);
    }
  }

  function showModal() {
    show_modal = true;
  }

  function closeModal() {
    show_modal = false;
  }

  async function save(event) {
    const layer_data = event.detail.layer;
    const response = await postHelper.post(dsn_controllers.layers, {
      action: "save_layer",
      layer: layer_data
    });
    store.updateLayer(response.layer);
    closeModal();
  }

  async function toggleActive() {
    layer.active = !layer.active;
    await postHelper.post(dsn_controllers.layers, {
      action: "toggle_layer_active",
      id_layer: layer.id
    });
    store.updateLayer(layer);
  }

  async function toggleSelected() {
    layer.selected = !layer.selected;
    const response = await postHelper.post(dsn_controllers.layers, {
      action: "toggle_layer_selected",
      id_layer: layer.id
    });
    store.updateLayerGroup(response.layer_group);
  }

  function updateLayerGroup(event) {
    const layer_group = event.detail.layer_group;
    store.updateLayerGroup(layer_group);
  }
</script>

<div class="dsn-layer btn-hover-wrap" class:active="{layer.active}" id="dsn-layer-{id_side}-{layer.id}">

  <div class="dsn-layer-title btn-hover-middle">
    <a href="_" on:click|preventDefault={toggleSelected} class="btn-blue btn-small check" title="{dsn_trans('Select layer')}">
      {#if layer.selected}
        <i class="material-icons">radio_button_checked</i>
      {:else}
        <i class="material-icons">radio_button_unchecked</i>
      {/if}
    </a>
    <span class="dsn-layer-label dsn-truncate" on:click={showModal}>{layer.label}</span>
    <span class="dsn-layer-price">{layer.display_price}</span>
    <a href="_" title={dsn_trans("Colorize layer")} on:click|preventDefault={() => show_colorize_modal = true} class="dsn-colorize-layer btn-blue btn-hover">
      <i class="material-icons">palette</i>
    </a>
    <a href="_" title={dsn_trans("Enable/Disable")} on:click|preventDefault={toggleActive} class="btn-blue btn-hover">
      {#if layer.active}
        <i class="material-icons">check_box</i>
      {:else}
        <i class="material-icons">check_box_outline_blank</i>
      {/if}
    </a>
    <a href="_" title={dsn_trans("Reorder")} class="dsn-reorder-layer btn-blue btn-hover">
      <i class="material-icons">reorder</i>
    </a>
    <a href="_" title={dsn_trans("Delete")} on:click|preventDefault={deleteLayer} class="btn-red btn-hover">
      <i class="material-icons">close</i>
    </a>
  </div>

  <div class="dsn-layer-images">

    <LayerImage id_side={id_side} id_layer_group={layer.id_layer_group} id_layer={layer.id} name={"image"} label={dsn_trans("Image")} />

    <LayerImage id_side={id_side} id_layer_group={layer.id_layer_group} id_layer={layer.id} name={"icon"} label={dsn_trans("Icon")} />

    <LayerColor id_side={id_side} id_layer_group={layer.id_layer_group} id_layer={layer.id} />

  </div>
</div>

{#if show_colorize_modal}
  <ColorizeModal id_layer={layer.id} on:close={() => show_colorize_modal = false} on:generate={updateLayerGroup}/>
{/if}

{#if show_modal}
  <LayerModal id_layer={layer.id} on:save={save} on:close={closeModal}/>
{/if}
