<style>
  .dsn-layer-preview img {
    max-width: 100%;
    max-height: 100%;
  }

  input[type=file] {
    position: fixed;
    top: -10000px;
    left: -10000px;
  }

  .delete-image {
    position: absolute;
    top: 0;
    right: 0;
  }

  .view-image {
    position: absolute;
    bottom: 0;
    left: 0;
  }

  .mdl-spinner {
    position: absolute;
    top: 16px;
    left: 16px;
  }
</style>

<!--suppress JSUnusedAssignment, ES6UnusedImports, UnnecessaryLabelJS, LabeledStatementJS, EqualityComparisonWithCoercionJS -->
<script>
  export let id_side;
  export let id_layer;
  export let id_layer_group;
  export let name;
  export let label;

  import { getContext, afterUpdate } from 'svelte';
  import ViewImageModal from './ViewImageModal.svelte';

  import { retreiveFromStore } from "../utils/store";
  import { dsn_trans } from '../utils/trans-helper';
  import { PostHelper } from '../utils/post-helper';

  const store = getContext('store');
  $: layer_image = retreiveFromStore($store, id_layer_group, id_layer, id_side);
  const empty_img = `${window.dsn_uri}views/img/components/image/empty.png`;
  $: image_src = layer_image[`${name}_thumb_uri`] ? layer_image[`${name}_thumb_uri`] + '?' + Math.random() : empty_img;

  const postHelper = new PostHelper();

  let loading = false;
  let view_src = false;
  let view_image = false;
  function viewImage() {
    jQuery.publish('open-view-image-modal', { ... layer_image, name});
    view_image = true;
    view_src = layer_image[`${name}_uri`];
  }

  let file_input;
  function upload(node) {
    jQuery(node).ajaxfileupload({
      action: dsn_controllers.layers,
      valid_extensions: ["svg", "png", "jpg", "jpeg"],
      params: {
        action: `save_layer_${name}_file`,
        id_layer: layer_image.id_layer,
        id_side: layer_image.id_side,
        ajax: true
      },
      onStart: () => {
        loading = true;
      },
      onComplete: (response) => {
        loading = false;
        store.updateLayerImage(id_layer_group, response.layer_image);
        if (response.layer) {
          store.updateLayer(response.layer);
        }
        showSuccessMessage(dsn_message.success);
        file_input.value = '';
      }
    });
    return {};
  }

  function clickUpload(node) {
    const jqNode = jQuery(node);
    jqNode.on('click', () => {
      jqNode.closest('.dsn-layer-preview').find('input[type=file]').trigger('click');
      return false;
    });
  }

  function closeViewImageModal() {
    view_image = false;
  }

  async function deleteImage() {
    if (!confirm(dsn_message.confirm)) {
      return;
    }
    const response = await postHelper.post(dsn_controllers.layers, {
      action: 'delete_layer_image_file',
      name: name,
      id_layer: layer_image.id_layer,
      id_side: layer_image.id_side
    });
    store.updateLayerImage(id_layer_group, response.layer_image);
  }

  jQuery.subscribe('updated_layer_file', (_, data) => {
    data = data.layer_image;
    if (data.id_layer == layer_image.id_layer && data.id_side == layer_image.id_side) {
      layer_image = data;
    }
  });

  afterUpdate(() => {
    setTimeout(() => {
      componentHandler.upgradeDom();
    });
  });
</script>

<div class="dsn-layer-image">
  <label>{label}</label>
  <div class="dsn-layer-preview btn-hover-wrap">
    {#if layer_image[name]}
      <a href="_" on:click|preventDefault={deleteImage} class="delete-image btn-red btn-hover">
        <i class="material-icons">close</i>
      </a>
      <a href="_" on:click|preventDefault={viewImage} class="view-image btn-blue btn-hover">
        <i class="material-icons">zoom_in</i>
      </a>
    {/if}
    <div>
      {#if loading}
        <div class="mdl-spinner mdl-js-spinner is-active"></div>
      {/if}
      <img src={image_src} use:clickUpload alt={dsn_trans("Image")} />
    </div>
    <input type="file" name={name} use:upload bind:this={file_input}/>
  </div>
</div>

{#if view_image}
  <ViewImageModal src={view_src} layer_image={layer_image} name={name} on:close={closeViewImageModal} />
{/if}
