<style>

  .dsn-layer-side {
    display: grid;
    grid-template-columns: 1fr 300px;
    width: calc(100% - 20px);
    margin-bottom: 20px;
    overflow: visible;
    z-index: unset;
  }

</style>

<script>
  export let layer_side;
  export let layer_groups;
  import SideImage from "./SideImage.svelte";
  import LayerGroups from "./LayerGroups.svelte";

  import { dsn_trans } from "../utils/trans-helper";

  dsn_trans;
</script>

{#if layer_side.canvas}
  <div class="dsn-layer-side mdl-card mdl-shadow--2dp">
    <SideImage layer_side={layer_side} layer_groups={layer_groups} />
    <LayerGroups id_side={layer_side.id_side} />
  </div>
{/if}
