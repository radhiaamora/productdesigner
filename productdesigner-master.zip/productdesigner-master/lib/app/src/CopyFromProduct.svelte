<style>

  select {
    width: 350px;
  }

  :global(.dsn-copy-from-product .select2-container--bootstrap) {
    display: inline-block;
  }

  :global(.dsn-copy-from-product .mdl-card) {
    width: 100%;
    min-height: unset;
  }

</style>

<script>
  import { afterUpdate } from 'svelte';
  import { PostHelper } from "./utils/post-helper";
  // noinspection ES6UnusedImports
  import { dsn_trans } from "./utils/trans-helper";
  // noinspection ES6UnusedImports
  import {select2} from "./utils/select2";

  const postHelper = new PostHelper();
  let promise = getProductList();
  let products = {};

  let product_list = null;
  let copy_images = false;
  let id_source_product = 0;

  let loading = false;

  function getProductList() {
    return new Promise(async(resolve) => {
      const response = await postHelper.post(dsn_controllers.bulk_copy, {
        action: 'get_products',
        no_msg: true
      });
      products = response.products;
      resolve();
    });
  }

  async function copyFromProduct() {
    id_source_product = jQuery(product_list).val();
    if (!id_source_product) {
      alert(dsn_trans("Please select a product"));
      return;
    }
    if (!confirm(dsn_trans("This will replace the current product configuration, continue?"))) {
      return;
    }
    loading = true;
    await postHelper.post(dsn_controllers.bulk_copy, {
      ajax: 1,
      action: "copy_product",
      id_target_product: dsn_id_product,
      id_source_product,
      copy_images: copy_images ? 1 : 0,
    });
    loading = false;
  }

  afterUpdate(() => {
    setTimeout(() => {
      componentHandler.upgradeDom();
    });
  });

</script>

<div class="dsn-copy-from-product">
  {#await promise}
    <div class="mdl-spinner mdl-js-spinner is-active"></div>
  {:then}
    {#if loading}
      <div class="mdl-spinner mdl-js-spinner is-active"></div>
    {/if}
    <div class="mdl-card mdl-shadow--2dp">
      <div class="mdl-card__supporting-text">
        <h4>{dsn_trans("Replace the configuration of the current product")}</h4>
        <select use:select2 bind:this={product_list}>
            <option value="0">{dsn_trans("Select a product")}</option>
          {#each products as product}
            <option value="{product.id_product}">{product.label}</option>
          {/each}
        </select>

        <button on:click={copyFromProduct} class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary">
        <i class="material-icons">add</i> {dsn_trans("Copy to the current product")}
        </button>

        <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="copy_images_from_product">
          <input type="checkbox" id="copy_images_from_product" class="mdl-checkbox__input" bind:checked={copy_images}>
          <span class="mdl-checkbox__label">{dsn_trans("Copy images")}</span>
        </label>
      </div>
    </div>
  {:catch error}
    <p style="color: red">{error.message}</p>
  {/await}
</div>
