<style>

  select {
    width: 350px;
  }

  :global(.dsn-copy-to-category .select2-container--bootstrap) {
    display: inline-block;
  }

  :global(.dsn-copy-to-category .mdl-card) {
    width: 100%;
    min-height: unset;
  }

</style>

<script>
  import { afterUpdate } from 'svelte';
  import { PostHelper } from "./utils/post-helper";
  // noinspection ES6UnusedImports
  import { dsn_trans } from "./utils/trans-helper";
  // noinspection ES6UnusedImports
  import {select2} from "./utils/select2";

  const postHelper = new PostHelper();
  let promise = getCategoriesList();
  let categories = {};

  let categories_list = null;
  let copy_images = false;
  let id_target_category = 0;

  let loading = false;

  function getCategoriesList() {
    return new Promise(async(resolve) => {
      const response = await postHelper.post(dsn_controllers.bulk_copy, {
        action: 'get_categories',
        no_msg: true
      });
      categories = response.categories;
      resolve();
    });
  }

  async function copyToCategory() {
    id_target_category = jQuery(categories_list).val();
    if (!id_target_category) {
      alert(dsn_trans("Please select a target category"));
      return;
    }
    if (!confirm(dsn_trans("This will replace the configurations of all products in the selected category, continue?"))) {
      return;
    }
    loading = true;
    await postHelper.post(dsn_controllers.bulk_copy, {
      ajax: 1,
      action: "copy_to_category",
      id_source_product: dsn_id_product,
      id_target_category,
      copy_images: copy_images ? 1 : 0,
    });
    loading = false;
  }

  afterUpdate(() => {
    setTimeout(() => {
      componentHandler.upgradeDom();
    });
  });

</script>

<div class="dsn-copy-to-category">
  {#await promise}
    <div class="mdl-spinner mdl-js-spinner is-active"></div>
  {:then}
    {#if loading}
      <div class="mdl-spinner mdl-js-spinner is-active"></div>
    {/if}
    <div class="mdl-card mdl-shadow--2dp">
      <div class="mdl-card__supporting-text">
        <h4>{dsn_trans("Copy the current configuration to all products of a category")}</h4>
        <select use:select2 bind:this={categories_list}>
            <option value="0">{dsn_trans("Select a category")}</option>
          {#each categories as category}
            <option value="{category.id_category}">{category.id_category} - {category.name}</option>
          {/each}
        </select>

        <button on:click={copyToCategory} class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary">
        <i class="material-icons">add</i> {dsn_trans("Copy to the selected category")}
        </button>

        <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="copy_images_to_category">
          <input type="checkbox" id="copy_images_to_category" class="mdl-checkbox__input" bind:checked={copy_images}>
          <span class="mdl-checkbox__label">{dsn_trans("Copy images")}</span>
        </label>
      </div>
    </div>
  {:catch error}
    <p style="color: red">{error.message}</p>
  {/await}
</div>
