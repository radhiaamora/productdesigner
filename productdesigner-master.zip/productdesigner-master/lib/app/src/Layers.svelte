<style></style>

<!--suppress ES6UnusedImports, UnnecessaryLabelJS, LabeledStatementJS -->
<script>
  import { setContext } from "svelte";
  import LayerSide from "./Layers/LayerSide.svelte";

  import { createStore } from "./utils/store";
  import { createStore as createFoldedGroupsStore } from "./utils/folded_groups_store";
  import { PostHelper } from "./utils/post-helper";
  import { dsn_trans } from "./utils/trans-helper";

  const postHelper = new PostHelper();

  let promise = getLayerSides();
  let layer_sides = {};

  let has_images = true;

  const store = createStore(layer_sides);
  setContext('store', store);

  const groups_store = createFoldedGroupsStore();
  setContext('groups_store', groups_store);

  async function getLayerSides () {
    return new Promise(async(resolve) => {
      const response = await postHelper.post(dsn_controllers.layers, {
        action: 'get_layer_sides',
        no_msg: true
      });
      layer_sides = response.layer_sides;
      store.set(layer_sides);
      has_images = response.has_images;
      resolve();
    });
  }

  // prevent events from bubbling to the upper product form
  function stopClick(event) {
    var tag = event.target.tagName.toLowerCase();
    if (['button', 'i'].includes(tag)) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  dsn_trans;
</script>

<div class="dsn-layers" on:click={stopClick}>
  {#await promise}
    <div class="mdl-spinner mdl-js-spinner is-active"></div>
  {:then}
    {#if has_images}
      {#each Object.values(layer_sides.sides) as layer_side}
        <LayerSide layer_side={layer_side} layer_groups={layer_sides.layer_groups} />
      {/each}
    {:else}
      <div class="module_warning alert alert-warning">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <span>{dsn_trans("Please add a product image then reload this tab")}</span>
      </div>
    {/if}
  {:catch error}
    <p style="color: red">{error.message}</p>
  {/await}
</div>
