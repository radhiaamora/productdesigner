<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tuni-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace lib\trans;

use Context;
use ProductDesigner;

class TranslationHelper
{

    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;
    protected $id_default_lang;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getTranslations()
    {
        $source = 'TranslationHelper';

        return array(
            // start
            '2106261' => $this->module->l('Copy', $source),
            '2106349' => $this->module->l('Cost', $source),
            '2155050' => $this->module->l('Edit', $source),
            '2273433' => $this->module->l('Icon', $source),
            '2576759' => $this->module->l('Side', $source),
            '3522941' => $this->module->l('save', $source),
            '59088909' => $this->module->l('This will replace the current product configuration, continue?', $source),
            '65193517' => $this->module->l('Clear', $source),
            '65290051' => $this->module->l('Color', $source),
            '70760763' => $this->module->l('Image', $source),
            '73174740' => $this->module->l('Label', $source),
            '77381929' => $this->module->l('Price', $source),
            '94756344' => $this->module->l('close', $source),
            '188877356' => $this->module->l('Select a product', $source),
            '281295848' => $this->module->l('Fold/Unfold', $source),
            '315553915' =>
                 $this->module->l('This will replace the configurations of all products in the selected category, continue?', $source),
            '365385018' => $this->module->l('Copy to the selected category', $source),
            '552033443' => $this->module->l('Copy the current configuration to all products of a category', $source),
            '737199437' => $this->module->l('Select layer', $source),
            '825460067' => $this->module->l('Copy images', $source),
            '958869325' => $this->module->l('Add a design layer', $source),
            '1082378784' => $this->module->l('Please select a target category', $source),
            '1346468776' => $this->module->l('Preview', $source),
            '1403821159' => $this->module->l('Remove the selected option in this group', $source),
            '1771694131' => $this->module->l('Add a layer', $source),
            '1955883814' => $this->module->l('Active', $source),
            '1987334337' => $this->module->l('Please add a product image then reload this tab', $source),
            '2043376075' => $this->module->l('Delete', $source),
            '2128986194' => $this->module->l('Add a layer group', $source),
            '-328495169' => $this->module->l('Required', $source),
            '-1374046628' => $this->module->l('Enable/Disable', $source),
            '-1536558885' => $this->module->l('Reorder', $source),
            '-728719198' => $this->module->l('Import layer images', $source),
            '-1952682078' => $this->module->l('Colorize layer', $source),
            '-506217509' => $this->module->l('Select the colors and textures to apply on this layer', $source),
            '-253443539' => $this->module->l('Generate layers', $source),
            '-1680464031' => $this->module->l('Select a category', $source),
            '-261661854' => $this->module->l('Please select a product', $source),
            '-830604139' => $this->module->l('Replace the configuration of the current product', $source),
            '-494095521' => $this->module->l('Copy to the current product', $source),
            // end
        );
    }
}
