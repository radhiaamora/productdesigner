const fs = require("fs-extra");
const gulp = require("gulp");
const insert = require("gulp-insert");
const uglify = require("gulp-uglify");
const pump = require("pump");
const clean = require("gulp-clean");
const zip = require("gulp-zip");
const lec = require("gulp-line-ending-corrector");
const debug = require("gulp-debug");
const sftp = require("gulp-sftp");
const replace = require("gulp-replace");
const md5File = require("md5-file");
const branchName = require('current-git-branch');
const merge = require('merge-stream');
const config = require('./config');

gulp.task("copy-plugins", function(cb) {
  return pump([
      gulp.src(["views/ts/plugins/**/*.js"]),
      uglify(),
      insert.prepend(fs.readFileSync("./LICENSE")),
      gulp.dest("views/js/plugins/"),
    ],
    cb,
  );
});

gulp.task("watch:plugins", function() {
  gulp.watch(["views/ts/plugins/**/*.js"], gulp.series("copy-plugins"));
});

gulp.task("copy-css", function(cb) {
  return pump([
      gulp.src(["views/scss/admin/css/*.css"]),
      gulp.dest("views/css/admin/"),
    ],
    cb,
  );
});

gulp.task("copy-color-theme", function(cb) {
  return pump([
      gulp.src(["views/scss/front/color_theme.scss"]),
      gulp.dest("views/css/front/"),
    ],
    cb,
  );
});

gulp.task("save-color-theme-hash", function(cb) {
  return pump([
      gulp.src(["classes/models/DesignerColorTheme.php"]),
      debug(),
      replace(/const HASH \= '.*?';/, `const HASH = '${md5File.sync("views/scss/front/color_theme.scss")}';`),
      gulp.dest("classes/models/"),
    ],
    cb,
  );
});

gulp.task("copy", gulp.series(
  "copy-plugins",
  "copy-css",
  "copy-color-theme",
  "save-color-theme-hash",
));

gulp.task("post-prod", gulp.series(
  "copy-plugins",
));

gulp.task("clean", function(cb) {
  pump([
      gulp.src(["views/js/*", "views/css/*"]),
      clean(),
    ],
    cb,
  );
});

gulp.task("archive", function() {
  const branch = branchName();
  const zipname = `${config.module_name}${branch !== 'master' ? `-${branch}` : ''}.zip`;
  const rules = fs.readFileSync(".nozip").toString().split("\n").map((s) => '!' + s.trim()).filter(Boolean);
  return gulp.src(["**", ...rules], {base: "../"})
    .pipe(zip(zipname))
    .pipe(gulp.dest(config.versions_dir));
});

gulp.task('copy-e2e', function () {
  let modules_dir = `${config.e2e_dir}/modules`;
  const rules = fs.readFileSync(".copy").toString().split("\n").map((s) => "!" + s.trim());

  const copy_module = gulp.src(['**','.*','**/.*','.*/**', ...rules], {base: '../'})
    .pipe(gulp.dest(modules_dir), {
      overwrite: true
    });
  const copy_files = gulp.src(['./cypress/fixtures/copy/**'])
    .pipe(gulp.dest(config.e2e_dir), {
      overwrite: true
    });
  return merge([copy_module, copy_files]);
});

gulp.task("fix:php", function(cb) {
  gulp.src(["./**/*.php"])
    .pipe(lec())
    .pipe(gulp.dest("./"));
  return cb;
});

gulp.task("upload", function() {
  return gulp.src("views/js/sourcemap/*")
    .pipe(sftp({
      host: "ssd.net", // from hosts file
      user: "presta",
      remotePath: "/srv/www/psdesigner/public_html/sourcemap/",
    }));
});

gulp.task("default", gulp.series("post-prod"));
