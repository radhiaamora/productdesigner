const devMode = process.env.NODE_ENV !== "production";

const plugins = {
  "rucksack-css": {},
  "autoprefixer": {},
  "css-mqpacker": {}
};

if (!devMode) {
  plugins["cssnano"] = {};
}

module.exports = {
  plugins
};
