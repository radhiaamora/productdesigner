<?php
/**
 * 2010-2020 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2010-2020 PrestaShop SA
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

/** @noinspection PhpUnused */

use classes\color_manager\ColorManager;
use classes\designer\Designer;
use classes\DesignerTools;
use classes\helpers\BulkCopyHelper;
use classes\helpers\DesignHelper;
use classes\helpers\OrdersHelper;
use classes\models\design\Design;
use classes\models\DesignerConfig;
use classes\models\DesignerProductConfig;
use classes\models\DesignerUserUpload;
use classes\module\Cache as DesignerCache;
use classes\module\Calculator as DesignerCalculator;
use classes\module\Handler;
use classes\module\Media as DesignerMedia;
use classes\module\Messenger;
use classes\module\Presenter;
use classes\module\Processor;
use classes\module\Provider;
use classes\module\State;
use classes\module\Summary;
use classes\module\Viewer;
use classes\panels\configuration\ConfigurationPanel;
use classes\panels\product\ProductPanel;

/**
 * @property bool bootstrap
 * @property string author_address
 */
class ProductDesigner extends Module
{

    /** @var Handler */
    public $handler;

    /** @var Provider */
    public $provider;

    /** @var DesignerCalculator */
    public $calculator;

    /** @var Messenger */
    public $messenger;

    /** @var Summary */
    public $summary;

    /** @var State */
    public $state;

    /** @var DesignerMedia */
    public $media;

    /** @var DesignerCache */
    public $cache;

    protected $duplicate_order = true;
    private $confirmUninstall;

    public $hooks = array(
        'displayProductAdditionalInfo',
        'displayCustomization',
        'displayFooterProduct',
    );

    public function __construct()
    {
        $this->name = 'productdesigner';
        $this->tab = 'front_office_features';
        $this->version = '1.15.0';
        $this->author = 'Tuni-Soft';
        $this->module_key = '88b85923ab8a362768d7ac4a6f2180e0';
        $this->author_address = '0xD70c56348A5C492162492e0520F09d06e4d8fa7a';
        $this->need_instance = 1;

        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Product Designer');
        $this->description = $this->l('Allow your clients to design, preview and order their customized products');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->registerAutoload();
        $this->initHelpers();

        /** @noinspection UnusedConstructorDependenciesInspection */
        $this->confirmUninstall = $this->l(
            'All data associated with the module will be lost! Are you sure you want to proceed ?',
            DesignerTools::getSource()
        );
    }

    private function registerAutoload()
    {
        spl_autoload_register(array(__CLASS__, 'autoloadClass'));
    }

    public static function autoloadClass($class_name)
    {
        $class_name = str_replace('\\', '/', $class_name);
        $class_path = dirname(__FILE__) . '/' . $class_name . '.php';
        if (is_file($class_path)) {
            require_once $class_path;
            return;
        }

        // libs folder
        $class_path = dirname(__FILE__) . '/libs/' . $class_name . '.php';
        if (is_file($class_path)) {
            require_once $class_path;
            return;
        }
    }

    public function getDir()
    {
        return realpath(dirname(__FILE__)) . DIRECTORY_SEPARATOR;
    }

    public function getFile()
    {
        return __FILE__;
    }

    private function initHelpers()
    {
        $this->handler = new Handler($this, $this->context);
        $this->provider = new Provider($this, $this->context);
        $this->calculator = new DesignerCalculator($this, $this->context);
        $this->messenger = new Messenger($this, $this->context);
        $this->summary = new Summary($this, $this->context);
        $this->state = new State($this, $this->context);
        $this->media = new DesignerMedia($this, $this->context);
        $this->cache = new DesignerCache($this, $this->context);
    }

    public function install()
    {
        if (!$this->handler->execSQLScripts()) {
            return false;
        }

        if (!$this->handler->installDataPresets()) {
            return false;
        }

        if (!$this->handler->installDataDirs()) {
            return false;
        }

        if (!$this->handler->installControllers()) {
            return false;
        }

        if (!parent::install()) {
            return false;
        }

        if (!$this->handler->installHooks()) {
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        if (!$this->handler->execUninstallScript()) {
            return false;
        }
        if (!$this->handler->uninstallControllers()) {
            return false;
        }
        return parent::uninstall();
    }

    public function getContent()
    {
        $this->postProcess();

        $output = '';

        $output .= $this->messenger->getMessages();

        $presenter = new Presenter($this, $this->context);
        $update_action = $presenter->getCurrentAction();
        if ($update_action) {
            return $output . $presenter->displayUpdateForm($update_action);
        }

        $viewer = new Viewer($this, $this->context);
        $view_action = $viewer->getCurrentAction();
        if ($view_action) {
            return $output . $viewer->display($view_action);
        }

        $output .= $this->getConfigurationForm();

        return $output;
    }

    private function getConfigurationForm()
    {
        $configuration_panel = new ConfigurationPanel($this, $this->context);
        return str_replace(
            '<configuration />',
            $configuration_panel->getContent(),
            $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configuration.tpl')
        );
    }

    protected function postProcess()
    {
        $processor = new Processor($this, $this->context);

        $position_action = $processor->getPositionAction();
        if ($position_action) {
            return $processor->processPosition();
        }

        $process_action = $processor->getCurrentAction('submit');
        if ($process_action) {
            return $processor->processSubmit($process_action);
        }

        $delete_action = $processor->getCurrentAction('delete');
        if ($delete_action) {
            /** @noinspection PhpVoidFunctionResultUsedInspection */
            return $processor->processDelete($delete_action);
        }

        $status_action = $processor->getCurrentAction('status');
        if ($status_action) {
            /** @noinspection PhpVoidFunctionResultUsedInspection */
            return $processor->processStatus($status_action);
        }
        return null;
    }

    public function hookActionAuthentication($params)
    {
        if (isset($params['customer']) && Validate::isLoadedObject($params['customer'])) {
            $id_customer = (int)$params['customer']->id;
            $id_guest = $this->provider->getGuest();
            DesignerUserUpload::transferUploadsToCustomer($id_guest, $id_customer);
        }
    }

    public function hookActionCartSave()
    {
        if ($this->duplicate_order && Tools::getIsset('submitReorder')) {
            $id_order_old = (int)Tools::getValue('id_order');
            $cookie = new Cookie('reorder');
            $cookie->setExpire(time() + 20 * 60);
            $cookie->id_order_old = $id_order_old;
            $cookie->write();
            $this->duplicate_order = false;
        }
    }

    public function hookDisplayHeader()
    {
        $this->hookReorder();

        Media::addJsDef(array(
            'dsn_id_module' => $this->id
        ));

        $controller = Tools::getValue('controller');
        if ($controller === 'product') {
            $id_product = (int)Tools::getValue('id_product');
            if (DesignerProductConfig::isActive($id_product)) {
                $this->media->addProductFooterMedia($id_product);
                if (Tools::getIsset('color_theme')) {
                    $this->media->addColorManagerMedia();
                }
            }
        }
        if ($this->provider->shouldDisplaySummary($controller)) {
            $this->media->addSummaryMedia();
        }

        // add firebug
        if (DesignerTools::isModuleDevMode() && DesignerTools::isIE() && DesignerTools::shouldAddFirebug()) {
            $this->media->addFirebug();
        }
    }

    public function hookDisplayProductAdditionalInfo()
    {
        $is_quickview = Tools::getValue('action') === 'quickview';
        $id_product = (int)Tools::getValue('id_product');
        if (DesignerProductConfig::isActive($id_product)) {
            $this->smarty->assign(array(
                'dsn_config'       => DesignerConfig::getConfig(),
                'product_config'   => DesignerProductConfig::getByProductID($id_product),
                'module_dir'       => $this->provider->getModuleDirUri(),
                'is_quickview'     => $is_quickview,
                'product_link'     => $this->provider->getProductLink($id_product, null, array(
                    'designer_scroll' => 1
                )),
                'hide_cart_button' => DesignerProductConfig::shouldHideCartButton($id_product)
            ));
            return $this->display(__FILE__, 'views/templates/hook/front/product-button.tpl');
        }
        return null;
    }

    public function hookDisplayLeftColumnProduct()
    {
        return $this->hookDisplayProductAdditionalInfo();
    }

    public function hookDisplayRightColumnProduct()
    {
        return $this->hookDisplayProductAdditionalInfo();
    }

    private $displayed_designer = false;

    public function hookDisplayFooterProduct()
    {
        if ($this->displayed_designer) {
            return null;
        }
        $this->displayed_designer = true;

        $id_product = (int)Tools::getValue('id_product');
        if (DesignerProductConfig::isActive($id_product)) {
            $output = '';
            $designer = new Designer($this, $this->context, $id_product);
            $designer->assignTplVars();
            $output .= $this->display(__FILE__, 'views/templates/hook/front/product-footer.tpl');

            $colorManager = new ColorManager($this, $this->context);
            if ($colorManager->isEnabled()) {
                $colorManager->assignTplVars();
                $output .= $this->display(__FILE__, 'views/templates/hook/front/color-manager.tpl');
            }
            return $output;
        }
        return null;
    }

    public function hookProductDesigner()
    {
        return $this->hookDisplayFooterProduct();
    }

    public function hookDisplayCustomization($params)
    {
        if (!isset($params['customization'])) {
            return false;
        }
        $controller = Tools::getValue('controller');

        $customization = $params['customization'];
        $id_design = (int)$customization['value'];
        $design = new Design($id_design);

        // if no corresponding design, return the original value
        if (!Validate::isLoadedObject($design)) {
            return $customization['value'];
        }

        $is_submit_state = Tools::isSubmit('submitState');

        if ($is_submit_state || in_array($controller, array('AdminPdf', 'pdfinvoice', 'validation'))) {
            return $this->summary->displayPdfSummary($design);
        }

        if ($controller === 'AdminOrders' || $controller === 'AdminCarts') {
            return $this->summary->displayAdminSummary($design);
        }

        return $this->summary->displayCartSummary($design);
    }

    public function hookDisplayBackOfficeHeader()
    {
        $controller = Tools::getValue('controller');

        if (Tools::getValue('configure') === $this->name) {
            Media::addJsDef(array(
                'currentIndex'    => $this->provider->getModuleAdminLink(),
                'dsn_data_uri'    => $this->provider->getDataDirUri(),
                'dsn_config'      => $this->provider->getControllerAdminLink('DsnConfig'),
                'dsn_extra'       => $this->provider->getControllerAdminLink('DsnProductExtra'),
                'dsn_color_theme' => $this->provider->getControllerAdminLink('DsnColorTheme'),
            ));
        }

        if ($controller === 'AdminProducts') {
            Media::addJsDef(array(
                'dsn_uri'              => $this->provider->getModuleDirUri(),
                'dsn_enabled_products' => DesignerProductConfig::getEnabledProducts(),
                'dsn_extra'            => $this->provider->getControllerAdminLink('DsnProductExtra'),
                'dsn_product_image'    => $this->provider->getControllerAdminLink('DsnProductImages'),
                'dsn_product_tab'      => $this->provider->getControllerAdminLink('DsnDesignTabs'),
                'dsn_product_config'   => $this->provider->getControllerAdminLink('DsnProductConfig'),
                'dsn_product_pricing'  => $this->provider->getControllerAdminLink('DsnProductPricing'),
                'dsn_product_areas'    => $this->provider->getControllerAdminLink('DsnProductAreas'),
                'dsn_product_fields'   => $this->provider->getControllerAdminLink('DsnProductFields'),
                'dsn_real_size'        => $this->provider->getControllerAdminLink('DsnRealSize')
            ));
        }

        if ($controller === 'AdminOrders') {
            $orders_helper = new OrdersHelper($this, $this->context);
            Media::addJsDef(array(
                'dsn_orders' => $orders_helper->getCustomizedOrders(),
            ));
        }

        // add firebug
        if (DesignerTools::isModuleDevMode() && DesignerTools::isIE() && DesignerTools::shouldAddFirebug()) {
            $this->media->addFirebugAdmin();
        }
    }

    /** @noinspection PhpUnused */
    public function hookActionAdminControllerSetMedia()
    {
        $controller = Tools::getValue('controller');

        Media::addJsDef(array(
            'dsn_id_module' => $this->id
        ));

        if ($controller === 'AdminProducts') {
            $id_product = $this->provider->getCurrentProductID();
            $this->media->addProductsExtraMedia($id_product);
            $this->media->addProductsListMedia();
        }

        if ($controller === 'AdminOrders') {
            $this->media->addOrdersMedia();
        }

        if ($controller === 'AdminModules' && Tools::getValue('configure') === $this->name) {
            $this->media->addConfigurationMedia();
        }
    }

    /** @noinspection PhpUnused */
    public function hookDisplayAdminProductsExtra($params)
    {
        $id_product = (int)$params['id_product'];
        $this->state->set('id_product', $id_product);
        $this->smarty->assign(array(
            'id_product' => $id_product,
        ));
        $product_panel = new ProductPanel($this, $this->context);
        return $product_panel->getContent();
    }

    private function hookReorder()
    {
        $cookie = new Cookie('reorder');
        if (!isset($cookie->id_order_old) || !(int)$cookie->id_order_old) {
            return false;
        }
        $id_cart = $this->provider->getCart();
        $id_order_old = (int)$cookie->id_order_old;
        $id_cart_old = Order::getCartIdStatic($id_order_old);
        DesignHelper::reorderDesigns($id_cart, $id_cart_old);
        unset($cookie->id_order_old);
        $cookie->logout();
        return null;
    }

    public function hookActionObjectProductAddAfter($params)
    {
        if ($this->provider->isDuplicateRequest()) {
            $id_source_product = (int)$this->provider->getProductIdFromDuplicateRequest();
            $id_target_product = (int)$params['object']->id;
            $bulk_copy_helper = new BulkCopyHelper($this, $this->context);
            $bulk_copy_helper->copyProduct($id_target_product, $id_source_product);
        }
    }

    public function hookActionObjectImageAddAfter($params)
    {
        if ($this->provider->isDuplicateRequest()) {
            $id_source_product = (int)$this->provider->getProductIdFromDuplicateRequest();
            $id_target_product = (int)$params['object']->id_product;
            $id_source_image = (int)$params['object']->id_image;
            $id_target_image = (int)$params['object']->id;
            $bulk_copy_helper = new BulkCopyHelper($this, $this->context);
            $bulk_copy_helper->copyImage($id_target_product, $id_source_product, $id_target_image, $id_source_image);
        }
    }
}
