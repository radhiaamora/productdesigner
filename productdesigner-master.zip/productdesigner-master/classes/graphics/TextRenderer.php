<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\graphics;

use Context;
use ProductDesigner;
use Tools;

class TextRenderer
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param $text
     * @param $font_path
     * @param $font_size
     * @param $measure
     * @return resource
     */
    public function renderText($text, $font_path, $font_size, $font_color, $measure)
    {
        $gd_image = imagecreatetruecolor($measure['width'], $measure['height']);
        $transparent = imagecolorallocatealpha($gd_image, 0, 0, 0, 127);
        imagefill($gd_image, 0, 0, $transparent);
        imagesavealpha($gd_image, true);
        $color = $this->getGDColor($gd_image, $font_color);
        imagettftext($gd_image, $font_size, 0, $measure['x'], $measure['y'], $color, $font_path, $text);
        return $gd_image;
    }

    public function getGDColor($gd_image, $color)
    {
        if (Tools::strlen($color) === 4) {
            $color = $this->getFullHexColor($color);
        }
        list($red, $green, $blue) = sscanf($color, "#%02x%02x%02x");
        return imagecolorallocate($gd_image, $red, $green, $blue);
    }

    private function getFullHexColor($color)
    {
        return '#' . $color[1] . $color[1] . $color[2] . $color[2] . $color[3] . $color[3];
    }

    /**
     * @param resource $gd_image
     * @param $path
     * @return bool
     */
    public function saveImage($gd_image, $path)
    {
        return imagepng($gd_image, $path, 9);
    }
}
