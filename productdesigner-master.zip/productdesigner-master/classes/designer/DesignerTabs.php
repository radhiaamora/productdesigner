<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\designer;

use classes\DesignerTools;
use classes\models\DesignerConfig;
use classes\models\DesignerProductConfig;
use classes\models\DesignerProductTab;

class DesignerTabs
{
    public static function getActiveTabs($id_product)
    {
        $active_tabs = array();

        $config = $product_config = DesignerProductConfig::getByProductID($id_product);
        if ($product_config->tabs_use_global_config) {
            $id_product = 0;
            $config = DesignerConfig::getConfig();
        }

        $tabs_list = self::getTabsList(true);
        if ($config->enable_all_tabs) {
            $active_tabs = $tabs_list;
        }
        $product_tabs = DesignerProductTab::getValuesByProduct($id_product);

        foreach ($tabs_list as $tab_name => $tab) {
            if (isset($product_tabs[$tab['id']])) {
                $active_tabs[$tab_name] = $tab;
            }
        }

        if ($product_config->enable_layers) {
            $active_tabs['options'] = $tabs_list['options'];
        } else {
            unset($active_tabs['options']);
        }

        if ($product_config->enable_product_colors ||
            $product_config->enable_product_size) {
            $active_tabs['product'] = $tabs_list['product'];
        } else {
            unset($active_tabs['product']);
        }

        $active_tabs = self::activateInitialTab($active_tabs, $config->initial_tab);
        return $active_tabs;
    }

    public static function getTabsList($all = false)
    {
        $module = DesignerTools::getModule();
        $source = DesignerTools::getSource();
        $tabs = array(
            'product' => array(
                'id'      => 4,
                'label'   => $module->l('Product', $source),
                'skipped' => true,
            ),
            'options' => array(
                'id'      => 3,
                'label'   => $module->l('Options', $source),
                'skipped' => true,
            ),
            'text'    => array(
                'id'    => 1,
                'label' => $module->l('Text', $source),
            ),
            'image'   => array(
                'id'    => 2,
                'label' => $module->l('Image', $source),
            ),
        );
        if (!$all) {
            foreach ($tabs as $tab_name => $tab) {
                if (isset($tab['skipped']) && $tab['skipped']) {
                    unset($tabs[$tab_name]);
                }
            }
        }
        return $tabs;
    }

    public static function activateInitialTab($active_tabs, $initial_tab)
    {
        $active_tabs = array_map(function ($item) {
            $item['active'] = 0;
            return $item;
        }, $active_tabs);

        foreach ($active_tabs as &$active_tab) {
            if (!$initial_tab) {
                // if no initial, activate the first tab and return
                $active_tab['active'] = 1;
                return $active_tabs;
            }
            if ((int)$active_tab['id'] === (int)$initial_tab) {
                $active_tab['active'] = 1;
                return $active_tabs;
            }
        }

        // no tab was activated, activate the first tab
        foreach ($active_tabs as &$active_tab) {
            $active_tab['active'] = 1;
            return $active_tabs;
        }

        return $active_tabs;
    }
}
