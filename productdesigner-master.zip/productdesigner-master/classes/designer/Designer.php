<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\designer;

use classes\DesignerTools;
use classes\helpers\ProductImageHelper;
use classes\models\design\Design;
use classes\models\DesignerArea;
use classes\models\DesignerColor;
use classes\models\DesignerConfig;
use classes\models\DesignerField;
use classes\models\DesignerFilter;
use classes\models\DesignerFont;
use classes\models\DesignerHelpContent;
use classes\models\DesignerImageColor;
use classes\models\DesignerImageFilter;
use classes\models\DesignerImageGroup;
use classes\models\DesignerProductColor;
use classes\models\DesignerProductConfig;
use classes\models\DesignerProductFont;
use classes\models\DesignerProductImageGroup;
use classes\models\DesignerProductSide;
use classes\models\DesignerTextColor;
use classes\models\DesignerUserUpload;
use Context;
use Media;
use ProductDesigner;
use Tools;

class Designer
{

    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;
    private $id_product;

    private $id_lang;

    /** @var DesignerProductConfig $product_config */
    private $product_config;

    public function __construct($module, $context, $id_product)
    {
        $this->module = $module;
        $this->context = $context;
        $this->id_product = $id_product;
        $this->id_lang = $this->context->language->id;
    }

    public function assignTplVars()
    {
        $variants_tpl_path = _PS_THEME_DIR_ . 'templates/catalog/_partials/product-variants.tpl';
        if (!is_file($variants_tpl_path)) {
            $variants_tpl_path = _PS_PARENT_THEME_DIR_ . 'templates/catalog/_partials/product-variants.tpl';
        }

        $product_image_helper = new ProductImageHelper($this->module, $this->context);
        $product_images = $product_image_helper->getProductImages($this->id_product);

        $this->context->smarty->assign(array(
            'designer'        => $this,
            'dsn_config'      => DesignerConfig::getConfig(),
            'tabs'            => $this->getActiveTabs($this->id_product),
            'product_config'  => $this->getProductConfig(),
            'product_colors'  => $this->getProductColors(),
            'text_colors'     => $this->getTextColors(),
            'image_colors'    => $this->getImageColors(),
            'image_filters'   => $this->getImageFilters(),
            'fonts'           => $this->getProductFonts(),
            'image_groups'    => $this->getProductImageGroups(),
            'sides'           => $this->getProductSides(),
            'design_areas'    => $this->getProductAreas(),
            'design_fields'   => $this->getProductFields(),
            'help_content'    => DesignerHelpContent::getHelpContent($this->context->language->id),
            'images_dir'      => $this->module->provider->getModuleDirUri('views/img'),
            'dsn_user_upload' => $this->context->link->getModuleLink($this->module->name, 'userupload'),
            'dsn_admin'       => $this->module->provider->isAdmin(),
            'variants_tpl'    => is_file($variants_tpl_path) ? $variants_tpl_path : false,
            'has_images'      => count($product_images),
            'dsn_tpl_home'    => $this->module->provider->getModuleDirPath('views/templates'),
        ));

        if ($this->product_config->allow_upload) {
            $this->context->smarty->assign(array(
                'user_uploads' => DesignerUserUpload::getUserUploads()
            ));
        }
    }

    public function getActiveTabs($id_product)
    {
        return DesignerTabs::getActiveTabs($id_product);
    }

    public function getProductConfig()
    {
        if ($this->product_config) {
            return $this->product_config;
        }
        return $this->product_config = DesignerProductConfig::getByProductID($this->id_product);
    }

    public function getTextColors()
    {
        if ($this->product_config->enable_all_text_colors) {
            return DesignerColor::getActive();
        }
        return DesignerTextColor::getColors($this->id_product, $this->id_lang);
    }

    public function getImageColors()
    {
        if ($this->product_config->enable_all_image_colors) {
            return DesignerColor::getActive();
        }
        return DesignerImageColor::getColors($this->id_product, $this->id_lang);
    }

    public function getImageFilters()
    {
        if ($this->product_config->enable_all_image_filters) {
            return DesignerFilter::getAll();
        }
        return DesignerImageFilter::getFilters($this->id_product);
    }

    public function getProductColors()
    {
        if ($this->product_config->enable_all_product_colors) {
            return DesignerColor::getActive();
        }
        return DesignerProductColor::getColors($this->id_product, $this->id_lang);
    }

    public function getProductFonts()
    {
        if ($this->product_config->enable_all_fonts) {
            return DesignerFont::getActive();
        }
        return DesignerProductFont::getProductFonts($this->id_product, $this->id_lang);
    }

    public function getProductImageGroups()
    {
        if ($this->product_config->enable_all_image_groups) {
            return DesignerImageGroup::getActive();
        }
        return DesignerProductImageGroup::getProductImageGroups($this->id_product, $this->id_lang);
    }

    private function getProductSides()
    {
        return DesignerProductSide::getProductSidesWithDefault($this->id_product, $this->id_lang);
    }

    private function getProductAreas()
    {
        return DesignerArea::getProductAreasWithDefaults($this->id_product);
    }

    private function getProductFields()
    {
        return DesignerField::getProductFields($this->id_product, $this->context->language->id);
    }

    public function addVariables()
    {
        Media::addJsDef(array(
            'dsn_config'         => DesignerConfig::getSettings(),
            'dsn_product_config' => DesignerProductConfig::getSettings($this->id_product),
            'dsn_public_path'    => $this->module->provider->getModuleDirUri('views/js'),
            'dsn_id_product'     => (int)$this->id_product,
            'dsn_id_attribute'   => (int)Tools::getValue('id_product_attribute'),
            'dsn_id_side'        => 0,
            'dsn_edit_design'    => $this->module->provider->getEditDesign(),
            'dsn_initial_design' => Design::getInitialDesign($this->id_product),
        ));

        Media::addJsDef(array(
            'dsn_image_group'     => $this->context->link->getModuleLink($this->module->name, 'imagegroup'),
            'dsn_user_upload'     => $this->context->link->getModuleLink($this->module->name, 'userupload'),
            'dsn_product_images'  => $this->context->link->getModuleLink($this->module->name, 'productimages'),
            'dsn_design_cart'     => $this->context->link->getModuleLink($this->module->name, 'designcart'),
            'dsn_design_download' => $this->context->link->getModuleLink($this->module->name, 'designdownload'),
            'dsn_layers'          => $this->context->link->getModuleLink($this->module->name, 'layers')
        ));

        Media::addJsDef(array(
            'dsn_uri'         => $this->module->provider->getModuleDirUri(),
            'dsn_data_uri'    => $this->module->provider->getDataDirUri(),
            'dsn_pixel_image' => $this->getPixelImage()
        ));

        $source = DesignerTools::getSource();
        $designer_config = DesignerConfig::getConfig();
        $variables = array(
            'dsn_message'      => array(
                'confirm'           => $this->module->l(
                    'Are you sure to delete this item?',
                    $source
                ),
                'saving_design'     => $this->module->l(
                    'Saving design items',
                    $source
                ),
                'saved_design'      => $this->module->l(
                    'Design saved successfully',
                    $source
                ),
                'deleted_design'    => $this->module->l(
                    'Design deleted successfully',
                    $source
                ),
                'saving_previews'   => $this->module->l(
                    'Saving design previews',
                    $source
                ),
                'adding_to_cart'    => $this->module->l(
                    'Adding design to cart',
                    $source
                ),
                'added_to_cart'     => $this->module->l(
                    'Successfully added to cart',
                    $source
                ),
                'low_dpi'           => $this->module->l(
                    'For a good print quality, please make the images with red borders smaller until they become green',
                    $source
                ),
                'low_dpi_confirm'           => $this->module->l(
                    'The images with a red border have low print quality, are you sure you want to proceed?',
                    $source
                ),
                'unavailable'       => $this->module->l(
                    'This product configuration is unavailable. Please choose another product option if possible',
                    $source
                ),
                'text.empty'        => $this->module->l(
                    'Please enter some text first',
                    $source
                ),
                'container.type.1'  => $this->module->l(
                    'This field only accepts text elements',
                    $source
                ),
                'container.type.2'  => $this->module->l(
                    'This field only accepts image elements',
                    $source
                ),
                'curvature_reset'   => $this->module->l(
                    'Click to reset the text curvature',
                    $source
                ),
                'brightness_reset'   => $this->module->l(
                    'Click to reset the image brightness',
                    $source
                ),
                'contrast_reset'   => $this->module->l(
                    'Click to reset the image contrast',
                    $source
                ),
                'leave'             => $this->module->l(
                    'Are you sure that you want to leave this page before saving your changes?',
                    $source
                ),
                'reset'             => $this->module->l(
                    'Are you sure that you want to reset the color theme?',
                    $source
                ),
                'no_previews'       => $this->module->l(
                    'No preview is available, please add some items and retry',
                    $source
                ),
                'layer_groups'      => $this->module->l(
                    'Please pick an option from each required group then retry',
                    $source
                ),
                'min_size'         => $this->module->l(
                    'The minimum allowed width & height for this element is _min_size_ cm',
                    $source
                ),
                'min_width'         => $this->module->l(
                    'The minimum allowed width for this product is _min_width_ cm',
                    $source
                ),
                'max_width'         => $this->module->l(
                    'The maximum allowed width for this product is _max_width_ cm',
                    $source
                ),
                'min_height'        => $this->module->l(
                    'The minimum allowed height for this product is _min_height_ cm',
                    $source
                ),
                'max_height'        => $this->module->l(
                    'The maximum allowed height for this product is _max_height_ cm',
                    $source
                ),
                'aspect_locked'     => $this->module->l(
                    'Changing aspect ratio of this product is disabled',
                    $source
                ),
                'upload.processing' => $this->module->l(
                    'Processing the uploaded file',
                    $source
                ),
                'upload.max_size'   => sprintf($this->module->l(
                    'The file is too big, please select a file less than %s',
                    $source
                ), DesignerTools::getSizeString($designer_config->upload_maxsize)),
            ),
            'dsn_translations' => array(),
        );
        Media::addJsDef($variables);

        Media::addJsDef(array(
            'dsn_lazy_css' => array(
                _THEMES_DIR_ . '_libraries/font-awesome/css/font-awesome.min.css'
            )
        ));
    }

    public function getPixelImage()
    {
        return $this->module->getPathUri() . 'views/img/pixel.png';
    }
}
