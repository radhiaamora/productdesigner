<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\presenters;

use classes\DesignerTools;
use classes\models\DesignerColor;
use Context;
use ProductDesigner;

class ColorPresenter extends DesignPresenter
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'color';

    protected function getFormValues()
    {
        $values = parent::getFormValues();
        $values['preview'] = null;
        $id_color = (int)$values['id_color'];
        if ($id_color) {
            $designer_color = new DesignerColor($id_color);
            if ($designer_color->getPath()) {
                $values['preview'] = $designer_color->getFileUri();
            }
        }
        return $values;
    }

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();
        $switch_active = array(
            'type' => 'switch',
            'label' => $this->module->l('Active', $source),
            'name' => 'active',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $input_label = array(
            'type' => 'text',
            'label' => $this->module->l('Label', $source),
            'col' => '4',
            'name' => 'label',
            'class' => 'dsn-sync-file',
            'lang' => true
        );

        $input_code = array(
            'type' => 'color',
            'label' => $this->module->l('Color code', $source),
            'name' => 'color'
        );

        $input_file = array(
            'type' => 'file',
            'label' => $this->module->l('Texture', $source),
            'col' => '4',
            'name' => 'file',
            'desc' => $this->module->l('Supported extensions', $source) . ': (png, jpeg, svg)'
        );

        $texture_preview = array(
            'type'  => 'img',
            'label' => $this->module->l('Current texture', $source),
            'name'  => 'preview'
        );

        $input_method = array(
            'type' => 'hidden',
            'name' => 'method'
        );

        $input_id = array(
            'type' => 'hidden',
            'name' => 'id_color'
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Edit color', $source)
                ),
                'input' => array(
                    $input_id,
                    $input_method,
                    $input_label,
                    $input_code,
                    $input_file,
                    $texture_preview,
                    $switch_active
                ),
                'submit' => array(
                    'name' => 'submitcolor',
                    'title' => $this->module->l('Save', $source),
                    'class' => 'btn btn-default pull-right'
                ),
                'buttons' => array(
                    array(
                        'title' => $this->module->l('Cancel', $source),
                        'href' => $this->module->provider->getModuleAdminLink('#colors'),
                        'icon' => 'process-icon-cancel'
                    )
                )
            )
        );
    }
}
