<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\presenters;

use classes\DesignerTools;
use classes\models\DesignerImageGroup;
use Context;
use ProductDesigner;

class ImagePresenter extends DesignPresenter
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    protected $model = 'image';

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
        parent::__construct($this->module, $this->context);
    }

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();
        $switch_active = array(
            'type' => 'switch',
            'label' => $this->module->l('Active', $source),
            'name' => 'active',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $input_label = array(
            'type' => 'text',
            'label' => $this->module->l('Label', $source),
            'col' => '4',
            'name' => 'label',
            'lang' => true,
            'class' => 'dsn-sync-file',
            'desc' => $this->module->l('Pick a file below to get an automatic label', $source)
        );

        $input_file = array(
            'type' => 'file',
            'label' => $this->module->l('Image file', $source),
            'col' => '4',
            'name' => 'file',
            'desc' => $this->module->l('Supported extensions', $source) . ': (png, jpeg, svg)'
        );

        $input_group = array(
            'type' => 'select',
            'label' => $this->module->l('Image group', $source),
            'name' => 'id_image_group',
            'options' => array(
                'query' => DesignerImageGroup::getOptionsList($this->context->language->id),
                'id' => 'id_option',
                'name' => 'name'
            )
        );

        $input_price = array(
            'type' => 'text',
            'label' => $this->module->l('Image price per m²', $source),
            'name' => 'price',
            'col' => '2',
            'cast' => 'floatval',
            'validation' => 'isPrice',
            'suffix' => $this->context->currency->getSign() . ' ' . $this->module->l('per m²', $source),
        );

        $input_width = array(
            'type' => 'text',
            'label' => $this->module->l('Image width', $source),
            'name' => 'width',
            'col' => '2',
            'cast' => 'floatval',
            'validation' => 'isUnsignedFloat',
            'suffix' => 'cm',
            'desc' => $this->module->l('Leave to 0 to ignore', $source),
        );

        $input_height = array(
            'type' => 'text',
            'label' => $this->module->l('Image height', $source),
            'name' => 'height',
            'col' => '2',
            'cast' => 'floatval',
            'validation' => 'isUnsignedFloat',
            'suffix' => 'cm',
            'desc' => $this->module->l('Leave to 0 to ignore', $source),
        );

        $input_method = array(
            'type' => 'hidden',
            'name' => 'method'
        );

        $input_id = array(
            'type' => 'hidden',
            'name' => 'id_image'
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Edit image', $source)
                ),
                'input' => array(
                    $input_id,
                    $input_method,
                    $input_label,
                    $input_file,
                    $input_group,
                    $input_price,
                    $input_width,
                    $input_height,
                    $switch_active
                ),
                'submit' => array(
                    'name' => 'submitimage',
                    'title' => $this->module->l('Save', $source),
                    'class' => 'btn btn-default pull-right'
                ),
                'buttons' => array(
                    array(
                        'title' => $this->module->l('Cancel', $source),
                        'href' => $this->module->provider->getModuleAdminLink('#images'),
                        'icon' => 'process-icon-cancel'
                    )
                )
            )
        );
    }
}
