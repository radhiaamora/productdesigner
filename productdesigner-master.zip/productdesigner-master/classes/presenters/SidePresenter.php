<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\presenters;

use classes\DesignerTools;
use Context;
use ProductDesigner;

class SidePresenter extends DesignPresenter
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'side';

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();
        $switch_active = array(
            'type' => 'switch',
            'label' => $this->module->l('Active', $source),
            'name' => 'active',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $input_name = array(
            'type' => 'text',
            'label' => $this->module->l('Name', $source),
            'desc' => $this->module->l('For reference only, it could be used as a category', $source),
            'col' => '4',
            'name' => 'name'
        );

        $input_label = array(
            'type' => 'text',
            'label' => $this->module->l('Label', $source),
            'desc' => $this->module->l('This label will be displayed in the product page', $source),
            'col' => '4',
            'name' => 'label',
            'lang' => true
        );

        $input_method = array(
            'type' => 'hidden',
            'name' => 'method'
        );

        $input_id = array(
            'type' => 'hidden',
            'name' => 'id_side'
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Edit side', $source)
                ),
                'input' => array(
                    $input_id,
                    $input_method,
                    $input_name,
                    $input_label,
                    $switch_active
                ),
                'submit' => array(
                    'name' => 'submitside',
                    'title' => $this->module->l('Save', $source),
                    'class' => 'btn btn-default pull-right'
                ),
                'buttons' => array(
                    array(
                        'title' => $this->module->l('Cancel', $source),
                        'href' => $this->module->provider->getModuleAdminLink('#sides'),
                        'icon' => 'process-icon-cancel'
                    )
                )
            )
        );
    }
}
