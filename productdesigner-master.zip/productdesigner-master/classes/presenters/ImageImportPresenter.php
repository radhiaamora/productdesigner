<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\presenters;

use classes\DesignerTools;
use classes\models\DesignerImageGroup;

class ImageImportPresenter extends DesignPresenter
{
    protected $model = 'image_import';

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();

        $input_file = array(
            'type' => 'file',
            'label' => $this->module->l('Images', $source),
            'col' => '4',
            'name' => 'files',
            'multiple' => true,
            'desc' => $this->module->l('Supported extensions', $source) . ': (png, jpeg, svg)'
        );

        $input_price = array(
            'type' => 'text',
            'label' => $this->module->l('Image price per m²', $source),
            'name' => 'price',
            'col' => '2',
            'cast' => 'floatval',
            'validation' => 'isPrice',
            'suffix' => $this->context->currency->getSign() . ' ' . $this->module->l('per m²', $source)
        );

        $input_group = array(
            'type' => 'select',
            'label' => $this->module->l('Image group', $source),
            'name' => 'id_image_group',
            'options' => array(
                'query' => DesignerImageGroup::getOptionsList($this->context->language->id),
                'id' => 'id_option',
                'name' => 'name'
            )
        );

        $input_method = array(
            'type' => 'hidden',
            'name' => 'method'
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Import images', $source)
                ),
                'input' => array(
                    $input_method,
                    $input_file,
                    $input_price,
                    $input_group
                ),
                'submit' => array(
                    'name' => 'submitimage_import',
                    'title' => $this->module->l('Save', $source),
                    'class' => 'btn btn-default pull-right'
                ),
                'buttons' => array(
                    array(
                        'title' => $this->module->l('Cancel', $source),
                        'href' => $this->module->provider->getModuleAdminLink('#images'),
                        'icon' => 'process-icon-cancel'
                    )
                )
            )
        );
    }
}
