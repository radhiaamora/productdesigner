<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\presenters;

use classes\DesignerTools;
use Context;
use ProductDesigner;

/** @noinspection PhpUnused */

class ImageGroupPresenter extends DesignPresenter
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    protected $model = 'image_group';

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
        parent::__construct($this->module, $this->context);
    }

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();
        $switch_active = array(
            'type' => 'switch',
            'label' => $this->module->l('Active', $source),
            'name' => 'active',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_is_white = array(
            'type' => 'switch',
            'label' => $this->module->l('White image group', $source),
            'name' => 'is_white',
            'values' => array(
                array(
                    'id' => 'is_white_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'is_white_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            ),
            'desc'   => $this->module->l('Enable if this group consistes of white images/shapes only', $source)
        );

        $input_label = array(
            'type' => 'text',
            'label' => $this->module->l('Label', $source),
            'col' => '4',
            'name' => 'label',
            'lang' => true,
            'class' => 'dsn-sync-file',
            'desc' => $this->module->l('Pick a file below to get an automatic label', $source)
        );

        $input_file = array(
            'type' => 'file',
            'label' => $this->module->l('Image', $source),
            'col' => '4',
            'name' => 'file',
            'desc' => $this->module->l('Supported extensions', $source) . ': (png, jpeg, svg)'
        );

        $input_method = array(
            'type' => 'hidden',
            'name' => 'method'
        );

        $input_id = array(
            'type' => 'hidden',
            'name' => 'id_image_group'
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Edit image group', $source)
                ),
                'input' => array(
                    $input_id,
                    $input_method,
                    $input_label,
                    $input_file,
                    $switch_active,
                    $switch_is_white
                ),
                'submit' => array(
                    'name' => 'submitimage_group',
                    'title' => $this->module->l('Save', $source),
                    'class' => 'btn btn-default pull-right'
                ),
                'buttons' => array(
                    array(
                        'title' => $this->module->l('Cancel', $source),
                        'href' => $this->module->provider->getModuleAdminLink('#image_groups'),
                        'icon' => 'process-icon-cancel'
                    )
                )
            )
        );
    }
}
