<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\configuration;

use classes\DesignerTools;
use classes\material\MaterialDesign;
use classes\panels\DesignPanel;
use Context;
use ProductDesigner;

class ConfigurationPanel extends DesignPanel
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    protected $name = 'configuration';
    protected $tpl_path = 'views/templates/admin/configuration/panels';

    public function getContent()
    {
        $material = new MaterialDesign($this->module, $this->context);
        $material->setComponents($this->getComponents());
        return $material->render();
    }

    protected function getComponents()
    {
        return array(
            'tabs' => array(
                'name'    => $this->name,
                'type'    => 'tabs',
                'dir'     => $this->module->getDir() . $this->tpl_path,
                'tabs'    => $this->getTabs(),
                'refresh' => false
            )
        );
    }

    protected function getTabsList()
    {
        $source = DesignerTools::getSource();
        return array(
            'general'        => array(
                'lazy'    => false,
                'label'   => $this->module->l('Settings', $source),
                'icon'    => 'settings_applications',
                'content' => ''
            ),
            'design_options' => array(
                'lazy'    => false,
                'label'   => $this->module->l('Design Options', $source),
                'icon'    => 'done_all',
                'content' => ''
            ),
            'text_options'   => array(
                'lazy'    => false,
                'label'   => $this->module->l('Text Options', $source),
                'icon'    => 'text_format',
                'content' => ''
            ),
            'tabs'           => array(
                'lazy'    => false,
                'label'   => $this->module->l('Tabs', $source),
                'icon'    => 'tab',
                'content' => '',
                'demo'    => false,
            ),
            'sides'          => array(
                'lazy'    => false,
                'label'   => $this->module->l('Sides', $source),
                'icon'    => 'shuffle',
                'content' => ''
            ),
            'colors'         => array(
                'lazy'    => false,
                'label'   => $this->module->l('Colors', $source),
                'icon'    => 'palette',
                'content' => ''
            ),
            'fonts'          => array(
                'lazy'    => false,
                'label'   => $this->module->l('Fonts', $source),
                'icon'    => 'font_download',
                'content' => ''
            ),
            'image_groups'   => array(
                'lazy'    => false,
                'label'   => $this->module->l('Image groups', $source),
                'icon'    => 'collections',
                'content' => ''
            ),
            'images'         => array(
                'lazy'    => false,
                'label'   => $this->module->l('Images', $source),
                'icon'    => 'image',
                'content' => ''
            ),
            'help_contents'  => array(
                'lazy'    => false,
                'label'   => $this->module->l('Help Contents', $source),
                'icon'    => 'help',
                'content' => ''
            ),
            'color_theme'    => array(
                'lazy'    => false,
                'label'   => $this->module->l('Color theme', $source),
                'icon'    => 'colorize',
                'content' => '',
                'demo'    => false,
            ),
        );
    }
}
