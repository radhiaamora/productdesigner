<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\configuration\panels;

use classes\DesignerTools;
use classes\models\DesignerImage;
use classes\models\DesignerImageGroup;
use classes\panels\ListPanel;
use Context;
use ProductDesigner;

class ImagesPanel extends ListPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'image';
    protected $label = 'Images';

    protected $filter;

    public function getListFields()
    {
        $source = DesignerTools::getSource();
        return array(
            'id_image' => array(
                'title' => $this->module->l('ID', $source),
                'width' => 50,
                'type' => 'text',
                'class' => 'fixed-width-xs'
            ),
            'label' => array(
                'title' => $this->module->l('Label', $source),
                'type' => 'text'
            ),
            'id_image_group' => array(
                'title' => $this->module->l('Group', $source),
                'type' => 'text',
                'callback' => 'getName',
                'callback_object' => DesignerImageGroup::class
            ),
            'file' => array(
                'title' => $this->module->l('Image', $source),
                'type' => 'text',
                'class' => 'fixed-width-xs',
                'callback' => 'getImageMarkup',
                'callback_object' => DesignerImage::class
            ),
            'price' => array(
                'title' => $this->module->l('Price', $source),
                'type' => 'price',
                'class' => 'fixed-width-xs'
            ),
            'active' => array(
                'title' => $this->module->l('Active', $source),
                'align' => 'center',
                'active' => 'status',
                'type' => 'bool',
                'class' => 'fixed-width-xs'
            ),
            'position' => array(
                'title' => $this->module->l('Position', $source),
                'position' => 'position',
                'align' => 'center',
                'class' => 'fixed-width-xs'
            )
        );
    }

    protected function addListButtons($helper)
    {
        parent::addListButtons($helper);
        $source = DesignerTools::getSource();
        $helper->toolbar_btn['import'] = array(
            'href' => $this->module->provider->getModuleAdminLink('update_image_import'),
            'desc' => $this->module->l('Import multiple images', $source)
        );
        $helper->toolbar_btn['export'] = array(
            'href' => $this->module->provider->getModuleAdminLink('submit_images_thumbnails'),
            'desc' => $this->module->l('Regenerate images thumbnails', $source)
        );
    }

    public function getFilter()
    {
        return $this->filter;
    }

    public function setFilter($filter)
    {
        $this->filter = $filter;
    }
}
