<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\configuration\panels;

use classes\DesignerTools;
use classes\models\DesignerConfig;
use classes\panels\FormPanel;
use Context;
use ProductDesigner;

class DesignOptionsPanel extends FormPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'config';
    protected $label = 'Design Options';

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();

        $switch_show_download_btn = array(
            'type'   => 'switch',
            'label'  => $this->module->l('Show download button', $source),
            'name'   => $this->model . '-show_download_btn',
            'values' => array(
                array(
                    'id'    => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id'    => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_show_dimensions = array(
            'type'   => 'switch',
            'label'  => $this->module->l('Show design items dimensions', $source),
            'desc'   => $this->module->l('Show the dimensions in centimers under the design texts and images', $source),
            'name'   => $this->model . '-show_dimensions',
            'values' => array(
                array(
                    'id'    => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id'    => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_show_delete_confirmation = array(
            'type'   => 'switch',
            'label'  => $this->module->l('Show item deletion confirmation', $source),
            'name'   => $this->model . '-show_delete_confirmation',
            'values' => array(
                array(
                    'id'    => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id'    => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_field_multiple_items = array(
            'type'   => 'switch',
            'label'  => $this->module->l('Allow multiple items per design field', $source),
            'desc'   => $this->module->l('A field can contain multiple texts and images if enabled', $source),
            'name'   => $this->model . '-field_multiple_items',
            'values' => array(
                array(
                    'id'    => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id'    => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $input_min_dpi = array(
            'type'  => 'text',
            'class' => 'fixed-width-lg',
            'label' => $this->module->l('Minimum DPI for images', $source),
            'desc'  => $this->module->l('Will be used to ensure that images have a good print quality', $source),
            'name'  => $this->model . '-min_dpi'
        );

        $switch_block_min_dpi = array(
            'type'   => 'switch',
            'label'  => $this->module->l('Disallow designs with low dpi images', $source),
            'desc'   => $this->module->l('You can either block adding to cart or only display a warning', $source),
            'name'   => $this->model . '-block_min_dpi',
            'values' => array(
                array(
                    'id'    => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id'    => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $input_upload_maxsize = array(
            'name'       => $this->model . '-upload_maxsize',
            'type'       => 'select',
            'label'      => $this->module->l('Upload max size', $source),
            'options'    => array(
                'query' => array(
                    array(
                        'label' => '500 KB',
                        'id'    => 512000
                    ),
                    array(
                        'label' => '1 MB',
                        'id'    => 1024000
                    ),
                    array(
                        'label' => '2 MB',
                        'id'    => 1024000 * 2
                    ),
                    array(
                        'label' => '5 MB',
                        'id'    => 1024000 * 5
                    ),
                    array(
                        'label' => '10 MB',
                        'id'    => 1024000 * 10
                    ),
                    array(
                        'label' => '20 MB',
                        'id'    => 1024000 * 20
                    ),
                    array(
                        'label' => '64 MB',
                        'id'    => 1024000 * 64
                    ),
                    array(
                        'label' => '128 MB',
                        'id'    => 1024000 * 128
                    ),
                    array(
                        'label' => '256 MB',
                        'id'    => 1024000 * 256
                    ),
                    array(
                        'label' => '512 MB',
                        'id'    => 1024000 * 512
                    ),
                ),
                'id' => 'id',
                'name' => 'label',
            )
        );


        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Design Options', $source)
                ),
                'input'  => array(
                    $switch_show_download_btn,
                    $switch_show_dimensions,
                    $switch_show_delete_confirmation,
                    $switch_field_multiple_items,
                    $input_min_dpi,
                    $switch_block_min_dpi,
                    $input_upload_maxsize,
                )
            )
        );
    }

    protected function getFieldsValues()
    {
        $result = array();
        $values = DesignerConfig::getConfigValues();
        foreach ($values as $name => $value) {
            $result[$this->model . '-' . $name] = $value;
        }
        return $result;
    }
}
