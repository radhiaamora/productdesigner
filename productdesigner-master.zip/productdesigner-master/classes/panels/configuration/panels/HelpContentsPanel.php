<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\configuration\panels;

use classes\DesignerTools;
use classes\models\DesignerHelpContent;
use classes\panels\FormPanel;
use Context;
use ProductDesigner;

/** @noinspection PhpUnused */

class HelpContentsPanel extends FormPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'help_content';
    protected $label = 'Help Contents';

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();

        $textarea_image_upload_help_content = array(
            'type'         => 'textarea',
            'label'        => $this->module->l('Image Upload Help'),
            'description'  => $this->module->l('Will be displayed next to the image upload button'),
            'lang' => true,
            'name'         => 'image_upload_help',
            'cols'         => 40,
            'rows'         => 120,
            'class'        => 'rte',
            'autoload_rte' => true,
        );

        $textarea_text_help_content = array(
            'type'         => 'textarea',
            'label'        => $this->module->l('Text Help'),
            'description'  => $this->module->l('Will be displayed in the text tab'),
            'lang' => true,
            'name'         => 'text_help',
            'cols'         => 40,
            'rows'         => 120,
            'class'        => 'rte',
            'autoload_rte' => true,
        );

        $input_id = array(
            'type' => 'hidden',
            'name' => 'id_' . $this->model
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Help Content', $source)
                ),
                'input'  => array(
                    $input_id,
                    $textarea_image_upload_help_content,
                    $textarea_text_help_content,
                ),
                'submit' => array(
                    'name'  => 'submithelp_content',
                    'title' => $this->module->l('Save', $source),
                    'class' => 'btn btn-default pull-right'
                ),
            )
        );
    }

    protected function getFieldsValues()
    {
        $result = array();
        $values = DesignerHelpContent::getContentValues();
        foreach ($values as $name => $value) {
            $result[$name] = $value;
        }
        $result['id_' . $this->model] = 1;
        return $result;
    }
}
