<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\configuration\panels;

use classes\DesignerTools;
use classes\models\DesignerConfig;
use classes\panels\FormPanel;
use Context;
use ProductDesigner;

class TextOptionsPanel extends FormPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'config';
    protected $label = 'Text Options';

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();

        $switch_hide_size = array(
            'type' => 'switch',
            'label' => $this->module->l('Hide text size input', $source),
            'desc' => $this->module->l('Keep things simpler for your customers', $source),
            'name' => $this->model . '-hide_size_input',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_hide_style = array(
            'type' => 'switch',
            'label' => $this->module->l('Hide text style buttons', $source),
            'desc' => $this->module->l('Hides bold, italic & underline buttons', $source),
            'name' => $this->model . '-hide_style_buttons',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_hide_alignment = array(
            'type' => 'switch',
            'label' => $this->module->l('Hide text alignment', $source),
            'name' => $this->model . '-hide_alignment',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_hide_outline = array(
            'type' => 'switch',
            'label' => $this->module->l('Hide text outline', $source),
            'name' => $this->model . '-hide_outline',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_enable_text_precision = array(
            'type' => 'switch',
            'label' => $this->module->l('Enable text precise size', $source),
            'desc' => $this->module->l('Will trim text to exact size (slower performance)', $source),
            'name' => $this->model . '-enable_text_precision',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Text Options', $source)
                ),
                'input' => array(
                    $switch_hide_size,
                    $switch_hide_style,
                    $switch_hide_alignment,
                    $switch_hide_outline,
                    $switch_enable_text_precision,
                )
            )
        );
    }

    protected function getFieldsValues()
    {
        $result = array();
        $values = DesignerConfig::getConfigValues();
        foreach ($values as $name => $value) {
            $result[$this->model . '-' . $name] = $value;
        }
        return $result;
    }
}
