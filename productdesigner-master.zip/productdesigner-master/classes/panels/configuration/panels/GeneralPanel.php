<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\configuration\panels;

use classes\DesignerTools;
use classes\models\DesignerConfig;
use classes\panels\FormPanel;
use Context;
use ProductDesigner;

class GeneralPanel extends FormPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model = 'config';
    protected $label = 'Settings';

    protected function getFormFields()
    {
        $source = DesignerTools::getSource();

        $switch_display_base = array(
            'type' => 'switch',
            'label' => $this->module->l('Include base image in print', $source),
            'desc' => $this->module->l('Print the product image with the design', $source),
            'name' => $this->model . '-display_base',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_display_mask = array(
            'type' => 'switch',
            'label' => $this->module->l('Include mask image in print', $source),
            'name' => $this->model . '-display_mask',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_display_layers = array(
            'type' => 'switch',
            'label' => $this->module->l('Include layer images in print', $source),
            'name' => $this->model . '-display_layers',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_preview_in_invoice = array(
            'type' => 'switch',
            'label' => $this->module->l('Show preview in invoice', $source),
            'name' => $this->model . '-preview_in_invoice',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_preview_in_email = array(
            'type' => 'switch',
            'label' => $this->module->l('Show preview in emails', $source),
            'name' => $this->model . '-preview_in_email',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_hide_cart = array(
            'type' => 'switch',
            'label' => $this->module->l('Hide standard cart button & quantity box', $source),
            'desc' => $this->module->l('Applies only if the customization is required', $source),
            'name' => $this->model . '-hide_cart_button',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_show_custom_btn = array(
            'type' => 'switch',
            'label' => $this->module->l('Show the customize button', $source),
            'desc' => $this->module->l('Shows a Customize button next to the cart button', $source),
            'name' => $this->model . '-show_custom_btn',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_show_attributes_in_tabs = array(
            'type' => 'switch',
            'label' => $this->module->l('Show product attributes in tabs', $source),
            'desc' => $this->module->l('Shows attributes on the bottom of the tabs', $source),
            'name' => $this->model . '-show_attributes_in_tabs',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_show_in_popup = array(
            'type' => 'switch',
            'label' => $this->module->l('Show the interface in a popup', $source),
            'desc' => $this->module->l('The popup will be displayed when the customize button is clicked', $source),
            'name' => $this->model . '-show_in_popup',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        $switch_auto_show_popup = array(
            'type' => 'switch',
            'label' => $this->module->l('Show the popup on page load', $source),
            'desc' => $this->module->l('The popup will be displayed when the page loads', $source),
            'name' => $this->model . '-auto_show_popup',
            'values' => array(
                array(
                    'id' => 'active_on',
                    'value' => 1,
                    'label' => $this->module->l('Yes', $source)
                ),
                array(
                    'id' => 'active_off',
                    'value' => 0,
                    'label' => $this->module->l('No', $source)
                )
            )
        );

        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->module->l('Configuration', $source)
                ),
                'input' => array(
                    $switch_display_base,
                    $switch_display_mask,
                    $switch_display_layers,
                    $switch_preview_in_invoice,
                    $switch_preview_in_email,
                    $switch_hide_cart,
                    $switch_show_custom_btn,
                    $switch_show_attributes_in_tabs,
                    $switch_show_in_popup,
                    $switch_auto_show_popup,
                ),
                'buttons' => array(
                    array(
                        'title' => $this->module->l('Troubleshooting', $source),
                        'href' => $this->module->provider->getModuleAdminLink('view_troubleshooter'),
                        'icon' => 'process-icon-terminal',
                        'class' => 'pull-left btn-success'
                    )
                )
            )
        );
    }

    protected function getFieldsValues()
    {
        $result = array();
        $values = DesignerConfig::getConfigValues();
        foreach ($values as $name => $value) {
            $result[$this->model . '-' . $name] = $value;
        }
        return $result;
    }
}
