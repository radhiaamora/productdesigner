<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels;

use classes\DesignerTools;
use classes\models\DesignerObject;
use Context;
use HelperList;
use ProductDesigner;

abstract class ListPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $model;
    protected $label;

    protected $filter;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getContent()
    {
        $helper = $this->getHelperList();
        $this->addListButtons($helper);
        return $this->generateList($helper);
    }

    abstract protected function getListFields();

    abstract public function getFilter();

    abstract public function setFilter($filter);

    protected function getHelperList()
    {
        $helper = new HelperList();

        $helper->simple_header = false;

        $helper->actions = array('edit', 'delete');

        $helper->show_toolbar = true;

        /** @noinspection PhpUndefinedFieldInspection */
        $helper->shopLinkType = null;
        /** @noinspection PhpUndefinedFieldInspection */
        $helper->position_group_identifier = '1';
        $helper->position_identifier = 'position';
        $helper->orderBy = 'position';

        $helper->title = 'List';
        $helper->table = 'table';
        $helper->token = $this->module->provider->getModuleAdminToken();
        $helper->currentIndex = $this->module->provider->getModuleAdminLink();

        $helper->table = $this->model;
        $helper->identifier = 'id_' . $this->model;

        return $helper;
    }

    /**
     * @param HelperList $helper
     */
    protected function addListButtons($helper)
    {
        $source = DesignerTools::getSource();
        $add_href = $this->module->provider->getModuleAdminLink();
        $add_href = DesignerTools::addQueryToUrl($add_href, array(
            'update_' . $this->model => '',
            'id_' . $this->model => 0
        ));
        $helper->toolbar_btn['new'] = array(
            'href' => $add_href,
            'desc' => $this->module->l('Add new', $source)
        );
    }

    /**
     * @param HelperList $helper
     * @return string
     */
    protected function generateList($helper)
    {
        $model_class = DesignerObject::getModelClass($this->model);
        $list = $model_class::getList($this->context->language->id, $this->getFilter());
        $helper->listTotal = count($list);
        return $helper->generateList($list, $this->getListFields());
    }
}
