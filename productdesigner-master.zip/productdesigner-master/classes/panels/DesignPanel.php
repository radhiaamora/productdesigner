<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels;

use classes\DesignerTools;
use classes\material\MaterialTab;
use Context;
use interfaces\DesignerUI;
use ProductDesigner;
use Tools;

abstract class DesignPanel
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $name;
    protected $tpl_path;
    /** @var DesignerUI $ui */
    protected $ui;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public static function getPanelClass($panel_name)
    {
        $namespace = 'classes\panels\\' . $panel_name . '\\';
        $class_name = Tools::toCamelCase($panel_name, true) . 'Panel';
        return $namespace . $class_name;
    }

    public static function getTabContent($panel_name, $tab_name)
    {
        $panel_class = self::getPanelClass($panel_name);
        /** @var DesignPanel $panel_instance */
        $module = DesignerTools::getModule();
        $context = DesignerTools::getContext();
        $panel_instance = new $panel_class($module, $context);
        $namespace = '\classes\panels\\' . $panel_instance->name . '\panels\\';
        $tab_class = $namespace . Tools::toCamelCase($tab_name, true) . 'Panel';
        $output = '';
        if (class_exists($tab_class)) {
            /** @var MaterialTab $panel */
            $panel = new $tab_class($module, $context);
            if (method_exists($panel, 'renderTabTemplate')) {
                $output = $panel->renderTabTemplate($panel_instance->tpl_path);
            }
        }
        return $output;
    }

    abstract protected function getComponents();

    abstract protected function getTabsList();

    public function getTabs()
    {
        $source = DesignerTools::getSource();
        $namespace = 'classes\panels\\' . $this->name . '\panels\\';
        $tabs = $this->getTabsList();
        foreach ($tabs as $tab_name => &$tab) {
            if (isset($tab['demo']) && $tab['demo'] === false && DesignerTools::isDemo()) {
                $tab['content'] = $this->module->l('This function is not available in demo mode', $source);
                continue;
            }
            $panel_class = $namespace . Tools::toCamelCase($tab_name, true) . 'Panel';
            if (class_exists($panel_class)) {
                $panel = new $panel_class($this->module, $this->context);
                if (!$this->isTabLazy($tab) && method_exists($panel, 'getContent')) {
                    $tab['content'] = $panel->getContent($this->ui);
                }
            }
            if (DesignerTools::isModuleDevMode()) {
                $tab['link'] = $this->module->provider->getControllerAdminLink(
                    'DsnProductDev',
                    array(
                        'id_product' => $this->module->state->get('id_product'),
                        'dsn_tab' => $tab_name
                    )
                );
            }
        }
        return $tabs;
    }

    private function isTabLazy($tab)
    {
        return isset($tab['lazy']) && $tab['lazy'];
    }
}
