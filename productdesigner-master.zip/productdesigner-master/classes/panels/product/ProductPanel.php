<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\product;

use classes\DesignerTools;
use classes\material\MaterialDesign;
use classes\models\DesignerProductConfig;
use classes\models\DesignerProductPricing;
use classes\panels\DesignPanel;
use interfaces\DesignerUI;
use Tools;

class ProductPanel extends DesignPanel
{
    protected $name = 'product';
    protected $tpl_path = 'views/templates/hook/admin/extra/panels';
    /** @var DesignerUI $ui */
    protected $ui;

    public function __construct($module, $context)
    {
        parent::__construct($this->module, $this->context);
        $this->module = $module;
        $this->context = $context;
        $this->ui = new MaterialDesign($this->module, $this->context);
        $id_product = $this->module->state->get('id_product');
        $values = array_merge(
            DesignerProductConfig::getProductValues($id_product),
            DesignerProductPricing::getProductValues($id_product)
        );
        $this->ui->setValues($values);
    }

    public function getContent()
    {
        $this->ui->setComponents($this->getComponents());
        return $this->ui->render();
    }

    protected function getComponents()
    {
        $source = DesignerTools::getSource();
        $components = array(
            'config_button'  => array(
                'name'   => 'config-btn',
                'type'   => 'button',
                'label'  => $this->module->l('Configuration page', $source),
                'icon'   => 'settings',
                'href'   => $this->module->provider->getModuleAdminLink(),
                'target' => '_blank'
            ),
            'color_theme'    => array(
                'name'   => 'color_theme-btn',
                'type'   => 'button',
                'label'  => $this->module->l('Color Theme', $source),
                'class'  => 'mdl-button--green',
                'icon'   => 'color_lens',
                'href'   => $this->module->provider->getProductLink(
                    $this->module->state->get('id_product'),
                    null,
                    array(
                        'designer_scroll' => 1,
                        'color_theme'     => 1
                    )
                ),
                'target' => 'color_theme'
            ),
            'product_button' => array(
                'name'   => 'product-btn',
                'type'   => 'button',
                'label'  => $this->module->l('Product page', $source),
                'class'  => 'mdl-button--accent',
                'icon'   => 'pages',
                'href'   => $this->module->provider->getProductLink(
                    $this->module->state->get('id_product'),
                    null,
                    array(
                        'designer_scroll' => 1
                    )
                ),
                'target' => 'tn_product_page'
            ),
            'dev_button'     => array(
                'name'   => 'product-btn',
                'type'   => 'button',
                'label'  => 'Dev Page',
                'class'  => 'mdl-button--blue',
                'icon'   => 'code',
                'href'   => $this->module->provider->getControllerAdminLink(
                    'DsnProductDev',
                    array(
                        'id_product' => $this->module->state->get('id_product')
                    )
                ),
                'target' => 'tn_dev_page'
            ),
            'tabs'           => array(
                'name' => $this->name,
                'type' => 'tabs',
                'dir'  => $this->module->getDir() . $this->tpl_path,
                'tabs' => $this->getTabs()
            )
        );

        if (!DesignerTools::isModuleDevMode()) {
            unset($components['dev_button']);
        }

        return $components;
    }

    protected function getTabsList()
    {
        $source = DesignerTools::getSource();
        $list = array(
            'main'           => array(
                'lazy'    => false,
                'label'   => $this->module->l('Main', $source),
                'icon'    => 'settings_applications',
                'content' => ''
            ),
            'tabs'           => array(
                'lazy'    => true,
                'label'   => $this->module->l('Tabs', $source),
                'icon'    => 'tab',
                'content' => '',
                'demo'    => false
            ),
            'sides'          => array(
                'lazy'    => true,
                'label'   => $this->module->l('Sides', $source),
                'icon'    => 'shuffle',
                'content' => ''
            ),
            'images'         => array(
                'lazy'    => true,
                'label'   => $this->module->l('Images', $source),
                'icon'    => 'collections',
                'content' => ''
            ),
            'product_colors' => array(
                'lazy'    => true,
                'label'   => $this->module->l('Product Colors', $source),
                'icon'    => 'brush',
                'content' => ''
            ),
            'product_size'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Product Size', $source),
                'icon'    => 'photo_size_select_large',
                'content' => ''
            ),
            'product_layers' => array(
                'lazy'    => true,
                'label'   => $this->module->l('Product Options', $source),
                'icon'    => 'layers',
                'content' => ''
            ),
            'fonts'          => array(
                'lazy'    => true,
                'label'   => $this->module->l('Fonts', $source),
                'icon'    => 'font_download',
                'content' => ''
            ),
            'text_colors'    => array(
                'lazy'    => true,
                'label'   => $this->module->l('Text Colors', $source),
                'icon'    => 'palette',
                'content' => ''
            ),
            'image_colors'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Image Colors', $source),
                'icon'    => 'palette',
                'content' => ''
            ),
            'image_filters'  => array(
                'lazy'    => true,
                'label'   => $this->module->l('Image Filters', $source),
                'icon'    => 'photo_filter',
                'content' => ''
            ),
            'image_groups'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Image groups', $source),
                'icon'    => 'burst_mode',
                'content' => ''
            ),
            'design_areas'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Areas', $source),
                'icon'    => 'select_all',
                'content' => ''
            ),
            'design_fields'  => array(
                'lazy'    => true,
                'label'   => $this->module->l('Fields', $source),
                'icon'    => 'picture_in_picture',
                'content' => ''
            ),
            'real_size'      => array(
                'lazy'    => true,
                'label'   => $this->module->l('Real size', $source),
                'icon'    => 'space_bar',
                'content' => ''
            ),
            'design_options' => array(
                'lazy'    => true,
                'label'   => $this->module->l('Design options', $source),
                'icon'    => 'done_all',
                'content' => ''
            ),
            'text_options'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Text options', $source),
                'icon'    => 'text_format',
                'content' => ''
            ),
            'image_options'  => array(
                'lazy'    => true,
                'label'   => $this->module->l('Images options', $source),
                'icon'    => 'settings_brightness',
                'content' => ''
            ),
            'text_pricing'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Text pricing', $source),
                'icon'    => 'account_balance',
                'content' => ''
            ),
            'image_pricing'  => array(
                'lazy'    => true,
                'label'   => $this->module->l('Image pricing', $source),
                'icon'    => 'account_balance',
                'content' => ''
            ),
            'side_pricing'   => array(
                'lazy'    => true,
                'label'   => $this->module->l('Side pricing', $source),
                'icon'    => 'account_balance',
                'content' => ''
            ),
            'bulk_copy'      => array(
                'lazy'    => true,
                'label'   => $this->module->l('Bulk Copy', $source),
                'icon'    => 'file_copy',
                'content' => '',
                'demo'    => false
            ),
        );

        if (Tools::getIsset('dsn_tab')) {
            $tab = Tools::getValue('dsn_tab');
            if (isset($list[$tab])) {
                $tab_definition = $list[$tab];
                $list = array();
                $tab_definition['lazy'] = false;
                $list[$tab] = $tab_definition;
            }
        }

        return $list;
    }
}
