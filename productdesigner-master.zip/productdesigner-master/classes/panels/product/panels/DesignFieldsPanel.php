<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\product\panels;

use classes\DesignerTools;
use classes\helpers\ProductImageHelper;
use classes\material\MaterialTab;
use classes\models\DesignerField;
use classes\models\DesignerProductSide;
use Configuration;
use Context;
use interfaces\DesignerUI;
use Language;
use Product;
use ProductDesigner;

class DesignFieldsPanel extends MaterialTab
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $name = 'product_fields';

    /**
     * @param DesignerUI $ui
     * @return mixed
     */
    public function getContent($ui)
    {
        $ui->setComponents($this->getFormFields());
        return $ui->render();
    }

    /**
     * @return array
     */
    public function getFormFields()
    {
        $id_product = $this->module->state->get('id_product');

        $designer_product_images = ProductImageHelper::getAttributeImages(
            $id_product,
            Product::getDefaultAttribute($id_product)
        );

        $source = DesignerTools::getSource();

        return array(
            array(
                'name' => 'enable_design_fields',
                'type' => 'switch',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_config',
                'label' => $this->module->l('Enable design fields', $source)
            ),
            array(
                'name' => 'design_fields',
                'type' => 'design-fields',
                'controller' => 'product_fields',
                'label' => $this->module->l('Configure design fields for this product', $source),
                'images' => $designer_product_images,
                'fields' => DesignerField::getProductFields($id_product, $this->context->language->id)
            )
        );
    }

    public static function getEditForm($id_design_field)
    {
        $module = DesignerTools::getModule();
        $context = DesignerTools::getContext();

        $context->smarty->assign(array(
            'id_design_field' => (int)$id_design_field,
            'design_field' => new DesignerField($id_design_field),
            'languages' => Language::getLanguages(),
            'language_img_dir' => _PS_IMG_ . 'l/'
        ));

        $template_path =
            $module->getDir() .
            'views/templates/hook/admin/extra/panels/panel-design-fields-edit.tpl';
        return $context->smarty->fetch($template_path);
    }
}
