<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\product\panels;

use classes\DesignerTools;
use classes\material\MaterialTab;
use Context;
use interfaces\DesignerUI;
use ProductDesigner;

class ImageOptionsPanel extends MaterialTab
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $name = 'real_size';

    /**
     * @param DesignerUI $ui
     * @return mixed
     */
    public function getContent($ui)
    {
        $ui->setComponents($this->getFormFields());
        return $ui->render();
    }

    /**
     * @return array
     */
    public function getFormFields()
    {
        $source = DesignerTools::getSource();
        return array(
            array(
                'name'       => 'enable_image_transparency',
                'type'       => 'switch',
                'class'      => 'dsn-ajax-input',
                'controller' => 'product_config',
                'label'      => $this->module->l('Enable image transparency', $source)
            ),
            array(
                'name'       => 'enable_image_brightness',
                'type'       => 'switch',
                'class'      => 'dsn-ajax-input',
                'controller' => 'product_config',
                'label'      => $this->module->l('Enable image brightness', $source)
            ),
            array(
                'name'       => 'enable_image_contrast',
                'type'       => 'switch',
                'class'      => 'dsn-ajax-input',
                'controller' => 'product_config',
                'label'      => $this->module->l('Enable image contrast', $source)
            ),
            array(
                'name'       => 'enable_image_flip',
                'type'       => 'switch',
                'class'      => 'dsn-ajax-input',
                'controller' => 'product_config',
                'label'      => $this->module->l('Enable image flip', $source)
            ),
        );
    }
}
