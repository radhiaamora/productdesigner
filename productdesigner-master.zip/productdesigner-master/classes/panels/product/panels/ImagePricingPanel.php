<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\product\panels;

use classes\DesignerTools;
use classes\material\MaterialTab;
use interfaces\DesignerUI;

class ImagePricingPanel extends MaterialTab
{
    protected $name = 'image_pricing';

    /**
     * @param DesignerUI $ui
     * @return mixed
     */
    public function getContent($ui)
    {
        $ui->setComponents($this->getFormFields());
        return $ui->render();
    }

    /**
     * @return array
     */
    public function getFormFields()
    {
        $source = DesignerTools::getSource();
        return array(
            array(
                'name' => 'use_image_cost',
                'type' => 'switch',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Use image cost directly', $source),
                'desc' => $this->module->l('Will not multiply image cost by the area of the image', $source),
            ),
            array(
                'name' => 'image_cost',
                'type' => 'input',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Image cost', $source),
                'placeholder' => '--'
            ),
            array(
                'name' => 'image_cost_per_area',
                'type' => 'input',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Image cost per m²', $source),
                'placeholder' => '--',
                'desc' => $this->module->l('Will replace the configured image price', $source),
            ),
            /*array(
                'name'        => 'image-area-intervals',
                'type'        => 'ng'
            ),*/
            array(
                'name' => 'upload_cost',
                'type' => 'input',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Upload cost', $source),
                'placeholder' => '--'
            ),
            array(
                'name' => 'upload_cost_per_area',
                'type' => 'input',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Upload cost per m²', $source),
                'placeholder' => '--'
            ),
            array(
                'name' => 'image_minimal_cost',
                'type' => 'input',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Minimum image cost', $source),
                'placeholder' => '--'
            ),
            array(
                'name' => 'images_total_cost',
                'type' => 'input',
                'class' => 'dsn-ajax-input',
                'controller' => 'product_pricing',
                'label' => $this->module->l('Images total cost', $source),
                'placeholder' => '--'
            ),
        );
    }
}
