<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\panels\product\panels;

use classes\components\ComponentDesign;
use classes\helpers\ProductImageHelper;
use classes\material\MaterialDesign;
use classes\material\MaterialTab;
use classes\models\DesignerProductSide;
use Context;
use ProductDesigner;

class ImagesPanel extends MaterialTab
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    protected $name = 'images';

    public function __construct($module, $context)
    {
        parent::__construct($module, $context);
        ComponentDesign::registerSmartyFunction();
    }

    /**
     * @param MaterialDesign $ui
     * @return string|null
     */
    public function getContent($ui)
    {
        $ui->setComponents(null);
        $id_product = $this->module->state->get('id_product');
        if (!$id_product) {
            return $this->module->messenger->displayNewProductWarning();
        }

        $product_image_helper = new ProductImageHelper($this->module, $this->context);

        $product_images = $product_image_helper->getProductImages($id_product);
        if (!count($product_images)) {
            return $this->module->messenger->displayAddProductImagesWarning();
        }

        $product_sides = DesignerProductSide::getProductSidesWithDefault($id_product, $this->context->language->id);

        $this->context->smarty->assign(array(
            'dsn_loader' => $this->module->provider->getModuleImageUri('icons/loader.svg'),
            'product_images' => $product_images,
            'product_sides' => $product_sides
        ));
        return null;
    }
}
