<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\controllers;

use classes\DesignerTools;
use Configuration;
use ModuleAdminController;
use ProductDesigner;
use Tools;

class DesignerAdminController extends ModuleAdminController
{
    /** @var ProductDesigner */
    public $module;

    public $action;

    public $id_product;

    public $id_default_lang;

    public function __construct()
    {
        parent::__construct();
        $this->context = DesignerTools::getContext();
        $this->action = Tools::getValue('action');
        $this->id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $this->id_product = (int)Tools::getValue('id_product');
        $this->bootstrap = true;
    }

    public function postProcess()
    {
        $method = 'ajaxProcess' . Tools::toCamelCase($this->action, true);
        if (method_exists($this, $method)) {
            return $this->{$method}();
        }

        $method = 'process' . Tools::toCamelCase($this->action, true);
        if (method_exists($this, $method)) {
            return $this->{$method}();
        }

        $this->respond();
    }

    public function respond($data = array())
    {
        $success = (int)!array_key_exists('error', $data) && (int)!array_key_exists('message', $data);
        $result = array(
            'success' => (int)$success,
        );
        if (!isset($result['message'])) {
            if ($success) {
                $result['message'] = $this->module->messenger->getSuccessMessage();
            } else {
                $result['message'] = $this->module->messenger->getErrorMessage();
            }
        }
        $result = array_merge($result, $data);
        exit(Tools::jsonEncode($result));
    }
}
