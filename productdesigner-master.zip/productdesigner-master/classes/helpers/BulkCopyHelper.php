<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\helpers;

use Category;
use classes\models\DesignerArea;
use classes\models\DesignerField;
use classes\models\DesignerImageColor;
use classes\models\DesignerProductColor;
use classes\models\DesignerProductConfig;
use classes\models\DesignerProductFont;
use classes\models\DesignerProductImage;
use classes\models\DesignerProductImageGroup;
use classes\models\DesignerProductPricing;
use classes\models\DesignerProductSide;
use classes\models\DesignerProductTab;
use classes\models\DesignerTextColor;
use classes\models\ImageAreaInterval;
use classes\models\layers\Layer;
use classes\models\layers\LayerGroup;
use classes\models\layers\LayerImage;
use classes\models\RealSize;
use classes\models\SidePricing;
use classes\models\TextAreaInterval;
use Context;
use Product;
use ProductDesigner;
use Tools;

class BulkCopyHelper
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getActiveProductsWithLabels($id_current, $id_lang)
    {
        $result = array();
        $products = array_keys(DesignerProductConfig::getEnabledProducts());
        foreach ($products as $id_product) {
            if ((int)$id_product !== (int)$id_current) {
                $result[] = array(
                    'id_product' => (int)$id_product,
                    'label'      => $id_product . ' - ' . Product::getProductName($id_product, null, $id_lang),
                );
            }
        }
        return $result;
    }

    public function copyProduct($id_target_product, $id_source_product, $copy_images = false)
    {
        $this->copyProductConfig($id_target_product, $id_source_product);

        $this->copyAreas($id_target_product, $id_source_product);
        $this->copyFields($id_target_product, $id_source_product);
        $this->copyImageAreaIntervals($id_target_product, $id_source_product);
        $this->copyImageColors($id_target_product, $id_source_product);
        $this->copyFonts($id_target_product, $id_source_product);
        $this->copyProductColors($id_target_product, $id_source_product);
        $this->copyImageGroups($id_target_product, $id_source_product);
        if ($copy_images) {
            $this->copyImages($id_target_product, $id_source_product);
        }
        $this->copyPricing($id_target_product, $id_source_product);
        $this->copySides($id_target_product, $id_source_product);
        $this->copyTabs($id_target_product, $id_source_product);
        $this->copyRealSizes($id_target_product, $id_source_product);
        $this->copySidePricing($id_target_product, $id_source_product);
        $this->copyTextAreaIntervals($id_target_product, $id_source_product);
        $this->copyTextColors($id_target_product, $id_source_product);
        $this->copyLayers($id_target_product, $id_source_product);
    }

    public function copyProductToCategory($id_target_category, $id_source_product, $copy_images = false)
    {
        $category = new Category($id_target_category);
        $products = $category->getProducts(
            $this->context->language->id,
            0,
            100000000,
            null,
            null,
            false,
            false,
            false,
            1,
            false
        );
        foreach ($products as $product) {
            $id_target_product = (int)$product['id_product'];
            if ($id_target_product !== $id_source_product) {
                $this->copyProduct($id_target_product, $id_source_product, $copy_images);
            }
        }
    }

    private function copyProductConfig($id_target_product, $id_source_product)
    {
        DesignerProductConfig::deleteByProduct($id_target_product);
        $source_product_config = DesignerProductConfig::getByProductID($id_source_product);
        $source_product_config->id_product = $id_target_product;
        $source_product_config->add();
    }

    private function copyAreas($id_target_product, $id_source_product)
    {
        DesignerArea::deleteAllByProduct($id_target_product);
        $product_areas = DesignerArea::getProductAreas($id_source_product);
        foreach ($product_areas as $product_area) {
            $product_area->id_product = $id_target_product;
            $product_area->add();
        }
    }

    private function copyFields($id_target_product, $id_source_product)
    {
        DesignerField::deleteAllByProduct($id_target_product);
        $product_fields = DesignerField::getProductFields($id_source_product);
        foreach ($product_fields as $product_field) {
            $product_field->id_product = $id_target_product;
            $product_field->add();
        }
    }

    private function copyImageAreaIntervals($id_target_product, $id_source_product)
    {
        ImageAreaInterval::deleteAllByProduct($id_target_product);
        $intervals = ImageAreaInterval::getProductIntervals($id_source_product);
        foreach ($intervals as $interval) {
            $interval->id_product = $id_target_product;
            $interval->add();
        }
    }

    private function copyImageColors($id_target_product, $id_source_product)
    {
        DesignerImageColor::deleteAllByProduct($id_target_product);
        $colors = DesignerImageColor::getProductEntries($id_source_product);
        foreach ($colors as $color) {
            $color->id_product = $id_target_product;
            $color->add();
        }
    }

    private function copyFonts($id_target_product, $id_source_product)
    {
        DesignerProductFont::deleteAllByProduct($id_target_product);
        $fonts = DesignerProductFont::getProductEntries($id_source_product);
        foreach ($fonts as $font) {
            $font->id_product = $id_target_product;
            $font->add();
        }
    }

    private function copyProductColors($id_target_product, $id_source_product)
    {
        DesignerProductColor::deleteAllByProduct($id_target_product);
        $colors = DesignerProductColor::getProductEntries($id_source_product);
        foreach ($colors as $color) {
            $color->id_product = $id_target_product;
            $color->add();
        }
    }

    private function copyImageGroups($id_target_product, $id_source_product)
    {
        DesignerProductImageGroup::deleteAllByProduct($id_target_product);
        $image_groups = DesignerProductImageGroup::getProductEntries($id_source_product);
        foreach ($image_groups as $image_group) {
            $image_group->id_product = $id_target_product;
            $image_group->add();
        }
    }

    private function copyImages($id_target_product, $id_source_product)
    {
        DesignerProductImage::deleteAllByProduct($id_target_product);
        $image_helper = new ProductImageHelper($this->module, $this->context);
        $source_images = $image_helper->getProductImages($id_source_product);
        $target_images = $image_helper->getProductImages($id_target_product);
        $source_keys = array_keys($source_images);
        $target_keys = array_keys($target_images);
        foreach ($source_keys as $image_index => $id_source_image) {
            if (isset($target_keys[$image_index])) {
                $this->copyImage($id_target_product, $id_source_product, $target_keys[$image_index], $id_source_image);
            }
        }
    }

    public function copyImage($id_target_product, $id_source_product, $id_target_image, $id_source_image)
    {
        $id_lang = $this->context->language->id;
        $product_images = DesignerProductImage::getByImage($id_source_product, $id_source_image, $id_lang);
        foreach ($product_images as $product_image) {
            $product_image->id_product = $id_target_product;
            $product_image->id_image = $id_target_image;
            $canvas_path = $product_image->getPath('canvas');
            if ($canvas_path) {
                $canvas_filename = $product_image->getFileName($product_image->canvas, 'canvas');
                $new_canvas_path = dirname($canvas_path) . '/' . $canvas_filename;
                Tools::copy($canvas_path, $new_canvas_path);
                $product_image->canvas = basename($new_canvas_path);
            }

            $mask_path = $product_image->getPath('mask');
            if ($mask_path) {
                $new_mask_path = dirname($mask_path) . '/' . $product_image->getFileName($product_image->mask, 'mask');
                Tools::copy($mask_path, $new_mask_path);
                $product_image->mask = basename($new_mask_path);
            }
            $product_image->createNewThumbnails();
            $product_image->add();
        }
    }

    private function copyPricing($id_target_product, $id_source_product)
    {
        DesignerProductPricing::deleteAllByProduct($id_target_product);
        $product_pricing = DesignerProductPricing::getByProductID($id_source_product);
        $product_pricing->id_product = $id_target_product;
        $product_pricing->add();
    }

    private function copySides($id_target_product, $id_source_product)
    {
        DesignerProductSide::deleteAllByProduct($id_target_product);
        $product_sides = DesignerProductSide::getProductEntries($id_source_product);
        foreach ($product_sides as $product_side) {
            $product_side->id_product = $id_target_product;
            $product_side->add();
        }
    }

    private function copyTabs($id_target_product, $id_source_product)
    {
        DesignerProductTab::deleteAllByProduct($id_target_product);
        $product_tabs = DesignerProductTab::getProductEntries($id_source_product);
        foreach ($product_tabs as $product_tab) {
            $product_tab->id_product = $id_target_product;
            $product_tab->add();
        }
    }

    private function copyRealSizes($id_target_product, $id_source_product)
    {
        RealSize::deleteAllByProduct($id_target_product);
        $real_sizes = RealSize::getProductRealSizes($id_source_product);
        foreach ($real_sizes as $real_size) {
            $real_size->id_product = $id_target_product;
            $real_size->add();
        }
    }

    private function copySidePricing($id_target_product, $id_source_product)
    {
        SidePricing::deleteAllByProduct($id_target_product);
        $side_pricings = SidePricing::getProductPricing($id_source_product);
        foreach ($side_pricings as $side_pricing) {
            $side_pricing->id_product = $id_target_product;
            $side_pricing->add();
        }
    }

    private function copyTextAreaIntervals($id_target_product, $id_source_product)
    {
        TextAreaInterval::deleteAllByProduct($id_target_product);
        $intervals = TextAreaInterval::getProductIntervals($id_source_product);
        foreach ($intervals as $interval) {
            $interval->id_product = $id_target_product;
            $interval->add();
        }
    }

    private function copyTextColors($id_target_product, $id_source_product)
    {
        DesignerTextColor::deleteAllByProduct($id_target_product);
        $colors = DesignerTextColor::getProductEntries($id_source_product);
        foreach ($colors as $color) {
            $color->id_product = $id_target_product;
            $color->add();
        }
    }

    private function copyLayers($id_target_product, $id_source_product)
    {
        $layer_groups = LayerGroup::getByProduct($id_target_product);
        foreach ($layer_groups as $layer_group) {
            $layer_group->delete();
        }

        $layer_groups = LayerGroup::getByProduct($id_source_product);
        foreach ($layer_groups as $layer_group) {
            $layers = Layer::getByLayerGroup($layer_group->id);
            $layer_group->id_product = $id_target_product;
            $layer_group->add();
            foreach ($layers as $layer) {
                $layer_images = LayerImage::getByLayer($layer->id);
                $layer->id_layer_group = $layer_group->id;
                $layer->add();
                foreach ($layer_images as $layer_image) {
                    $layer_image->copyToLayer($layer->id);
                }
            }
        }
    }
}
