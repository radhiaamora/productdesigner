<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\helpers;

use classes\DesignerTools;
use classes\models\DesignerProductImage;
use classes\models\DesignerProductSide;
use classes\models\DesignerSide;
use Context;
use Image;
use ImageType;
use Product;
use ProductDesigner;
use Tools;

class ProductImageHelper
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public static function getAttributeImages($id_product, $id_product_attribute)
    {
        $attribute_images = array();
        $context = DesignerTools::getContext();
        $id_image = self::getAttributeImageID($id_product, $id_product_attribute);
        $product_images = DesignerProductImage::getByImage($id_product, $id_image, $context->language->id);
        $product_sides = DesignerProductSide::getProductSidesWithDefault($id_product);
        foreach ($product_images as $product_image) {
            if (isset($product_sides[$product_image->id_side])) {
                $attribute_images[$product_image->id_side] = $product_image;
            }
        }
        // fill empty sides with default image
        foreach ($product_sides as $product_side) {
            $id_side = $product_side->id;
            $designer_side = new DesignerSide($id_side);
            if (!isset($attribute_images[$id_side])) {
                $attribute_images[$designer_side->position] = DesignerProductImage::createForSide(
                    $id_product,
                    $id_image,
                    $id_side
                );
            }
        }

        ksort($attribute_images);

        return $attribute_images;
    }

    /**
     * @param $id_product
     * @param $id_product_attribute
     * @param $id_side
     * @return DesignerProductImage
     */
    public static function getSideImage($id_product, $id_product_attribute, $id_side)
    {
        $id_image = self::getAttributeImageID($id_product, $id_product_attribute);
        return DesignerProductImage::getByImageAndSide($id_product, $id_image, $id_side);
    }

    public static function getAttributeImageID($id_product, $id_product_attribute)
    {
        $context = DesignerTools::getContext();
        $attribute_image = Product::getCombinationImageById(
            $id_product_attribute,
            $context->language->id
        );
        if (!$attribute_image) {
            return self::getProductCover($id_product);
        }
        return isset($attribute_image['id_image']) ? (int)$attribute_image['id_image'] : false;
    }

    public static function getDefaultImage($id_product, $id_image)
    {
        $image_link = self::getImageLink($id_product, $id_image);
        return self::replaceCDN($image_link);
    }

    private static function replaceCDN($image_link)
    {
        $url = Tools::usingSecureMode() ? Tools::getShopDomainSsl() : Tools::getShopDomain();
        return str_replace(array(_MEDIA_SERVER_1_, _MEDIA_SERVER_2_, _MEDIA_SERVER_3_), $url, $image_link);
    }

    public static function getDefaultImagePath($id_image)
    {
        return self::getImagePath($id_image);
    }

    private static function getImageLink($id_product, $id_image)
    {
        if (!$id_image) {
            return false;
        }
        $context = DesignerTools::getContext();
        $product = new Product($id_product, false, $context->language->id);
        return $context->link->getImageLink(
            $product->link_rewrite,
            $id_image,
            ImageType::getFormattedName('large')
        );
    }

    private static function getImagePath($id_image)
    {
        $image = new Image($id_image);
        $image_type = ImageType::getFormattedName('large');
        return _PS_IMG_DIR_ . 'p/' . $image->getExistingImgPath() . '-' . $image_type . '.' . $image->image_format;
    }

    /**
     * @param $id_product
     * @return array[cover, id_image, link]
     */
    public function getProductImages($id_product)
    {
        $product = new Product($id_product, false, $this->context->language->id);
        $product_images = array();

        // add the cover
        $id_cover = (int)self::getProductCover($id_product);
        if ($id_cover) {
            $product_images[$id_cover] = array(
                'id_image' => $id_cover
            );
        }

        $combination_images_list = $product->getCombinationImages($this->context->language->id);
        if ($combination_images_list) {
            foreach ($combination_images_list as $combination_images) {
                /** @noinspection LoopWhichDoesNotLoopInspection */
                foreach ($combination_images as $product_image) {
                    if (!isset($product_images[$product_image['id_image']])) {
                        $product_images[$product_image['id_image']] = $product_image;
                    }
                    // necessary to avoid duplicating product images in the backend
                    break;
                }
            }
        }

        $product_images = $this->assignImagesLinks($product, $product_images);
        $product_images = $this->assignProductID($product, $product_images);
        return $product_images;
    }

    private static function getProductCover($id_product)
    {
        $cover = Product::getCover($id_product);
        if (!$cover) {
            return false;
        }
        return (int)$cover['id_image'];
    }

    /**
     * @param Product $product
     * @param array $product_images
     * @return array
     */
    private function assignImagesLinks($product, $product_images)
    {
        foreach ($product_images as &$product_image) {
            $product_image['link'] = $this->context->link->getImageLink(
                $product->link_rewrite,
                $product_image['id_image'],
                ImageType::getFormattedName('large')
            );
        }
        return $product_images;
    }

    /**
     * @param Product $product
     * @param array $product_images
     * @return array
     */
    private function assignProductID($product, $product_images)
    {
        foreach ($product_images as &$product_image) {
            $product_image['id_product'] = (int)$product->id;
        }
        return $product_images;
    }
}
