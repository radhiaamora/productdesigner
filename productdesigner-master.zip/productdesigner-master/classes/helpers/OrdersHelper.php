<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\helpers;

use Db;

class OrdersHelper extends DesignerHelper
{
    public function getCustomizedOrders()
    {
        $orders = array();
        $prefix = _DB_PREFIX_;
        $sql = "SELECT DISTINCT o.id_order, d.id_design, c.id_customization FROM {$prefix}{$this->module->name}_design d
            JOIN {$prefix}customized_data cd ON cd.value = d.id_design
            JOIN {$prefix}customization c ON c.id_customization = cd.id_customization
            JOIN {$prefix}orders o ON o.id_cart = d.id_cart
            WHERE c.in_cart = 1";
        $result = Db::getInstance()->executeS($sql);
        if (is_array($result)) {
            foreach ($result as $item) {
                $orders[] = (int)$item['id_order'];
            }
        }
        return $orders;
    }
}
