<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\helpers;

use Tools;

class SvgImageHelper
{
    public static function getType($image_path)
    {
        return pathinfo($image_path, PATHINFO_EXTENSION) === 'svg' ? 'svg' : 'image';
    }

    public static function getSize($path)
    {
        return self::getType($path) === 'svg' ? self::getSvgSize($path) : self::getImageSize($path);
    }

    public static function getSvgSize($path)
    {
        $xml = simplexml_load_string(Tools::file_get_contents($path));
        $attributes = $xml->attributes();
        $width = $attributes->width;
        $height = $attributes->height;
        if (!$width || !$height) {
            $viewbox = $attributes->viewBox;
            $dimensions = explode(' ', $viewbox);
            $width = $dimensions[2];
            $height = $dimensions[3];
        }
        return array(
            'width'  => preg_replace('/[^0-9,.]/', '', $width),
            'height' => preg_replace('/[^0-9,.]/', '', $height)
        );
    }

    public static function getSvgRatio($path)
    {
        $svg_size = self::getSvgSize($path);
        $ratio = $svg_size['width'] / $svg_size['height'];
        return is_nan($ratio) ? 1 : $ratio;
    }

    public static function getImageSize($path)
    {
        list($width, $height) = getimagesize($path);
        return array(
            'width'  => $width,
            'height' => $height
        );
    }

    public static function getImageRatio($path)
    {
        list($width, $height) = getimagesize($path);
        $ratio = $width / $height;
        return is_nan($ratio) ? 1 : $ratio;
    }
}
