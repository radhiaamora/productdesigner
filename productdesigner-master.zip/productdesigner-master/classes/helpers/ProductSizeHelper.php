<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\helpers;

use classes\models\design\Design;
use classes\models\DesignerProductConfig;
use classes\models\RealSize;
use Context;
use ProductDesigner;
use Validate;

class ProductSizeHelper
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param int $id_product
     * @param Design $design
     * @param RealSize $real_size
     * @param float $product_image
     */
    public function getFullSize($id_product, $design, $real_size, $ratio)
    {
        $product_config = DesignerProductConfig::getByProductID($id_product);
        $design_size = $design->design_size;
        if ($product_config->enable_product_size && Validate::isLoadedObject($design_size)) {
            return array(
                'width'  => $design_size->width,
                'height' => $design_size->height,
                'ratio'  => $design_size->width / $design_size->height
            );
        }
        return array(
            'width'  => $real_size->getFullWidth(),
            'height' => $real_size->getFullHeight($ratio),
            'ratio'  => $ratio
        );
    }
}
