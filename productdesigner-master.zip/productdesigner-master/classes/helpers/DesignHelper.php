<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\helpers;

use classes\DesignerTools;
use classes\models\design\Design;
use classes\models\design\DesignColor;
use classes\models\design\DesignContainer;
use classes\models\design\DesignElement;
use classes\models\design\DesignImage;
use classes\models\design\DesignSize;
use classes\models\design\DesignText;
use classes\models\DesignerProductConfig;
use classes\models\layers\DesignLayer;
use classes\models\layers\Layer;
use Context;
use Db;
use DbQuery;
use ProductDesigner;
use RuntimeException;

class DesignHelper
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param $design_data
     * @return Design
     */
    public static function collectData($design_data)
    {
        $design = new Design();
        $design->copyFromPost();

        $containers = $design_data['containers'];
        $design_containers = array();
        foreach ($containers as $container) {
            if (!DesignContainer::isEmpty($container)) {
                $design_container = new DesignContainer();
                $design_container->copyFromArray($container);

                $design_elements = $container['design_elements'];
                $container_design_items = array();
                foreach ($design_elements as $design_item_data) {
                    $design_element = new DesignElement();
                    $design_element->copyFromArray($design_item_data);

                    if ($design_item_data['category'] === 'text') {
                        $design_text = new DesignText();
                        $design_text->copyFromArray($design_item_data);
                        $design_element->setDesignItem($design_text);
                    }

                    if ($design_item_data['category'] === 'image') {
                        $design_image = new DesignImage();
                        $design_image->copyFromArray($design_item_data);
                        $design_element->setDesignItem($design_image);
                    }
                    $container_design_items[] = $design_element;
                }
                $design_container->setDesignElements($container_design_items);
                $design_containers[] = $design_container;
            }
            $design->setContainers($design_containers);
        }

        if (isset($design_data['size'])) {
            $design_size_data = $design_data['size'];
            $design_size = new DesignSize();
            $design_size->id_design = (int)$design->id;
            $design_size->width = (float)$design_size_data['width'];
            $design_size->height = (float)$design_size_data['height'];
            $design->setDesignSize($design_size);
        }

        if (isset($design_data['color'])) {
            $design_color_data = $design_data['color'];
            $design_color = new DesignColor();
            $design_color->id_design = (int)$design->id;
            $design_color->id_color = (int)$design_color_data['id_color'];
            $design_color->color = $design_color_data['color'];
            $design->setDesignColor($design_color);
        }

        if (isset($design_data['layers'])) {
            $design_layers = array();
            $selected_layers = $design_data['layers'];
            if (is_array($selected_layers)) {
                foreach ($selected_layers as $layer) {
                    $layerObj = new Layer($layer['id_layer']);
                    $design_layer = new DesignLayer();
                    $design_layer->id_design = (int)$design->id;
                    $design_layer->id_layer_group = (int)$layerObj->id_layer_group;
                    $design_layer->id_layer = (int)$layerObj->id;
                    $design_layer->position = (int)$layer['position'];
                    $design_layers[] = $design_layer;
                }
            }
            $design->setDesignLayers($design_layers);
        }

        return $design;
    }

    /**
     * @param $id_design
     * @return Design
     */
    public static function loadDesign($id_design)
    {
        $design = new Design($id_design);
        $design->assignContainers();
        $design->assignDesignSize();
        $design->assignDesignColor();
        $design->assignDesignLayers();
        return $design;
    }

    public static function reorderDesigns($id_cart_new, $id_cart_old)
    {
        $designs = Design::getDesignsByCart($id_cart_old);
        foreach ($designs as $design) {
            $id_design_old = $design->id;
            $design->id_cart = $id_cart_new;
            $design->duplicate();

            $sql = new DbQuery();
            $sql->select('id_customization');
            $sql->from('customized_data');
            $sql->where('value = ' . (int)$id_design_old);
            $sql->where('id_customization != ' . (int)$design->id_customization);
            $id_customization = (int)Db::getInstance()->getValue($sql);
            if ($id_customization) {
                $design->id_customization = $id_customization;
                $design->save();
            }
            Db::getInstance()->update(
                'customized_data',
                array(
                    'value' => (int)$design->id
                ),
                'value = ' . (int)$id_design_old . '
                AND id_customization = ' . (int)$id_customization
            );
        }
    }

    public function saveDesignFromRequest($id_product, $design_data, $id_edit_design)
    {
        $design = self::collectData($design_data);
        $containers = $design_data['containers'];
        $product_config = DesignerProductConfig::getByProductID($id_product);
        $has_product_color = !$design->design_color->isEmpty();
        $has_product_size = $design->design_size->hasValues();

        $is_design_empty = Design::isEmpty($containers) && !$has_product_color && !$has_product_size;

        if ($is_design_empty) {
            if (!(int)$product_config->enable_layers) {
                throw new RuntimeException(
                    $this->module->l('Please add some design items first', DesignerTools::getSource())
                );
            }

            if ((int)$product_config->enable_layers) {
                $layers = isset($design_data['layers']) ? $design_data['layers'] : null;
                if (!$layers || !count($layers)) {
                    throw new RuntimeException(
                        $this->module->l(
                            'Please add some design items or pick a product option',
                            DesignerTools::getSource()
                        )
                    );
                }
            }
        }

        if ($id_edit_design) {
            $edit_design = new Design($id_edit_design);
            $edit_design->deleteFromCart();
            $edit_design->assignContainers();
            $edit_design->assignDesignSize();
            $edit_design->assignDesignColor();
            $edit_design->assignDesignLayers();
            $edit_design->delete();
        }

        $design->id_customer = $this->module->provider->getCustomer();
        $design->id_guest = $this->module->provider->getGuest();
        $design->saveAll();
        return $design;
    }
}
