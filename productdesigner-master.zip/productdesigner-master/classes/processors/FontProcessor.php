<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\processors;

use classes\DesignerTools;
use classes\models\DesignerFont;
use Context;
use Exception;
use ProductDesigner;
use Validate;

class FontProcessor extends DesignProcessor
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    protected static $name = 'font';

    public function processSave($redirect = true)
    {
        /** @var DesignerFont $designer_font */
        $designer_font = parent::processSave(false);
        if (Validate::isLoadedObject($designer_font) && empty($designer_font->family)) {
            if (!$designer_font->getPath()) {
                $this->module->messenger->addError(
                    $this->module->l('Could not find the font file', DesignerTools::getSource())
                );
            } else {
                try {
                    $font_family = $designer_font->getFontFamily();
                    $designer_font->family = $font_family;
                    $designer_font->save();
                    $this->module->messenger->redirectToConfirmation(4, self::$name);
                } catch (Exception $e) {
                    $this->module->messenger->addError(
                        $this->module->l('Could not parse the font', DesignerTools::getSource())
                    );
                }
            }
        }

        if (Validate::isLoadedObject($designer_font) && !empty($designer_font->family) && $redirect) {
            $this->module->messenger->redirectToConfirmation(4, self::$name);
        }
    }
}
