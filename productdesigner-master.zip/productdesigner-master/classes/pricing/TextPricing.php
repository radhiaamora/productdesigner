<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\pricing;

use classes\helpers\TextAreaIntervalHelper;
use classes\models\design\DesignText;
use classes\models\DesignerProductPricing;
use Context;
use ProductDesigner;
use Tools;

class TextPricing
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    /** @var DesignText */
    private $design_element;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param DesignText $design_text
     * @param DesignerProductPricing $pricing
     * @param $container_area
     */
    public function getPrice($pricing, $container_area)
    {
        $price = 0;
        if ($pricing->text_cost_per_area !== null) {
            $price += $this->getAreaCost($pricing->text_cost_per_area, $container_area);
        }

        $price += $this->getAreaIntervalCost($pricing->id_product, $container_area);

        if ($pricing->text_cost !== null) {
            $price += (float)$pricing->text_cost;
        }
        if ($pricing->text_character_cost !== null) {
            $price += $this->getCharactersCost($pricing->text_character_cost);
        }
        if ($pricing->text_minimal_cost !== null) {
            $price = max((float)$pricing->text_minimal_cost, $price);
        }
        return $price;
    }

    private function getAreaCost($cost_per_area, $container_area)
    {
        $area = $this->design_element->getArea($container_area);
        return $area * (float)$cost_per_area;
    }

    private function getAreaIntervalCost($id_product, $container_area)
    {
        $area = $this->design_element->getArea($container_area) ;
        $area_interval_helper = new TextAreaIntervalHelper($this->module, $this->context);
        $interval_area_cost = (float)$area_interval_helper->getAreaCost($id_product, $area * 10000);
        return $area * $interval_area_cost;
    }

    private function getCharactersCost($character_cost)
    {
        $text = preg_replace('/\s*/m', '', $this->design_element->text);
        $text_length = Tools::strlen($text);
        return $text_length * (float)$character_cost;
    }

    /**
     * @return DesignText
     */
    public function getDesignElement()
    {
        return $this->design_element;
    }

    /**
     * @param DesignText $design_element
     */
    public function setDesignElement($design_element)
    {
        $this->design_element = $design_element;
    }
}
