<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\pricing;

use classes\models\design\Design;
use classes\models\design\DesignContainer;
use classes\models\DesignerProductPricing;
use classes\models\layers\Layer;
use classes\models\SideCombination;
use classes\models\SidePricing;
use Context;
use ProductDesigner;
use Validate;

class DesignPricing
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    /** @var Design */
    public $design;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @return Design
     */
    public function getDesign()
    {
        return $this->design;
    }

    /**
     * @param Design $design
     */
    public function setDesign($design)
    {
        $this->design = $design;
    }

    public function getPrice()
    {
        $price = 0;
        $pricing = DesignerProductPricing::getByProductID($this->design->id_product);
        $design_containers = $this->design->getContainers();
        $price += $this->addProductSizeCost($pricing, $this->design);
        $price += $this->addContainersCost($design_containers);
        $price += $this->addDesignElementsCost($pricing, $design_containers);
        $price += $this->addTextsTotalPrice($pricing);
        $price += $this->addImagesTotalPrice($pricing);
        $price += $this->addSidesPrices($this->design->id_product, $design_containers);
        $price += $this->addSidesCombinationsPrices($this->design->id_product, $design_containers);
        $price += $this->addLayersPrices();
        $price += $this->addLayersExtraPrice($pricing);
        return $price;
    }

    /**
     * @param DesignerProductPricing $pricing
     * @param Design $design
     */
    public function addProductSizeCost($pricing, $design)
    {
        return $pricing->product_cost_per_area * $design->design_size->getArea();
    }

    /**
     * @param DesignContainer[] $design_containers
     * @return float
     */
    public function addContainersCost($design_containers)
    {
        $price = 0;
        foreach ($design_containers as $container) {
            $price += $container->getCost();
        }
        return $price;
    }

    /**
     * @param DesignerProductPricing $pricing
     * @param DesignContainer[] $design_containers
     * @return float
     */
    public function addDesignElementsCost($pricing, $design_containers)
    {
        $price = 0;
        foreach ($design_containers as $container) {
            if ($container->includesElementsCost()) {
                $design_area = $this->design->getArea($container->id_side);
                foreach ($container->getDesignElements() as $design_item) {
                    $price += $design_item->getPrice($pricing, $container->getArea($design_area));
                }
            }
        }
        return $price;
    }

    /**
     * @param DesignerProductPricing $pricing
     */
    private function addTextsTotalPrice($pricing)
    {
        foreach ($this->design->getContainers() as $container) {
            foreach ($container->getDesignElements() as $design_item) {
                if ($design_item->category === 'text') {
                    return $pricing->texts_total_cost;
                }
            }
        }
        return 0;
    }

    /**
     * @param DesignerProductPricing $pricing
     */
    private function addImagesTotalPrice($pricing)
    {
        foreach ($this->design->getContainers() as $container) {
            foreach ($container->getDesignElements() as $design_item) {
                if ($design_item->category === 'image') {
                    return $pricing->images_total_cost;
                }
            }
        }
        return 0;
    }

    /**
     * @param int $id_product
     * @param DesignContainer[] $design_containers
     */
    private function addSidesPrices($id_product, $design_containers)
    {
        $cost = 0;
        foreach ($design_containers as $container) {
            $design_elements = $container->getDesignElements();
            if (count($design_elements)) {
                $cost += SidePricing::getSideCost($id_product, $container->id_side)->cost;
            }
        }
        return $cost;
    }

    /**
     * @param int $id_product
     * @param DesignContainer[] $design_containers
     */
    private function addSidesCombinationsPrices($id_product, $design_containers)
    {
        $cost = 0;
        $sides = array();
        foreach ($design_containers as $container) {
            $design_elements = $container->getDesignElements();
            if (count($design_elements)) {
                $sides[] = $container->id_side;
            }
        }
        if (count($sides)) {
            $combination = SideCombination::getCombinationWithSides($id_product, $sides);
            if (Validate::isLoadedObject($combination)) {
                $cost += $combination->cost;
            }
        }
        return $cost;
    }

    private function addLayersPrices()
    {
        $cost = 0;
        foreach ($this->design->design_layers as $design_layer) {
            $layer = new Layer($design_layer->id_layer);
            $cost += $layer->price;
        }
        return $cost;
    }

    /**
     * @param DesignerProductPricing $pricing
     * @return float
     */
    private function addLayersExtraPrice($pricing)
    {
        if (count($this->design->design_layers) >0) {
            return $pricing->layers_extra_cost;
        }
        return 0;
    }
}
