<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\pricing;

use classes\helpers\ImageAreaIntervalHelper;
use classes\models\design\DesignImage;
use classes\models\DesignerProductPricing;
use Context;
use ProductDesigner;

class ImagePricing
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    /** @var DesignImage */
    private $design_element;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param DesignImage $design_text
     * @param DesignerProductPricing $pricing
     * @param $container_area
     */
    public function getPrice($pricing, $container_area)
    {
        $price = 0;
        if (!$pricing->use_image_cost) {
            if (!$this->design_element->upload && $pricing->image_cost_per_area !== null) {
                $price += $this->getAreaCost($pricing->image_cost_per_area, $container_area);
            } else {
                $price += $this->getAreaCost($this->design_element->getImagePriceByArea($pricing), $container_area);
            }
        } else {
            $price += $this->design_element->getImagePrice($pricing);
        }

        $price += $this->getAreaIntervalCost($pricing->id_product, $container_area);

        if ($pricing->image_cost !== null) {
            $price += (float)$pricing->image_cost;
        }
        if ($pricing->image_minimal_cost !== null) {
            $price = max((float)$pricing->image_minimal_cost, $price);
        }
        return $price;
    }

    private function getAreaCost($cost_per_area, $container_area)
    {
        $area = $this->design_element->getArea($container_area);
        return $area * (float)$cost_per_area;
    }

    private function getAreaIntervalCost($id_product, $container_area)
    {
        $area = $this->design_element->getArea($container_area);
        $area_interval_helper = new ImageAreaIntervalHelper($this->module, $this->context);
        $interval_area_cost = (float)$area_interval_helper->getAreaCost($id_product, $area * 10000);
        return $area * $interval_area_cost;
    }

    /**
     * @return DesignImage
     */
    public function getDesignElement()
    {
        return $this->design_element;
    }

    /**
     * @param DesignImage $design_element
     */
    public function setDesignElement($design_element)
    {
        $this->design_element = $design_element;
    }
}
