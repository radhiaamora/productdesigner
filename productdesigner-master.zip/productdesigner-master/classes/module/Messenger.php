<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use classes\DesignerTools;
use Context;
use ProductDesigner;
use Tools;

class Messenger
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    /* messages */
    public $confirmations = array();
    public $informations = array();
    public $warnings = array();
    public $errors = array();

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getMessages()
    {
        $output = '';
        $output .= $this->displayConfirmations();
        $output .= $this->displayWarnings();
        $output .= $this->displayErrors();
        return $output;
    }

    public function redirectToConfirmation($conf, $name)
    {
        Tools::redirect($this->module->provider->getModuleAdminLink("conf={$conf}#{$name}s"));
        exit();
    }

    private function displayConfirmations()
    {
        if (!is_array($this->confirmations)) {
            return false;
        }
        $output = '';
        foreach ($this->confirmations as $confirmation) {
            $output .= $this->module->displayConfirmation($confirmation);
        }
        return $output;
    }

    private function displayWarnings()
    {
        if (!is_array($this->warnings)) {
            return false;
        }
        $output = '';
        foreach ($this->warnings as $warning) {
            $output .= $this->module->displayWarning($warning);
        }
        return $output;
    }

    private function displayErrors()
    {
        if (!is_array($this->errors)) {
            return false;
        }
        $output = '';
        foreach ($this->errors as $error) {
            $output .= $this->module->displayError($error);
        }
        return $output;
    }

    public function displayNewProductWarning()
    {
        return $this->module->displayWarning(
            $this->module->l('You will be able to configure this product once you save it', DesignerTools::getSource())
        );
    }

    public function displayAddProductImagesWarning()
    {
        return $this->module->displayWarning(
            $this->module->l('Start by adding product images then retry', DesignerTools::getSource())
        );
    }

    public function addConfirmation()
    {
        $this->confirmations[] =
        $this->module->l('Item saved successfully', DesignerTools::getSource());
    }

    public function addError($errors)
    {
        if (!is_array($errors)) {
            $errors = array($errors);
        }
        foreach ($errors as $error) {
            $this->errors[] = $error;
        }
    }

    public function getSuccessMessage()
    {
        return $this->module->l('Data saved successfully', DesignerTools::getSource());
    }

    public function getErrorMessage()
    {
        return $this->module->l('An error occurred', DesignerTools::getSource());
    }
}
