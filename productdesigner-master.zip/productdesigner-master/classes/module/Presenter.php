<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use classes\presenters\DesignPresenter;
use Context;
use ProductDesigner;
use Tools;

class Presenter
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getCurrentAction()
    {
        $values = array_merge($_POST, $_GET);
        $keys = array_keys($values);
        foreach ($keys as $key) {
            if (strpos($key, 'update') === 0) {
                // return current action
                return str_replace('update', '', $key);
            }
            if ($key === 'action') {
                return str_replace('update', '', $values[$key]);
            }
        }
        return false;
    }

    public function displayUpdateForm($action)
    {
        $namescape = 'classes\presenters\\';
        $class_name = $namescape . Tools::toCamelCase($action, true) . 'Presenter';
        /** @var DesignPresenter $presenter */
        $presenter = new $class_name($this->module, $this->context);
        return $presenter->display();
    }
}
