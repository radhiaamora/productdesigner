<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use Category;
use classes\DesignerTools;
use classes\helpers\DesignHelper;
use Configuration;
use Context;
use Cookie;
use Currency;
use Db;
use DbQuery;
use Dispatcher;
use Guest;
use Product;
use ProductDesigner;
use Tab;
use Tools;
use Validate;

class Provider
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    private $products_cache = array();

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getModuleAdminLink($parameter = '', $with_token = true)
    {
        $admin_modules = $this->context->link->getAdminLink('AdminModules', $with_token);
        $link = $admin_modules .
            '&configure=' . urlencode($this->module->name)
            . ($parameter ? '&' : '') . $parameter;
        $link = str_replace('&#', '#', $link);
        return $link;
    }

    public function getModuleAdminToken()
    {
        return Tools::getAdminTokenLite('AdminModules');
    }

    public function getControllerAdminLink($controller, $params = array())
    {
        $params['token'] = Tools::getAdminTokenLite($controller);
        $id_lang = $this->context->language->id;
        $link = Dispatcher::getInstance()->createUrl($controller, $id_lang, $params);
        $base_link = $this->getAdminBaseLink();
        return $base_link . basename(_PS_ADMIN_DIR_) . '/' . $link;
    }

    public function getAdminBaseLink()
    {
        $https = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $current_link = $https . "://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $admin_dirname = basename(_PS_ADMIN_DIR_);
        $parts = explode("/$admin_dirname/", $current_link, 2);
        return isset($parts[0]) ? $parts[0] . '/' : false;
    }

    public function getModuleFile($file)
    {
        return $this->module->getDir() . $file;
    }

    public function getDataFile($file)
    {
        return _PS_ROOT_DIR_ . '/designer/' . $file;
    }

    public function getDataFileUri($file)
    {
        return $this->context->shop->getBaseURI() . 'designer/' . $file;
    }

    public function getDataDir($folder = '')
    {
        return _PS_ROOT_DIR_ . '/designer/' . $folder . (Tools::strlen($folder) ? '/' : '');
    }

    public function getDataDirUri($folder = '')
    {
        return $this->context->shop->getBaseURI() . 'designer/' . $folder . (Tools::strlen($folder) ? '/' : '');
    }

    public function getModuleDirUri($folder = '')
    {
        return $this->module->getPathUri() . $folder . ($folder ? '/' : '');
    }

    public function getModuleDirPath($folder = '')
    {
        return $this->module->getDir() . $folder . ($folder ? '/' : '');
    }

    public function getModuleImageUri($image)
    {
        return $this->getModuleDirUri('views/img') . $image;
    }

    public function getCustomer()
    {
        return $this->context->cookie ? (int)$this->context->cookie->id_customer : 0;
    }

    public function getGuest()
    {
        $id_guest = $this->context->cookie ? (int)$this->context->cookie->id_guest : 0;
        if (!$id_guest && class_exists('Guest')) {
            Guest::setNewGuest($this->context->cookie);
        }
        return $this->context->cookie ? (int)$this->context->cookie->id_guest : 0;
    }

    public function getCurrency()
    {
        $id_currency = (int)$this->context->currency->id;
        return $id_currency ?: Currency::getDefaultCurrency()->id;
    }

    public function getCountry()
    {
        if (method_exists('Tools', 'getCountry')) {
            return Tools::getCountry();
        }
        return null;
    }

    public function getCart()
    {
        $cart = $this->context->cart;
        if (Validate::isLoadedObject($cart)) {
            return $cart->id;
        }
        return null;
    }

    public function getPixelImage()
    {
        return $this->module->getPathUri() . 'views/img/pixel.png';
    }

    public function getPixelImagePath()
    {
        return $this->module->getDir() . 'views/img/pixel.png';
    }

    public function getShopUrl()
    {
        $shop = $this->context->shop;
        $url = Tools::usingSecureMode() ? 'https://' : 'http://';
        $url .= Tools::usingSecureMode() ? $shop->domain_ssl : $shop->domain;
        return $url;
    }

    public function getJson($filename)
    {
        $path = $this->getDataDir('json') . $filename . '.json';
        return json_decode(Tools::file_get_contents($path), true);
    }

    public function shouldDisplaySummary($controller)
    {
        $cart_controllers = array(
            'cart',
            'orderconfirmation'
        );
        return in_array($controller, $cart_controllers, true);
    }

    public function getCurrentProductID()
    {
        $id_product = 0;

        $path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO']: null;
        if (!$path) {
            $path = isset($_SERVER['ORIG_PATH_INFO']) ? $_SERVER['ORIG_PATH_INFO']: null;
        }
        if (!$path) {
            $path = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI']: null;
        }

        $matched = preg_match("/\/products\/(\d+)/", $path, $matches);
        if ($matched) {
            $id_product = (int)$matches[1];
        }

        if (!$id_product) {
            $id_product = (int)str_replace('/product/form/', '', $path);
        }

        if (!$id_product) {
            $matched = preg_match("/id_product=(\d+)/", $path, $matches);
            if ($matched) {
                $id_product = (int)$matches[1];
            }
        }
        return $id_product;
    }

    public function getProduct($id_product)
    {
        if (isset($this->products_cache[$id_product])) {
            return $this->products_cache[$id_product];
        }
        return $this->products_cache[$id_product] = new Product($id_product);
    }

    public function getProductLink($id_product, $id_attribute = null, $params = null)
    {
        $id_lang = $this->context->language->id;
        $product = new Product($id_product, false, $id_lang);
        $product_link = $this->context->link->getProductLink(
            $product,
            $product->link_rewrite,
            Category::getLinkRewrite($product->id_category_default, $id_lang),
            null,
            $id_lang,
            (int)Context::getContext()->shop->id,
            (int)$id_attribute ?: Product::getDefaultAttribute($id_product),
            (bool)Configuration::get('PS_REWRITING_SETTINGS')
        );
        if ($params) {
            return DesignerTools::addQueryToUrl($product_link, $params);
        }
        return $product_link;
    }

    public function getEditDesign()
    {
        if (Tools::getIsset('edit_design')) {
            $id_design = (int)Tools::getValue('edit_design');
            $design = DesignHelper::loadDesign($id_design);
            if (Validate::isLoadedObject($design)) {
                if ($design->validateCustomerPermission()) {
                    return $design;
                }
            } else {
                return false;
            }
        }
        return false;
    }

    public function isDuplicateRequest()
    {
        if (!isset($_SERVER['PATH_INFO'])) {
            return false;
        }
        $PATH_INFO = $_SERVER['PATH_INFO'];
        return
            strpos($PATH_INFO, '/products/unit/duplicate/') !== false ||
            strpos($PATH_INFO, '/product/unit/duplicate/') !== false;
    }

    public function getProductIdFromDuplicateRequest()
    {
        $id_product = (int)Tools::getValue('id_product');
        return $id_product ?: (int)str_replace(
            array(
                '/sell/catalog/products/unit/duplicate/',
                '/product/unit/duplicate/'
            ),
            '',
            $_SERVER['PATH_INFO']
        );
    }

    public function getCleanName($name)
    {
        $result = str_replace(array('-', '_'), ' ', $name);
        return Tools::ucfirst($result);
    }

    public function getCleanPrice($price)
    {
        return (float)str_replace(',', '.', $price);
    }

    public function getTabID($class_name)
    {
        $sql = new DbQuery();
        $sql->select('id_tab');
        $sql->from('tab');
        $sql->where('class_name = "' . pSQL($class_name) . '"');
        $id_tab = (int)Db::getInstance()->getValue($sql);
        return $id_tab ?: -1;
    }

    public function isAdmin()
    {
        $cookie = new Cookie('psAdmin');
        if ((int)$cookie->id_employee) {
            // we have an employee in the cookie
            return true;
        }

        // we need to check the adtoken if any
        return $this->checkAdminToken();
    }

    public function checkAdminToken()
    {
        $adtoken = Tools::getValue('adtoken');
        $admin_token = Tools::getAdminToken(
            'AdminProducts' . (int)Tab::getIdFromClassName('AdminProducts') . (int)Tools::getValue('id_employee')
        );
        return $adtoken === $admin_token;
    }
}
