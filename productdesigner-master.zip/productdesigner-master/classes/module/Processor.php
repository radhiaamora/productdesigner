<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use classes\processors\DesignProcessor;
use Context;
use ProductDesigner;
use Tools;

class Processor
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getCurrentAction($context)
    {
        $values = array_merge($_POST, $_GET);
        $keys = array_keys($values);
        foreach ($keys as $key) {
            if (strpos($key, $context) === 0) {
                // return current action
                return str_replace($context, '', $key);
            }
            if ($key === 'action') {
                return str_replace($context, '', $values[$key]);
            }
        }
        return false;
    }

    public function getPositionAction()
    {
        return Tools::getValue('action') === 'updatePositions';
    }

    private function getClassName($action)
    {
        $namescape = 'classes\processors\\';
        return $namescape . Tools::toCamelCase($action, true) . 'Processor';
    }

    private function getPositionsIdentifier()
    {
        foreach ($_POST as $key => $value) {
            if (is_array($value)) {
                return $key;
            }
        }
        return false;
    }

    public function processSubmit($action)
    {
        $class_name = $this->getClassName($action);

        $method = Tools::getValue('method') ?: 'save';
        $class_method = 'process' . Tools::toCamelCase($method, true);

        /** @var DesignProcessor $processor */
        $processor = new $class_name($this->module, $this->context);
        return $processor->$class_method();
    }

    public function processDelete($action)
    {
        $class_name = $this->getClassName($action);
        /** @var DesignProcessor $processor */
        $processor = new $class_name($this->module, $this->context);
        /** @noinspection PhpVoidFunctionResultUsedInspection */
        return $processor->processDelete();
    }

    public function processStatus($action)
    {
        $class_name = $this->getClassName($action);
        /** @var DesignProcessor $processor */
        $processor = new $class_name($this->module, $this->context);
        /** @noinspection PhpVoidFunctionResultUsedInspection */
        return $processor->processStatus();
    }

    public function processPosition()
    {
        $identifier = $this->getPositionsIdentifier();
        if (!$identifier) {
            return false;
        }

        $order = Tools::getValue($identifier);

        $class_name = $this->getClassName($identifier);
        /** @var DesignProcessor $processor */
        $processor = new $class_name($this->module, $this->context);
        /** @noinspection PhpVoidFunctionResultUsedInspection */
        return $processor->processPositions($order);
    }
}
