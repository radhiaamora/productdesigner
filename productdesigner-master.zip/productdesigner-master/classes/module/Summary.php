<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use classes\models\design\Design;
use classes\models\DesignerConfig;
use Context;
use ProductDesigner;
use Tools;

class Summary
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    private static $cart_controllers = array('cart');

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param Design $design
     * @return string
     */
    public function displayCartSummary($design)
    {
        $controller = Tools::getValue('controller');
        $is_email = Tools::getIsset('sendStateEmail') ||
            in_array($controller, array('validation', 'orderconfirmation'));
        $this->context->smarty->assign(array(
            'design'             => $design,
            'display_preview'    => $design->shouldDisplayPreview($is_email),
            'is_cart_controller' => in_array($controller, self::$cart_controllers, true),
            'edit_link'          => $this->module->provider->getProductLink(
                $design->id_product,
                $design->id_product_attribute,
                array(
                    'edit_design' => $design->id
                )
            )
        ));

        return $this->module->display(
            $this->module->getDir(),
            'views/templates/hook/front/summary/cart-summary.tpl'
        );
    }

    /**
     * @param Design $design
     * @return string
     */
    public function displayPdfSummary($design)
    {
        $this->context->smarty->assign(array(
            'dsn_config' => DesignerConfig::getConfig(),
            'design'     => $design,
            'summary' => $design->getSummary(),
        ));

        return $this->module->display(
            $this->module->getDir(),
            'views/templates/hook/front/summary/pdf-summary.tpl'
        );
    }

    /**
     * @param Design $design
     * @return string
     */
    public function displayAdminSummary($design)
    {
        $this->context->smarty->assign(array(
            'design'  => $design,
            'summary' => $design->getSummary(),
        ));

        return $this->module->display(
            $this->module->getDir(),
            'views/templates/hook/admin/summary/admin-summary.tpl'
        );
    }

    /**
     * @param Design $design
     * @return string
     */
    public function displayAdminSvgPreviews($design)
    {
        $this->context->smarty->assign(array(
            'design'    => $design,
            'svg_codes' => $design->getSvgCodes()
        ));

        return $this->module->display(
            $this->module->getDir(),
            'views/templates/hook/admin/summary/admin-preview.tpl'
        );
    }
}
