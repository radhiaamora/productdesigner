<?php
/**
* 2010-2020 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\module;

use Address;
use classes\models\design\Design;
use Configuration;
use Context;
use Product;
use ProductDesigner;
use SpecificPrice;

class Calculator
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getProductTaxRate($id_product)
    {
        $address = null;
        $context = $this->context;
        if (is_object($context->cart) && $context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')} != null) {
            $address = $context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')};
        }

        $product = $this->module->provider->getProduct($id_product);
        return $product->getTaxesRate(new Address($address));
    }

    public function applyTax($price, $id_product)
    {
        $tax_rate = $this->getProductTaxRate($id_product);
        return $price + ($price * $tax_rate / 100);
    }

    public function getReduction($id_product, $id_product_attribute = null, $quantity = 1, $id_cart = null)
    {
        if ($id_cart === null) {
            $id_cart = $this->module->provider->getCart();
        }
        if ($id_product_attribute === null) {
            $id_product_attribute = (int)Product::getDefaultAttribute($id_product);
        }
        return SpecificPrice::getSpecificPrice(
            (int)$id_product,
            (int)$this->context->shop->id,
            (int)$this->module->provider->getCurrency(),
            (int)$this->module->provider->getCountry(),
            (int)$this->context->customer->id_default_group,
            (int)$quantity,
            (int)$id_product_attribute,
            (int)$this->module->provider->getCustomer(),
            (int)$id_cart
        );
    }

    public function applyReduction($price, $specific_price)
    {
        if (!$specific_price) {
            return $price;
        }
        $type = $specific_price['reduction_type'];
        $reduction = (float)$specific_price['reduction'];
        if ($type === 'percentage') {
            $price -= $price * $reduction;
        }
        return $price;
    }

    /**
     * @param Design $design
     */
    public function getDesignReducedPrice($design, $id_cart = null)
    {
        $price = $design->getPrice();
        $reduction = $this->getReduction(
            $design->id_product,
            $design->id_product_attribute,
            $design->quantity,
            $id_cart
        );
        return $this->applyReduction($price, $reduction);
    }

    public function getDisplayPriceAmount($price, $id_product)
    {
        $price_with_tax = $this->applyTax($price, $id_product);
        return $this->applyReduction($price_with_tax, $this->getReduction($id_product));
    }
}
