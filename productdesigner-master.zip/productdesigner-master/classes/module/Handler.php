<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use Cart;
use classes\DesignerTools;
use classes\models\DesignerObject;
use Configuration;
use Context;
use Db;
use Language;
use ObjectModel;
use ProductDesigner;
use Tab;
use Tools;
use Validate;

class Handler
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    private $hooks_front = array(
        'displayHeader',
        'actionAuthentication',
        'actionCartSave',
        'displayProductAdditionalInfo',
        'displayFooterProduct',
        'displayCustomization',
        'ProductDesigner'
    );
    private $hooks_admin = array(
        'actionAdminControllerSetMedia',
        'displayBackOfficeHeader',
        'displayAdminProductsExtra',
        'actionObjectProductAddAfter',
        'actionObjectImageAddAfter'
    );

    private $controllers = array(
        array(
            'name'  => 'DSN Product Extra',
            'class' => 'DsnProductExtra'
        ),
        array(
            'name'  => 'DSN Product Images',
            'class' => 'DsnProductImages'
        ),
        array(
            'name'  => 'DSN Design Tabs',
            'class' => 'DsnDesignTabs'
        ),
        array(
            'name'  => 'DSN Product Config',
            'class' => 'DsnProductConfig'
        ),
        array(
            'name'  => 'DSN Product Pricing',
            'class' => 'DsnProductPricing'
        ),
        array(
            'name'  => 'DSN Config',
            'class' => 'DsnConfig'
        ),
        array(
            'name'  => 'DSN Color Theme',
            'class' => 'DsnColorTheme'
        ),
        array(
            'name'  => 'DSN Font',
            'class' => 'DsnFont'
        ),
        array(
            'name'  => 'DSN ImageGroup',
            'class' => 'DsnImageGroup'
        ),
        array(
            'name'  => 'DSN Product Areas',
            'class' => 'DsnProductAreas'
        ),
        array(
            'name'  => 'DSN Product Fields',
            'class' => 'DsnProductFields'
        ),
        array(
            'name'  => 'DSN Real Size',
            'class' => 'DsnRealSize'
        ),
        array(
            'name'  => 'SVG Preview',
            'class' => 'DsnSvg'
        ),
        array(
            'name'  => 'Text Area Intervals',
            'class' => 'DsnTextAreaIntervals'
        ),
        array(
            'name'  => 'Image Area Intervals',
            'class' => 'DsnImageAreaIntervals'
        ),
        array(
            'name'  => 'Side Pricing',
            'class' => 'DsnSidePricing'
        ),
        array(
            'name'  => 'Side Combinations',
            'class' => 'DsnSideCombinations'
        ),
        array(
            'name'  => 'Bulk Copy',
            'class' => 'DsnBulkCopy'
        ),
        array(
            'name'  => 'Product Layers',
            'class' => 'DsnLayers'
        ),
        array(
            'name'   => 'Product Designer',
            'class'  => 'DsnRedirect',
            'parent' => 'AdminParentModulesSf'
        ),
        array(
            'name'  => 'Product Dev',
            'class' => 'DsnProductDev'
        ),
    );

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function getHooks()
    {
        return array_merge($this->hooks_front, $this->hooks_admin);
    }

    public function getFrontHooks()
    {
        return $this->hooks_front;
    }

    public function installHooks()
    {
        foreach ($this->getHooks() as $hook) {
            $this->module->registerHook($hook);
        }
        return true;
    }

    public function installDataDirs()
    {
        $result = true;

        $folders = array(
            '',
            'font',
            'cache',
            'product_images',
            'product_images/canvas',
            'product_images/mask',
            'json',
            'color',
            'image',
            'image_group',
            'user_upload',
            'layer',
            'design_preview',
            'output',
            'svg'
        );

        foreach ($folders as $folder) {
            $result &= $this->installDataDir($folder);
        }

        $files = array(
            // translation
            'json/customization_field.json'          => 'json/customization_field.json',
            // fonts
            'views/fonts/milkshake.ttf'              => 'font/milkshake.ttf',
            'views/fonts/mountain.ttf'               => 'font/mountain.ttf',
            'views/fonts/days.ttf'                   => 'font/days.ttf',
            // image group
            'views/img/preset/animals.png'           => 'image_group/animals.png',
            'views/img/preset/animals.png.thumb.png' => 'image_group/animals.png.thumb.png',
            // images
            'views/img/preset/dogs.svg'              => 'image/dogs.svg',
            'views/img/preset/cats.svg'              => 'image/cats.svg',
            'views/img/preset/birds.svg'             => 'image/birds.svg',
            'views/img/preset/reindeer.svg'          => 'image/reindeer.svg'
        );

        foreach ($files as $src => $dest) {
            $file_path = $this->module->getDir() . $src;
            if (is_file($file_path)) {
                $destination = $this->module->provider->getDataFile($dest);
                if (!is_file($destination)) {
                    copy($file_path, $destination);
                }
            }
        }

        return $result;
    }

    public function installDataDir($folder)
    {
        $index_file = $this->module->getDir() . 'index.php';
        $dir = $this->module->provider->getDataDir($folder);
        if (!is_dir($dir)) {
            $result = mkdir($dir);
            copy($index_file, $dir . 'index.php');
            return $result;
        }
        return true;
    }

    public function execSQLScripts($context = 'install')
    {
        if ($context === 'uninstall') {
            return $this->execUninstallScript();
        }
        $success = true;
        $files = glob($this->module->getDir() . 'sql/' . $context . '-*.sql');
        foreach ($files as $file) {
            $name = pathinfo($file, PATHINFO_FILENAME);
            $success &= $this->execSQL($name);
        }
        $success &= $this->execSQL($context);
        return $success;
    }

    public function execSQL($context = 'install')
    {
        $sql_path = $this->module->getDir() . 'sql/' . $context . '.sql';
        if (!is_file($sql_path)) {
            return false;
        }

        if (!$sql = Tools::file_get_contents($sql_path)) {
            return true;
        }
        return $this->execSQLCode($sql);
    }

    public function execSQLCode($sql)
    {
        $success = true;
        $sql = str_replace('__PREFIX', pSQL(_DB_PREFIX_ . $this->module->name), $sql);
        $sql = str_replace('_MYSQL_ENGINE_', pSQL(_MYSQL_ENGINE_), $sql);
        $sql = preg_split('/;\s*[\r\n]+/', $sql);
        foreach ($sql as $query) {
            $query = trim($query);
            if (Tools::strlen($query)) {
                if (preg_match('/^# install/', $query)) {
                    $file = preg_replace('/^# /', '', $query);
                    $file = preg_replace('/;$/', '', $file);
                    $success &= $this->execSQL($file);
                } else {
                    $success &= Db::getInstance()->execute(trim($query));
                }
            }
        }
        return $success;
    }

    public function execUpgradeSql($version)
    {
        return $this->execSQL('upgrade/' . $version);
    }

    public function installControllers()
    {
        $success = true;
        foreach ($this->controllers as $controller) {
            $success &= $this->installController($controller);
        }
        return (bool)$success;
    }

    public function installController($controller)
    {
        $translator = new Translator($this->module, $this->context);
        $languages = Language::getLanguages();
        $tab = new Tab();
        foreach ($languages as $lang) {
            $tab->name[$lang['id_lang']] = $translator->getTranslation(
                $controller['name'],
                $lang['iso_code']
            );
        }
        $tab->class_name = $controller['class'];
        if (isset($controller['parent'])) {
            $tab->id_parent = $this->module->provider->getTabID($controller['parent']);
        } else {
            $tab->id_parent = 0;
        }
        $tab->module = $this->module->name;
        $tab->active = 1;
        return $tab->add();
    }

    public function uninstallHooks()
    {
        foreach ($this->getHooks() as $hook) {
            $this->module->unregisterHook($hook);
        }
        return true;
    }

    public function uninstallControllers()
    {
        $success = true;
        foreach ($this->controllers as $controller) {
            $success &= $this->uninstallController($controller);
        }
        return $success;
    }

    public function uninstallController($controller)
    {
        $tab = new Tab((int)Tab::getIdFromClassName($controller['class']));
        return $tab->delete();
    }

    public function execUninstallScript()
    {
        $success = true;
        $uninstall_script = $this->module->getDir() . 'sql/tables.json';
        $contents = Tools::file_get_contents($uninstall_script);
        $tables = json_decode($contents, true);
        if (is_array($tables)) {
            foreach ($tables as $table) {
                $table = $this->restoreTableName($table);
                $sql = 'DROP TABLE IF EXISTS `__PREFIX_' . pSQL($table) . '`;';
                $sql = str_replace('__PREFIX', pSQL(_DB_PREFIX_ . $this->module->name), $sql);
                $success &= Db::getInstance()->execute($sql);
            }
        }
        return $success;
    }

    public function installDataPresets()
    {
        $success = true;
        // install initial data from JSON files
        $presets = glob($this->module->getDir() . 'sql/presets/*.json');
        foreach ($presets as $preset) {
            $name = pathinfo($preset, PATHINFO_FILENAME);
            // add the module name to the filename to get the table name
            $table = $this->module->name . '_' . $name;
            $fields = DesignerObject::getModelFields($name);
            $entries = $this->getEntries($preset);
            foreach ($entries as $entry) {
                $success &= $this->insertPreset($name, $table, $entry, $fields);
            }
        }
        return $success;
    }

    private function insertPreset($name, $table, $entry, $fields)
    {
        $clean_table = bqSQL(pSQL($table));
        $clean_name = bqSQL(pSQL($name));
        $id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        $id_primary = "id_{$clean_name}";
        // fill non existing fields to be used for sanitizing
        $fields[$id_primary] = array('type' => ObjectModel::TYPE_INT);
        $fields['id_lang'] = array('type' => ObjectModel::TYPE_INT);

        $data = array();
        foreach ($entry as $key => $value) {
            if ($key === 'lang') {
                $value[$id_primary] = (int)$entry[$id_primary];
                $value['id_lang'] = $id_default_lang;
                $this->insertPreset($name, $clean_table . '_lang', $value, $fields);
                // fill other languages
                $languages = Language::getLanguages();
                foreach ($languages as $lang) {
                    // we want translations to be empty for the rest of the langs
                    $id_lang = (int)$lang['id_lang'];
                    if ($id_lang !== $id_default_lang) {
                        $value['id_lang'] = $id_lang;
                        $this->insertPreset($name, $clean_table . '_lang', $value, $fields);
                    }
                }
            } elseif (isset($fields[$key])) {
                $field = $fields[$key];
                // sanitize and assign data for insertion
                $clean_key = bqSQL(pSQL($key));
                $data[$clean_key] = ObjectModel::formatValue($value, $field['type']);
            }
        }
        // $data is sanitized using ObjectModel::formatValue
        return Db::getInstance()->insert(pSQL($clean_table), $data, false, true, Db::INSERT_IGNORE);
    }

    private function restoreTableName($table)
    {
        if (!DesignerTools::isModuleDevMode() && Tools::substr($table, 0, 1) === '_') {
            $table = Tools::substr($table, 1);
        }
        return $table;
    }

    /**
     * @return Cart
     */
    public function getOrCreateCart()
    {
        $cart = $this->context->cart;
        if (Validate::isLoadedObject($cart)) {
            return $cart;
        }
        $cart->save();
        $this->context->cookie->id_cart = $cart->id;
        $this->context->cart = $cart;
        return $cart;
    }

    private function getEntries($preset)
    {
        $json = Tools::file_get_contents($preset);
        return json_decode($json, true);
    }
}
