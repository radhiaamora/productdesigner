<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\module;

use classes\color_manager\ColorManager;
use classes\designer\Designer;
use classes\DesignerTools;
use classes\scss\ScssCompiler;
use Context;
use lib\trans\TranslationHelper;
use Media as PrestaShopMedia;
use ProductDesigner;

class Media
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    private $module_path;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
        $this->module_path = $this->module->getPathUri();
    }

    public function addProductFooterMedia($id_product)
    {
        $designer = new Designer($this->module, $this->context, $id_product);
        $designer->addVariables();

        $this->context->controller->addJqueryUI(array(
            'draggable',
            'resizable',
            'spinner',
            'slider'
        ));

        $scss_compiler = new ScssCompiler($this->module, $this->context);

        $this->context->controller->addCSS(array(
            $this->module_path . 'views/css/front/vendor.css',
            $this->module_path . 'views/css/front/common.css',
            $this->module_path . 'views/css/front/dsn-product-footer.css',
            $scss_compiler->compileColorTheme()
        ));
        if (DesignerTools::isModuleDevMode() && !DesignerTools::isAddAssetsEnabled()) {
            $this->context->controller->registerJavascript(
                'dsn-css-assets',
                'modules/' . $this->module->name . '/views/js/front/dsn-css-assets.js',
                array(
                    'position' => 'bottom',
                    'priority' => 150
                )
            );
        }
        $this->context->controller->registerJavascript(
            'vendor',
            'modules/' . $this->module->name . '/views/js/front/vendor.js',
            array(
                'position' => 'bottom',
                'priority' => 150
            )
        );
        $this->context->controller->registerJavascript(
            'common',
            'modules/' . $this->module->name . '/views/js/front/common.js',
            array(
                'position' => 'bottom',
                'priority' => 150
            )
        );
        $this->context->controller->registerJavascript(
            'dsn-product-footer',
            'modules/' . $this->module->name . '/views/js/front/dsn-product-footer.js',
            array(
                'position' => 'bottom',
                'priority' => 150
            )
        );
    }

    public function addColorManagerMedia()
    {
        $colorManager = new ColorManager($this->module, $this->context);
        if ($colorManager->isEnabled()) {
            $colorManager->addVariables();
            $this->context->controller->addCSS(array(
                $this->module_path . 'views/css/front/dsn-color.css',
            ));
            $this->context->controller->registerJavascript(
                'dsn-acolorpicker',
                'modules/' . $this->module->name . '/views/js/plugins/a-color-picker/acolorpicker.js',
                array(
                    'position' => 'bottom',
                    'priority' => 150
                )
            );
            $this->context->controller->registerJavascript(
                'sass',
                'https://cdnjs.cloudflare.com/ajax/libs/sass.js/0.10.7/sass.sync.min.js',
                array(
                    'position' => 'bottom',
                    'priority' => 150,
                    'server' => 'remote',
                )
            );
            $this->context->controller->registerJavascript(
                'dsn-color',
                'modules/' . $this->module->name . '/views/js/front/dsn-color.js',
                array(
                    'position' => 'bottom',
                    'priority' => 150
                )
            );
        }
    }

    public function addProductsExtraMedia($id_product)
    {
        $source = DesignerTools::getSource();
        $translation_helper = new TranslationHelper($this->module, $this->context);
        PrestaShopMedia::addJsDef(array(
            'dsn_id_product'   => $id_product,
            'dsn_public_path'  => $this->module->provider->getModuleDirUri('views/js'),
            'dsn_uri'          => $this->module->provider->getModuleDirUri(),
            'dsn_data_uri'     => $this->module->provider->getDataDirUri(),
            'dsn_module_dev'   => DesignerTools::isModuleDevMode(),
            'dsn_controllers'  => array(
                'text_area_intervals'  => $this->module->provider->getControllerAdminLink('DsnTextAreaIntervals'),
                'image_area_intervals' => $this->module->provider->getControllerAdminLink('DsnImageAreaIntervals'),
                'side_pricing'         => $this->module->provider->getControllerAdminLink('DsnSidePricing'),
                'side_combinations'    => $this->module->provider->getControllerAdminLink('DsnSideCombinations'),
                'bulk_copy'            => $this->module->provider->getControllerAdminLink('DsnBulkCopy'),
                'layers'               => $this->module->provider->getControllerAdminLink('DsnLayers'),
            ),
            'dsn_message'      => array(
                'confirm' => $this->module->l(
                    'Are you sure to delete this item?',
                    $source
                ),
                'success' => $this->module->l(
                    'Data saved successfully',
                    $source
                ),
            ),
            'dsn_translations' => $translation_helper->getTranslations()
        ));

        $this->context->controller->addJqueryUI(array(
            'ui.draggable',
            'ui.resizable',
            'ui.sortable'
        ));

        $this->context->controller->addCSS(array(
            $this->module_path . 'views/css/admin/vendor.css',
            $this->module_path . 'views/css/admin/dsn-products-extra.css',
            $this->module_path . 'lib/app/css/global.css',
        ));
        $this->context->controller->addJS($this->addHash(array(
            $this->module_path . 'views/js/plugins/material/material.js',
            $this->module_path . 'views/js/plugins/material/getmdl-select.js',
            $this->module_path . 'views/js/admin/vendor.js',
            $this->module_path . 'views/js/admin/common.js',
            $this->module_path . 'views/js/admin/dsn-products-extra.js',
        )));
    }

    public function addProductsListMedia()
    {
        $this->context->controller->addCSS(array(
            $this->module_path . 'views/css/admin/dsn-products-list.css'
        ));
        $this->context->controller->addJS($this->addHash(array(
            $this->module_path . 'views/js/admin/dsn-products-list.js'
        )));
    }

    public function addConfigurationMedia()
    {
        PrestaShopMedia::addJsDef(array(
            'dsn_public_path' => $this->module->provider->getModuleDirUri('views/js'),
            'dsn_font'        => $this->module->provider->getControllerAdminLink('DsnFont'),
            'dsn_image_group' => $this->module->provider->getControllerAdminLink('DsnImageGroup')
        ));
        $this->context->controller->addCSS($this->module_path . 'views/css/admin/dsn-configuration.css');
        $this->context->controller->addJS($this->addHash(array(
            $this->module_path . 'views/js/plugins/material/material.js',
            $this->module_path . 'views/js/admin/vendor.js',
            $this->module_path . 'views/js/admin/common.js',
            $this->module_path . 'views/js/admin/dsn-configuration.js'
        )));
    }

    public function addOrdersMedia()
    {
        PrestaShopMedia::addJsDef(array(
            'dsn_public_path' => $this->module->provider->getModuleDirUri('views/js'),
            'dsn_uri'         => $this->module->provider->getModuleDirUri(),
        ));
        $this->context->controller->addCSS($this->module_path . 'views/css/admin/dsn-orders.css');
        $this->context->controller->addJS($this->addHash(array(
            $this->module_path . 'views/js/admin/vendor.js',
            $this->module_path . 'views/js/admin/common.js',
            $this->module_path . 'views/js/admin/dsn-orders.js'
        )));
    }

    public function addSummaryMedia()
    {
        $this->context->controller->addCSS(array(
            $this->module_path . 'views/css/front/dsn-cart.css'
        ));
        $this->context->controller->registerJavascript(
            'vendor',
            'modules/' . $this->module->name . '/views/js/front/vendor.js',
            array(
                'position' => 'bottom',
                'priority' => 150
            )
        );
        $this->context->controller->registerJavascript(
            'common',
            'modules/' . $this->module->name . '/views/js/front/common.js',
            array(
                'position' => 'bottom',
                'priority' => 150
            )
        );
        $this->context->controller->registerJavascript(
            'dsn-cart',
            'modules/' . $this->module->name . '/views/js/front/dsn-cart.js',
            array(
                'position' => 'bottom',
                'priority' => 150
            )
        );
    }

    public function addFirebug()
    {
        $this->context->controller->registerJavascript(
            'firebug-lite',
            'https://getfirebug.com/firebug-lite.js',
            array(
                'position' => 'top',
                'priority' => 0,
                'server'   => 'remote'
            )
        );
    }

    public function addFirebugAdmin()
    {
        $this->context->controller->addJS('https://getfirebug.com/firebug-lite.js');
    }

    private function addHash($files)
    {
        $hash = $this->module->version;

        if (is_array($files)) {
            foreach ($files as &$file) {
                $file .= '?' . $hash;
            }
            return $files;
        }

        if (is_string($files)) {
            return $files . '?' . $hash;
        }

        return $files;
    }
}
