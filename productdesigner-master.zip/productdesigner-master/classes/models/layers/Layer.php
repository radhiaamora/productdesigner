<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\layers;

use classes\models\DesignerObject;
use classes\models\DesignerProductSide;
use Db;
use DbQuery;
use Product;
use Tools;

class Layer extends DesignerObject
{

    public $id_product;
    public $id_layer_group;
    public $price;
    public $active = true;
    public $selected = false;
    public $position;

    public $label;

    /** @var LayerImage[] */
    public $layer_images;

    public $display_price;

    public static $definition = array(
        'table'     => 'productdesigner_layer',
        'primary'   => 'id_layer',
        'multilang' => true,
        'fields'    => array(
            'id_product'     => array('type' => self::TYPE_INT),
            'id_layer_group' => array('type' => self::TYPE_INT),
            'price'          => array('type' => self::TYPE_FLOAT),
            'active'         => array('type' => self::TYPE_BOOL),
            'selected'       => array('type' => self::TYPE_BOOL),
            'position'       => array('type' => self::TYPE_INT),
            /* Lang fields */
            'label'          => array(
                'type'     => self::TYPE_STRING,
                'lang'     => true,
                'required' => true,
                'validate' => 'isGenericName',
                'size'     => 64
            )
        )
    );

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
        $this->assignLayerImages();
        $this->assignConvertedPrice();
    }

    /**
     * @param $id_layer_group
     * @param $id_lang
     * @return Layer[]
     */
    public static function getByLayerGroup($id_layer_group, $id_lang = null)
    {
        $layers = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_layer_group = ' . (int)$id_layer_group);
        $sql->orderBy('position ASC');
        $db = Db::getInstance();
        $result = $db->executeS($sql, false);
        while ($row = $db->nextRow($result)) {
            $id_layer = (int)$row['id_layer'];
            $layers[$id_layer] = new self($id_layer, $id_lang);
        }
        return $layers;
    }

    /**
     * @param $id_side
     * @return LayerImage
     */
    public function getLayerImage($id_side)
    {
        return $this->layer_images[$id_side];
    }

    /**
     * @param $id_layer_group
     * @return self
     */
    public function copyToGroup($id_layer_group)
    {
        $id_layer = $this->id;
        $this->id_layer_group = $id_layer_group;
        $this->position = 1 + $this->getHighestPosition(array(
                'key'   => 'id_layer_group',
                'value' => $id_layer_group
            ));
        $this->add();

        $new_id_layer = $this->id;

        $layer_images = LayerImage::getByLayer($id_layer);
        foreach ($layer_images as $layer_image) {
            $layer_image->copyToLayer($new_id_layer);
        }
        return $this;
    }

    private function assignLayerImages()
    {
        $designer_sides = DesignerProductSide::getProductSidesWithDefault($this->id_product);
        foreach ($designer_sides as $designer_side) {
            $id_side = $designer_side->id;
            $this->layer_images[$id_side] = LayerImage::getByLayerAndSide($this->id, $id_side);
        }
    }

    private function assignConvertedPrice()
    {
        $price = $this->price;
        if (Tools::getValue('controller') === 'layers') {
            $price = $this->module->calculator->applyTax(
                $this->price,
                Tools::getValue('id_product')
            );
        }
        $this->display_price = Product::convertAndFormatPrice($price);
    }

    public function delete()
    {
        $layer_images = LayerImage::getByLayer($this->id);
        foreach ($layer_images as $layer_image) {
            $layer_image->delete();
        }
        parent::delete();
    }

    public static function unselectLayersByGroup($id_layer_group)
    {
        Db::getInstance()->update(
            self::$definition['table'],
            array('selected' => 0),
            'id_layer_group = ' . (int)$id_layer_group
        );
    }
}
