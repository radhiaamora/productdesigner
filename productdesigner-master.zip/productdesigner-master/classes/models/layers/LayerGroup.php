<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\layers;

use classes\DesignerTools;
use classes\models\DesignerObject;
use Db;
use DbQuery;

class LayerGroup extends DesignerObject
{

    public $id_product;
    public $active = true;
    public $required = false;
    public $is_design_layer = false;
    public $position;

    public $label;

    public $layers;

    public static $definition = array(
        'table'     => 'productdesigner_layer_group',
        'primary'   => 'id_layer_group',
        'multilang' => true,
        'fields'    => array(
            'id_product'      => array('type' => self::TYPE_INT),
            'active'          => array('type' => self::TYPE_BOOL),
            'required'        => array('type' => self::TYPE_BOOL),
            'is_design_layer' => array('type' => self::TYPE_BOOL),
            'position'        => array('type' => self::TYPE_INT),
            /* Lang fields */
            'label'           => array(
                'type'     => self::TYPE_STRING,
                'lang'     => true,
                'required' => true,
                'validate' => 'isGenericName',
                'size'     => 64
            )
        )
    );

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
        $this->assignLayers($id_lang);
    }

    /**
     * @param $id_product
     * @param $id_lang
     * @return LayerGroup[]
     */
    public static function getByProduct($id_product, $id_lang = null)
    {
        $layer_groups = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_product = ' . (int)$id_product);
        $sql->orderBy('position ASC');
        $db = Db::getInstance();
        $result = $db->executeS($sql, false);
        while ($row = $db->nextRow($result)) {
            $id_layer_group = (int)$row['id_layer_group'];
            $layer_groups[$id_layer_group] = new self($id_layer_group, $id_lang);
        }
        return $layer_groups;
    }

    public static function getProductDesignLayer($id_product)
    {
        $module_name = DesignerTools::getModuleName();
        $sql = new DbQuery();
        $sql->select('id_layer_group');
        $sql->from($module_name . '_layer_group');
        $sql->where('id_product = ' . (int)$id_product);
        $sql->where('is_design_layer = 1');
        return (int)Db::getInstance()->getValue($sql);
    }

    private function assignLayers($id_lang)
    {
        $this->layers = Layer::getByLayerGroup($this->id, $id_lang);
    }

    public function isAboveDesign()
    {
        $sql = new DbQuery();
        $sql->select('id_layer_group');
        $sql->from($this->module->name . '_layer_group');
        $sql->where('id_product = ' . (int)$this->id_product);
        $sql->where('is_design_layer = 1');
        $sql->where('position < ' . (int)$this->position);
        $id_layer_group = (int)Db::getInstance()->getValue($sql);
        return $id_layer_group !== 0;
    }

    public function delete()
    {
        $layers = Layer::getByLayerGroup($this->id);
        foreach ($layers as $layer) {
            $layer->delete();
        }
        parent::delete();
    }

    /**
     * @param $id_product
     * @return self
     */
    public function copyToProduct($id_product)
    {
        $id_layer_group = $this->id;
        $this->id_product = $id_product;
        $this->position = 1 + $this->getHighestPosition(array(
                'key'   => 'id_product',
                'value' => $this->id_product
            ));
        $this->add();

        $new_id_layer_group = $this->id;

        $layers = Layer::getByLayerGroup($id_layer_group);
        foreach ($layers as $layer) {
            $layer->copyToGroup($new_id_layer_group);
        }
        return $this;
    }
}
