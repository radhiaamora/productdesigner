<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\layers;

use classes\helpers\SvgImageHelper;
use classes\models\DesignerObject;
use classes\svg\SvgHelper;
use Db;
use DbQuery;

class LayerImage extends DesignerObject
{

    public $id_layer;
    public $id_side;
    public $image;
    public $icon;
    public $color;

    protected $dir = 'layer';

    public $image_uri;
    public $image_thumb_uri;

    public $icon_uri;
    public $icon_thumb_uri;

    public static $definition = array(
        'table'     => 'productdesigner_layer_image',
        'primary'   => 'id_layer_image',
        'multilang' => false,
        'fields'    => array(
            'id_layer' => array('type' => self::TYPE_INT),
            'id_side'  => array('type' => self::TYPE_INT),
            'image'    => array(
                'type'       => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'thumb'      => array('height' => 64),
                'required'   => false,
                'rename'     => true
            ),
            'icon'     => array(
                'type'       => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'thumb'      => array('height' => 64),
                'required'   => false,
                'rename'     => true
            ),
            'color'    => array('type' => self::TYPE_STRING)
        )
    );

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);

        if ($this->getPath('image')) {
            $this->image_uri = $this->getFileUri('image');
            $this->image_thumb_uri = $this->getThumbUri('image');
        }

        if ($this->getPath('icon')) {
            $this->icon_uri = $this->getFileUri('icon');
            $this->icon_thumb_uri = $this->getThumbUri('icon');
        }
    }

    /**
     * @param $id_layer
     * @param $id_lang
     * @return LayerImage[]
     */
    public static function getByLayer($id_layer)
    {
        $layer_images = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_layer = ' . (int)$id_layer);
        $db = Db::getInstance();
        $result = $db->executeS($sql, false);
        while ($row = $db->nextRow($result)) {
            $id_layer_image = (int)$row['id_layer_image'];
            $layer_image = new self($id_layer_image);
            $layer_images[$layer_image->id_side] = $layer_image;
        }
        return $layer_images;
    }

    /**
     * @param $id_layer
     * @param $id_side
     * @param $id_lang
     * @return LayerImage
     */
    public static function getByLayerAndSide($id_layer, $id_side)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_layer = ' . (int)$id_layer);
        $sql->where('id_side = ' . (int)$id_side);
        $id_layer_image = (int)Db::getInstance()->getValue($sql);
        $layer_image = new self($id_layer_image);
        $layer_image->id_layer = (int)$id_layer;
        $layer_image->id_side = (int)$id_side;
        return $layer_image;
    }

    /**
     * @param $new_id_layer
     * @return self
     */
    public function copyToLayer($new_id_layer)
    {
        $image_path = $this->getPath('image');
        $icon_path = $this->getPath('icon');
        $this->id_layer = $new_id_layer;
        $this->add();
        $new_id_layer_image = $this->id;
        if ($image_path) {
            $extension = pathinfo($image_path, PATHINFO_EXTENSION);
            $image_name = $new_id_layer_image . '-image-' . '.' . $extension;
            copy($image_path, dirname($image_path) . DIRECTORY_SEPARATOR . $image_name);
            $this->image = $image_name;
        }
        if ($icon_path) {
            $extension = pathinfo($icon_path, PATHINFO_EXTENSION);
            $icon_name = $new_id_layer_image . 'icon' . '.' . $extension;
            copy($icon_path, dirname($icon_path) . DIRECTORY_SEPARATOR . $icon_name);
            $this->icon = $icon_name;
        }
        $this->createNewThumbnails();
        $this->save();
        return $this;
    }

    /** @noinspection PhpUnused */
    public function getImageSize($name)
    {
        return SvgImageHelper::getSize($this->getPath($name));
    }

    /** @noinspection PhpUnused */
    public function getCleanSvgPath($name)
    {
        $path = $this->getPath($name);
        return SvgHelper::getCleanSvgPath($path);
    }
}
