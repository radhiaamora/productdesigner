<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\layers;

use classes\models\DesignerObject;
use Db;
use DbQuery;

class DesignLayer extends DesignerObject
{

    public $id_design;
    public $id_layer_group;
    public $id_layer;

    public static $definition = array(
        'table'     => 'productdesigner_design_layer',
        'primary'   => 'id_design_layer',
        'multilang' => false,
        'fields'    => array(
            'id_design'      => array('type' => self::TYPE_INT),
            'id_layer_group' => array('type' => self::TYPE_INT),
            'id_layer'       => array('type' => self::TYPE_INT),
            'position'       => array('type' => self::TYPE_INT),
        )
    );

    /**
     * @param $id_design
     * @return DesignLayer[]
     */
    public static function getByDesign($id_design)
    {
        $design_layers = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_design = ' . (int)$id_design);
        $sql->orderBy('position ASC');
        $db = Db::getInstance();
        $result = $db->executeS($sql, false);
        while ($row = $db->nextRow($result)) {
            $id_design_layer = (int)$row[self::$definition['primary']];
            $design_layers[$id_design_layer] = new self($id_design_layer);
        }
        return $design_layers;
    }

    /**
     * @return LayerGroup()
     */
    public function getLayerGroup()
    {
        return new LayerGroup($this->id_layer_group);
    }

    /** @noinspection PhpUnused */
    /**
     * @return Layer
     */
    public function getLayer()
    {
        return new Layer($this->id_layer);
    }

    public function isAboveDesign()
    {
        $layer_group = $this->getLayerGroup();
        return $layer_group->isAboveDesign();
    }
}
