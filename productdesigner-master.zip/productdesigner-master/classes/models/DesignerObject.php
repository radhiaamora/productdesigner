<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\converter\Converter;
use classes\DesignerTools;
use Context;
use Db;
use DbQuery;
use Eventviva\ImageResize;
use Exception;
use Language;
use Module;
use ObjectModel;
use ProductDesigner;
use Tools;
use Uploader;
use Validate;

/**
 * @property bool active
 */
class DesignerObject extends ObjectModel
{
    public static $module_name = 'productdesigner';
    /** @var ProductDesigner $module */
    protected $module;
    public $position;
    protected $dir;

    /** @var Context */
    protected $context;
    protected $max_upload = array();

    public function __construct($id = null, $id_lang = null)
    {
        $this->module = Module::getInstanceByName(self::$module_name);
        $this->context = DesignerTools::getContext();
        parent::__construct($id, $id_lang);
        $this->assignPrimaryKeyProperty();
        $this->castNumericValues();
    }

    private function assignPrimaryKeyProperty()
    {
        $definition = ObjectModel::getDefinition($this);
        $primary = $definition['primary'];
        $this->$primary = $this->id;
    }

    public static function getModule()
    {
        return Module::getInstanceByName(self::$module_name);
    }

    /**
     * @param $model
     * @return DesignerObject
     */
    public static function getModelClass($model)
    {
        $namespace = 'classes\models\\';
        $class_name = 'Designer' . Tools::toCamelCase($model, true);
        return $namespace . $class_name;
    }

    /**
     * @param $model
     * @return array
     */
    public static function getModelFields($model)
    {
        $model_class = self::getModelClass($model);
        $definition = ObjectModel::getDefinition($model_class);
        return $definition['fields'];
    }

    /**
     * @param DesignerObject $object
     * @return mixed
     */
    public static function getValues($object, $fill_lang_values = false)
    {
        if ($fill_lang_values) {
            $object = self::fillLangFields($object);
        }
        return json_decode(json_encode($object), true);
    }

    /**
     * @param DesignerObject $object
     * @return DesignerObject
     * // TODO: remove this
     */
    private static function fillLangFields($object)
    {
        $languages = Language::getLanguages();
        $lang_fields = self::getLangFields($object);
        foreach ($lang_fields as $lang_field) {
            $value_all_langs = $object->{$lang_field};
            foreach ($languages as $language) {
                $id_lang = $language['id_lang'];
                if (!isset($value_all_langs[$id_lang])) {
                    $value_all_langs[$id_lang] = '';
                }
            }
        }
        return $object;
    }

    protected static function getLangFields($object)
    {
        $lang_fields = array();
        $definition = ObjectModel::getDefinition($object);
        $fields = $definition['fields'];
        foreach ($fields as $field_name => $field) {
            if (self::isLangField($field)) {
                $lang_fields[] = $field_name;
            }
        }
        return $lang_fields;
    }

    protected static function isLangField($field)
    {
        return isset($field['lang']) && $field['lang'];
    }

    protected static function isNullableField($field)
    {
        return isset($field['allow_null']) && $field['allow_null'];
    }

    public function getFieldsValues()
    {
        $values = array();
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];
        foreach ($fields as $name => $field) {
            $values[$name] = self::formatValue($this->{$name}, $field['type']);
        }
        return $values;
    }

    private function isDirField($name)
    {
        $definition = ObjectModel::getDefinition($this);
        $field_definition = $definition['fields'][$name];
        return isset($field_definition['dir']) && $field_definition['dir'];
    }

    public function getDir($name = '')
    {
        return $this->module->provider->getDataDir() . $this->dir . '/' . $name . (empty($name) ? '' : '/');
    }

    public function getPathForCreation($name = 'file')
    {
        if (property_exists($this, $name)) {
            $dir = $this->getDir();
            if ($this->isDirField($name)) {
                $dir = $this->getDir($name);
            }
            return $dir . $this->$name;
        }
        return false;
    }

    public function getPath($name = 'file')
    {
        $path = $this->getPathForCreation($name);
        if (is_file($path)) {
            return $path;
        }
        return false;
    }

    public function deleteFile($name = 'file')
    {
        $path = $this->getPath($name);
        if ($path) {
            unlink($path);
        }
        $this->{$name} = null;
    }

    public function delete()
    {
        $file_fields = $this->getFileFields();
        foreach ($file_fields as $file_field) {
            $path = $this->getPath($file_field);
            if ($path) {
                unlink($path);
            }
        }
        parent::delete();
    }

    public function getUrl($encode = false, $name = 'file')
    {
        if (!$encode) {
            return $this->getFileUrl($name);
        }
        $path = $this->getPath($name);
        if ($path) {
            return DesignerTools::encodeFile($path);
        }
        return null;
    }

    public function getFileUri($name = 'file')
    {
        $folder = $this->dir;
        if ($this->isDirField($name)) {
            $folder .= '/' . $name;
        }
        return $this->module->provider->getDataDirUri($folder) . $this->{$name};
    }

    public function getFileUrl($name = 'file')
    {
        return $this->module->provider->getShopUrl() . $this->getFileUri($name);
    }

    public function getThumbUri($name = 'file')
    {
        $type = $this->getType($name);
        if ($this->shouldCreateThumbForType($type)) {
            return $this->getFileUri($name) . '.thumb.' . $type;
        }
        return $this->getFileUri($name);
    }

    /** @noinspection PhpUnused */
    public function getThumbUrl($name = 'file')
    {
        $type = $this->getType($name);
        if ($this->shouldCreateThumbForType($type)) {
            return $this->getFileUrl($name) . '.thumb.' . $type;
        }
        return $this->getFileUrl($name);
    }

    public function getType($name = 'file')
    {
        return Tools::strtolower(pathinfo($this->{$name}, PATHINFO_EXTENSION));
    }

    public function setMaxUpload($field, $maxsize)
    {
        $this->max_upload[$field] = $maxsize;
    }

    public function saveFromPost()
    {
        $errors = array();
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];

        $this->saveFieldsFromPost($fields, $errors);

        $this->saveLangFieldsFromPost($fields, $errors);

        $this->saveNewPosition($fields);

        $saved_files = $this->saveFieldFilesFromPost($fields, $errors);

        if (!count($errors)) {
            try {
                $this->save();
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
            }
            $this->renameSavedFiles($fields, $saved_files);
            try {
                $this->createThumbnails($fields, $saved_files);
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
            }
        }
        return $errors;
    }

    private function saveFieldsFromPost($fields, &$errors)
    {
        foreach ($fields as $field => $info) {
            $type = (int)$info['type'];
            if (!isset($info['extensions'])) {
                $is_bool = $type === self::TYPE_BOOL;
                $isset_field = Tools::getIsset($field);
                if ($isset_field) {
                    $post_value = Tools::getValue($field);
                    $validation = $this->validateField($field, $post_value, null, array(), true);
                    if ($validation !== true) {
                        $errors[] = $validation;
                    }
                    if ($is_bool && $post_value === 'on') {
                        $post_value = 1;
                    }
                    $value = $post_value;
                    if ($is_bool) {
                        $value = !$isset_field ? false : $post_value;
                    }
                    $this->$field = $value;
                } elseif ($is_bool) {
                    $this->$field = isset($info['fallback']) ? $info['fallback'] : false;
                }
            }
        }
    }

    private function saveLangFieldsFromPost($fields, &$errors)
    {
        $languages = Language::getLanguages(false);
        foreach ($fields as $field => $info) {
            if (self::isLangField($info)) {
                $translation = array();
                foreach ($languages as $language) {
                    $id_lang = (int)$language['id_lang'];
                    $post_value = Tools::getValue($field . '_' . $id_lang);
                    $message = $this->validateField($field, $post_value, $id_lang, array(), true);
                    if ($message !== true) {
                        $errors[] = $message;
                    }
                    $translation[$id_lang] = $post_value;
                }
                $this->$field = $translation;
            }
        }
    }

    private function saveFieldFilesFromPost($fields, &$errors)
    {
        $saved_files = array();

        if (is_array($_FILES)) {
            foreach ($_FILES as $name => $file) {
                if (!Validate::isLoadedObject($this)) {
                    $validation = $this->validateField($name, $file['name'], null, array(), true);
                    if ($validation !== true) {
                        $errors[] = $validation;
                        return $saved_files;
                    }
                }
                if (isset($fields[$name]) && !$file['error']) {
                    $field = $fields[$name];
                    if ($field['extensions']) {
                        $dir = $this->getDir();
                        if (isset($field['dir']) && $field['dir']) {
                            $dir = $this->getDir($name);
                        }
                        $path = $dir . $this->getFileName($file['name'], $name);
                        $uploader = new Uploader();
                        $uploader->setName($name);
                        $uploader->setAcceptTypes($field['extensions']);
                        if (isset($this->max_upload[$name])) {
                            $uploader->setMaxSize($this->max_upload[$name]);
                        }
                        $upload = $uploader->process();
                        if (isset($upload[0])) {
                            if (!$upload[0]['error']) {
                                if ($this->getPath($name)) {
                                    unlink($this->getPath($name));
                                }
                                $save_path = $upload[0]['save_path'];
                                $converter = new Converter($this->module, $this->context);
                                $converted_path = $converter->convertImage($save_path);
                                if ($converted_path) {
                                    $save_path = $converted_path;
                                    $path = $dir . basename($save_path);
                                } else {
                                    /** @noinspection NestedPositiveIfStatementsInspection */
                                    if (isset($field['usable_extensions'])) {
                                        $extension = pathinfo($save_path, PATHINFO_EXTENSION);
                                        if (!in_array($extension, $field['usable_extensions'], true)) {
                                            $errors[] = sprintf($this->module->l(
                                                'The file %s is not supported, please try another file (%s)',
                                                DesignerTools::getSource()
                                            ), basename($save_path), implode(',', $field['usable_extensions']));
                                            continue;
                                        }
                                    }
                                }
                                rename($save_path, $path);
                                $this->$name = basename($path);
                                $saved_files[] = $name;
                            } else {
                                $errors[] = $upload[0]['error'];
                            }
                        }
                    }
                }
            }
        }
        return $saved_files;
    }

    private function saveNewPosition($fields)
    {
        if (!is_numeric($this->position) && isset($fields['position'])) {
            $this->position = $this->getHighestPosition() + 1;
        }
    }

    private function renameSavedFiles($fields, $saved_files)
    {
        $modified = false;
        foreach ($saved_files as $field_name) {
            $field = $fields[$field_name];
            if (isset($field['rename']) && $field['rename']) {
                $path = $this->getPath($field_name);
                $extension = pathinfo($path, PATHINFO_EXTENSION);
                $new_filename = $this->id . '-' . $field_name . '.' . $extension;
                if (isset($field['randomize']) && $field['randomize']) {
                    /** @noinspection NonSecureUniqidUsageInspection */
                    $new_filename = uniqid('dsn_') . '.' . $extension;
                }
                $this->$field_name = $new_filename;
                $new_path = $this->getPathForCreation($field_name);
                rename($path, $new_path);
                $modified = true;
            }
        }
        if ($modified) {
            $this->save();
        }
    }

    private function createThumbnails($fields, $saved_files)
    {
        foreach ($saved_files as $field_name) {
            $field = $fields[$field_name];
            if (isset($field['thumb'])) {
                $path = $this->getPath($field_name);
                $type = $this->getType($field_name);
                if ($path && $this->shouldCreateThumbForType($type)) {
                    $thumb_path = $path . '.thumb.' . $type;
                    $image = new ImageResize($path);
                    if (isset($field['thumb']['height'])) {
                        $image->resizeToHeight((int)$field['thumb']['height']);
                    }
                    if (isset($field['thumb']['width'])) {
                        $image->resizeToWidth((int)$field['thumb']['width']);
                    }
                    $image->save($thumb_path, null, 100);
                }
            }
        }
    }

    public function createNewThumbnails()
    {
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];
        $this->createThumbnails($fields, array_keys($fields));
    }

    protected function shouldCreateThumbForType($type)
    {
        $no_thumb_types = array('svg');
        return !in_array($type, $no_thumb_types, true);
    }

    public function copyFromPost()
    {
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];
        foreach ($fields as $field => $info) {
            $type = $info['type'];
            if (Tools::getIsset($field)) {
                $field_value = Tools::getValue($field);
                if ((int)$type === self::TYPE_BOOL && $field_value === 'true') {
                    $field_value = true;
                }
                $value = $field_value;
                $this->$field = $value;
            }
        }
    }

    public function copyFromArray($values = false)
    {
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];
        foreach ($fields as $field => $info) {
            $type = $info['type'];
            if (isset($values[$field])) {
                $field_value = $values[$field];
                if ((int)$type === self::TYPE_BOOL && $field_value === 'true') {
                    $field_value = true;
                }
                $this->$field = $field_value;
            }
        }
    }

    public function getFileName($name, $field_name = null)
    {
        $extension = pathinfo($name, PATHINFO_EXTENSION);
        $primary_keys = $this->getPrimaryKeys();
        if ($primary_keys) {
            $filename_items = array();
            foreach ($primary_keys as $primary_key) {
                $filename_items[] = $this->$primary_key;
            }
            return implode('_', $filename_items) . ($field_name ? '_' . $field_name : '') . '.' . $extension;
        }

        return Tools::strtolower(Tools::replaceAccentedChars($name));
    }

    private function getPrimaryKeys()
    {
        $primary_keys = array();
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];
        foreach ($fields as $field_name => $field) {
            if (isset($field['primary']) && $field['primary']) {
                $primary_keys[] = $field_name;
            }
        }
        return count($primary_keys) ? $primary_keys : false;
    }

    private function getFileFields()
    {
        $file_fields = array();
        $definition = ObjectModel::getDefinition($this);
        $fields = $definition['fields'];
        foreach ($fields as $field_name => $field) {
            if (isset($field['extensions'])) {
                $file_fields[] = $field_name;
            }
        }
        return $file_fields;
    }

    public static function validateKey($name)
    {
        $class_definition = self::getClassDefinition();
        $fields = $class_definition['fields'];
        return isset($fields[$name]);
    }

    public function getHighestPosition($filter = null)
    {
        $definition = ObjectModel::getDefinition($this);
        /** @noinspection SqlResolve */
        $sql = '
        SELECT MAX(`position`)
        FROM `' . _DB_PREFIX_ . pSQL($definition['table']) . '`';

        if ($filter) {
            $sql .= ' WHERE `' . pSQL($filter['key']) . '` = "' . pSQL($filter['value']) . '"';
        }

        $position = Db::getInstance()->getValue($sql, false);
        return is_numeric($position) ? (int)$position : -1;
    }

    /**
     * @param DesignerObject[] $objects
     */
    public static function fixPositions($objects)
    {
        $position = 0;
        foreach ($objects as $object) {
            $object->position = $position++;
            $object->save();
        }
    }

    public static function getClassDefinition()
    {
        return static::$definition;
    }

    /**
     * @param $id_product
     * @return DbQuery
     */
    protected static function getProductQuery($id_product)
    {
        $definition = self::getClassDefinition();
        $fields = $definition['fields'];
        $sql = new DbQuery();
        $primary = $definition['primary'];
        $product_table = $definition['table'];
        $item_table = str_replace('_product', '', $product_table);
        $item_primary = str_replace('_product', '', $primary);
        $sql->from($product_table, 'p');
        $sql->where('p.`id_product` = ' . (int)$id_product);
        $sql->leftJoin($item_table, 't', 'p.' . pSQL($item_primary) . ' = t.' . pSQL($item_primary));
        if (isset($fields['position'])) {
            $sql->orderBy('t.position ASC');
        }
        return $sql;
    }

    public static function getList($id_lang = null, $filter = null)
    {
        $all_items = self::getAll($id_lang, $filter);
        return self::getValues($all_items);
    }

    public static function getOptionsList($id_lang)
    {
        $options = array();
        /** @var DesignerObject $objects */
        $objects = self::getAll($id_lang);
        foreach ($objects as $object) {
            $options[$object->id] = array(
                'id_option' => $object->id,
                'name'      => property_exists($object, 'name') ? $object->name : $object->label
            );
        }
        return $options;
    }

    public static function getSelectList($id_lang)
    {
        $options = array();
        /** @var DesignerObject $objects */
        $objects = self::getAll($id_lang);
        foreach ($objects as $object) {
            $options[] = array(
                'label' => property_exists($object, 'name') ? $object->name : $object->label,
                'value' => (int)$object->id
            );
        }
        return $options;
    }

    public static function getAll($id_lang = null, $filter = null)
    {
        $objects = array();
        $class_definition = self::getClassDefinition();
        $primary = $class_definition['primary'];
        $class = get_called_class();
        $sql = new DbQuery();
        $sql->select($primary);
        $sql->from($class_definition['table']);
        if (isset($class_definition['fields']['position'])) {
            $sql->orderBy('position ASC');
        }
        if (is_array($filter)) {
            $field = $filter['field'];
            $value = $filter['value'];
            // TODO: add support for string filters by adding quotes
            $sql->where(pSQL($field) . ' = ' . pSQL($value));
        }
        $rows = Db::getInstance()->executeS($sql);
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $id_object = $row[$primary];
                $objects[$id_object] = new $class($id_object, $id_lang);
            }
        }
        return $objects;
    }

    public static function getActive()
    {
        $context = DesignerTools::getContext();
        $id_lang = $context->language->id;
        return self::getAll($id_lang, array(
            'field' => 'active',
            'value' => 1
        ));
    }

    public static function deleteAllByProduct($id_product)
    {
        Db::getInstance()->delete(static::$definition['table'], 'id_product = ' . (int)$id_product);
    }

    private function castNumericValues()
    {
        $fields = static::$definition['fields'];
        foreach ($fields as $field => $info) {
            $type = $info['type'];
            if (in_array((int)$type, array(self::TYPE_INT, self::TYPE_FLOAT), true)) {
                $original_value = $this->$field;
                if ($original_value !== null) {
                    $value = self::formatValue($original_value, $type);
                    $this->$field = $value;
                }
            }
        }
    }

    private static function getForcedId($definition)
    {
        return isset($definition['forced_id']) ? (int)$definition['forced_id'] : 0;
    }

    public function save($null_values = false, $auto_date = true)
    {
        $definition = ObjectModel::getDefinition($this);
        $forced_id = self::getForcedId($definition);
        if ($forced_id) {
            $instance = new $this($forced_id);
            if (!Validate::isLoadedObject($instance)) {
                $this->id = $forced_id;
                $this->force_id = true;
                $this->add();
            }
        }
        return parent::save($null_values, $auto_date);
    }
}
