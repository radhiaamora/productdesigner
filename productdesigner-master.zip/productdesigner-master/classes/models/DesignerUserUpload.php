<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\DesignerTools;
use Db;
use DbQuery;

class DesignerUserUpload extends DesignerObject
{

    public $file;

    public $id_customer;

    public $id_guest;

    public $active = true;

    public $date_add;

    public $label = "Upload";

    protected $dir = 'user_upload';

    public static $definition = array(
        'table'     => 'productdesigner_user_upload',
        'primary'   => 'id_user_upload',
        'multilang' => false,
        'fields'    => array(
            'file'        => array(
                'type'              => self::TYPE_STRING,
                'extensions'        => array('png', 'jpg', 'jpeg', 'svg', 'heic', 'ai', 'eps', 'pdf'),
                'usable_extensions' => array('png', 'jpg', 'jpeg', 'svg'),
                'rename'            => true,
                'randomize'         => true,
                'thumb'             => array('height' => 60),
                'maxsize'           => 512000
            ),
            'id_customer' => array('type' => self::TYPE_INT),
            'id_guest'    => array('type' => self::TYPE_INT),
            'active'      => array('type' => self::TYPE_BOOL, 'fallback' => true),
            'date_add'    => array('type' => self::TYPE_DATE, 'validate' => 'isDate')
        )
    );

    /**
     * @param bool $id_customer
     * @param bool $id_guest
     * @return DesignerUserUpload[]
     */
    public static function getUserUploads($id_customer = 0, $id_guest = 0)
    {
        if (!$id_customer && !$id_guest) {
            $module = DesignerTools::getModule();
            $id_customer = $module->provider->getCustomer();
            $id_guest = $module->provider->getGuest();
        }
        $user_uploads = array();
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $conditions = array();
        if ($id_customer) {
            $conditions[] = 'id_customer = ' . (int)$id_customer;
        }
        if ($id_guest) {
            $conditions[] = 'id_guest = ' . (int)$id_guest;
        }
        if (!count($conditions)) {
            return $user_uploads;
        }
        $condition = implode(' OR ', $conditions);
        $sql->where(pSQL($condition));
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_user_upload = $result['id_user_upload'];
                $user_uploads[$id_user_upload] = new DesignerUserUpload((int)$id_user_upload);
            }
        }
        return $user_uploads;
    }

    public function validateCustomerPermission()
    {
        $id_customer = $this->module->provider->getCustomer();
        $id_guest = $this->module->provider->getGuest();
        if ((int)$id_customer) {
            return (int)$this->id_customer === (int)$id_customer;
        }
        if ((int)$id_guest) {
            return (int)$this->id_guest === (int)$id_guest;
        }
        return false;
    }

    public static function transferUploadsToCustomer($id_guest, $id_customer)
    {
        Db::getInstance()->update(
            self::$definition['table'],
            array(
                'id_customer' => (int)$id_customer
            ),
            'id_guest = ' . (int)$id_guest
        );
    }

    public function displayPrice($price, $id_product)
    {
        $locale = $this->context->getCurrentLocale();
        $display_price_amount = $this->module->calculator->getDisplayPriceAmount($price, $id_product);
        return $locale->formatPrice($display_price_amount, $this->context->currency->iso_code);
    }
}
