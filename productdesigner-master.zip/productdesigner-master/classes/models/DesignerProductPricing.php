<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use Db;
use DbQuery;

class DesignerProductPricing extends DesignerObject
{

    public $id_product;

    public $product_cost_per_area;

    public $text_cost_per_area;
    public $text_cost;
    public $text_character_cost;
    public $text_minimal_cost;
    public $texts_total_cost;

    public $use_image_cost;
    public $image_cost;
    public $image_cost_per_area;
    public $upload_cost;
    public $upload_cost_per_area;
    public $image_minimal_cost;
    public $images_total_cost;

    public $layers_extra_cost;

    public static $config_cache = array();
    public static $values_cache = array();

    public static $definition = array(
        'table'     => 'productdesigner_product_pricing',
        'primary'   => 'id_product_pricing',
        'multilang' => false,
        'fields'    => array(
            'id_product' => array('type' => self::TYPE_INT),

            'product_cost_per_area' => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),

            'text_cost_per_area'  => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'text_cost'           => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'text_character_cost' => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'text_minimal_cost'   => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'texts_total_cost'    => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),

            'use_image_cost'       => array('type' => self::TYPE_BOOL),
            'image_cost'           => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'image_cost_per_area'  => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'upload_cost'          => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'upload_cost_per_area' => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'image_minimal_cost'   => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),
            'images_total_cost'    => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true),

            'layers_extra_cost' => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'allow_null' => true)
        )
    );

    public function __construct($id_product_pricing = null, $id_lang = null)
    {
        parent::__construct($id_product_pricing, $id_lang);
        $this->formatValues();
    }

    /**
     * @param $id_product
     * @return DesignerProductPricing
     */
    public static function getByProductID($id_product)
    {
        if (isset(self::$config_cache[$id_product])) {
            return self::$config_cache[$id_product];
        }
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = ' . (int)$id_product);
        $id_product_pricing = (int)Db::getInstance()->getValue($sql);
        $product_pricing = new DesignerProductPricing($id_product_pricing);
        $product_pricing->id_product = (int)$id_product;
        return self::$config_cache[$id_product] = $product_pricing;
    }

    public static function getProductValues($id_product)
    {
        if (isset(self::$values_cache[$id_product])) {
            return self::$values_cache[$id_product];
        }
        $product_pricing = self::getByProductID($id_product);
        return self::$values_cache[$id_product] = json_decode(json_encode($product_pricing), true);
    }

    /**
     * @param $id_product
     * @return DesignerProductPricing
     */
    public static function addForProduct($id_product)
    {
        Db::getInstance()->insert(
            self::$definition['table'],
            array(
                'id_product' => (int)$id_product
            )
        );
        return new DesignerProductPricing(Db::getInstance()->Insert_ID());
    }

    public function saveValue($name, $value)
    {
        $field = self::$definition['fields'][$name];

        // we store NULL when the float field is emptied, this is to ignore the value in the pricing logic
        $nullify = self::isNullableField($field) && !is_numeric($value);

        Db::getInstance()->update(
            self::$definition['table'],
            array(
                // store either NULL or the formatted value
                pSQL($name) => $nullify ? null : (float)$value
            ),
            'id_product_pricing = ' . (int)$this->id,
            0,
            true // handle null_values
        );
    }

    private function formatValues()
    {
        $fields = self::$definition['fields'];
        foreach ($fields as $name => $field) {
            $value = $this->{$name};
            if (!empty($value) && $field['type'] === self::TYPE_FLOAT) {
                $formatted_value = self::formatValue($value, $field['type']);
                $this->{$name} = $formatted_value;
            }
        }
    }
}
