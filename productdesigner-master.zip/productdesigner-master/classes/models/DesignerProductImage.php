<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\DesignerTools;
use classes\helpers\ProductImageHelper;
use classes\helpers\SvgImageHelper;
use classes\svg\SvgHelper;
use Db;
use DbQuery;
use ProductDesigner;
use Tools;
use Validate;

class DesignerProductImage extends DesignerObject
{

    public $id_product;

    public $id_image;

    public $id_side;

    public $canvas;

    public $mask;

    public $canvas_width;
    public $canvas_height;

    public $date_upd;

    /** @var ProductDesigner */
    protected $module;

    protected $dir = 'product_images';

    public static $definition = array(
        'table' => 'productdesigner_product_image',
        'primary' => 'id_product_image',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT, 'primary' => true),
            'id_image' => array('type' => self::TYPE_INT, 'primary' => true),
            'id_side' => array('type' => self::TYPE_INT, 'primary' => true),
            'canvas' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'dir' => true,
                'thumb' => array('width' => 126),
                'rename' => false
            ),
            'mask' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'dir' => true,
                'thumb' => array('width' => 126),
                'rename' => false
            ),
            'canvas_width' => array('type' => self::TYPE_INT),
            'canvas_height' => array('type' => self::TYPE_INT),
            'date_upd' => array('type' => self::TYPE_DATE, 'validate' => 'isDate')
        )
    );

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerProductImage[]
     */
    public static function getProductImages($id_product, $id_lang = null)
    {
        $product_images = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = ' . (int)$id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_product_image = $result[self::$definition['primary']];
                $product_images[$id_product_image] = new self((int)$id_product_image, $id_lang);
            }
        }
        return $product_images;
    }

    /**
     * @param $id_product
     * @param $id_image
     * @param $id_side
     * @return DesignerProductImage[]
     */
    public static function getByImage($id_product, $id_image, $id_lang)
    {
        $product_images = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = ' . (int)$id_product);
        $sql->where('`id_image` = ' . (int)$id_image);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_product_image = $result[self::$definition['primary']];
                $product_images[$id_product_image] = new DesignerProductImage((int)$id_product_image, $id_lang);
            }
        }
        return $product_images;
    }

    /**
     * @param $id_product
     * @param $id_image
     * @param $id_side
     * @return DesignerProductImage
     */
    public static function getByImageAndSide($id_product, $id_image, $id_side)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = ' . (int)$id_product);
        $sql->where('`id_image` = ' . (int)$id_image);
        $sql->where('`id_side` = ' . (int)$id_side);
        $id_product_image = (int)Db::getInstance()->getValue($sql);
        $product_image = new DesignerProductImage($id_product_image);
        $product_image->id_product = (int)$id_product;
        $product_image->id_image = (int)$id_image;
        $product_image->id_side = (int)$id_side;
        return $product_image;
    }

    /**
     * @param $id_product
     * @param $id_product_attribute
     * @param $id_side
     * @return DesignerProductImage
     */
    public static function getByAttributeAndSide($id_product, $id_product_attribute, $id_side)
    {
        $id_image = ProductImageHelper::getAttributeImageID($id_product, $id_product_attribute);
        return DesignerProductImage::getByImageAndSide($id_product, $id_image, $id_side);
    }

    public static function getInstanceByData($data)
    {
        return self::getByImageAndSide($data['id_product'], $data['id_image'], $data['id_side']);
    }

    public static function createForSide($id_product, $id_image, $id_side)
    {
        $product_image = new DesignerProductImage();
        $product_image->id_product = $id_product;
        $product_image->id_image = $id_image;
        $product_image->id_side = $id_side;
        return $product_image;
    }

    public function getSideLabel()
    {
        $designer_side = new DesignerSide($this->id_side, $this->context->language->id);
        if (Validate::isLoadedObject($designer_side)) {
            return $designer_side->label;
        }
        return null;
    }

    public function hasMask()
    {
        return !empty($this->mask);
    }

    public function getImageUrl($name = 'file', $default_image = false, $encode = false)
    {
        if (!$encode) {
            return $this->getFileUri($name, $default_image);
        }
        $path = $this->getFilePath($name, $default_image);
        return DesignerTools::encodeFile($path);
    }

    public function getFileUri($name = 'file', $default_image = false)
    {
        if (!$this->getPath($name)) {
            if ($default_image) {
                return ProductImageHelper::getDefaultImage($this->id_product, $this->id_image);
            } else {
                return $this->module->provider->getPixelImage();
            }
        }
        return parent::getFileUri($name);
    }

    public function getFilePath($name = 'file', $default_image = false)
    {
        $path = $this->getPath($name);
        if (!$path) {
            if ($default_image && $name === 'canvas') {
                return ProductImageHelper::getDefaultImagePath($this->id_image);
            } else {
                return $this->module->provider->getPixelImagePath();
            }
        }
        return $path;
    }

    public function getFileUriWithHash($name = 'file', $default_image = false)
    {
        $file_uri = $this->getFileUri($name, $default_image);
        if (!$file_uri) {
            return false;
        }
        return $file_uri . '?' . $this->getHash();
    }

    public function getThumbUriWithHash($name = 'file')
    {
        return $this->getThumbUri($name) . '?' . $this->getHash();
    }

    public function getRatio()
    {
        $path = $this->getFilePath('canvas', true);
        if ($this->getType('canvas') === 'svg') {
            return SvgImageHelper::getSvgRatio($path);
        } else {
            return SvgImageHelper::getImageRatio($path);
        }
    }

    public function getSvgSize($name)
    {
        $path = $this->getFilePath($name);
        return SvgImageHelper::getSvgSize($path);
    }

    public function getCleanSvgPath($name)
    {
        $image_path = $this->getFilePath($name);
        return SvgHelper::getCleanSvgPath($image_path, $this->getHash() . '.svg');
    }

    public function setSize()
    {
        $canvas_path = $this->getFilePath('canvas', true);
        if ($this->isSvg($canvas_path)) {
            $svg_size = SvgImageHelper::getSvgSize($canvas_path);
            $width = (int)$svg_size['width'];
            $height = (int)$svg_size['height'];
        } else {
            list($width, $height) = getimagesize($canvas_path);
        }
        $this->canvas_width = $width;
        $this->canvas_height = $height;
        return array(
            'width'  => $width,
            'height' => $height
        );
    }

    private function getHash()
    {
        return md5($this->date_upd);
    }

    public function outputDimensions($name)
    {
        $canvas_width = (float)$this->canvas_width;
        $canvas_height = (float)$this->canvas_height;
        if (!$canvas_width || !$canvas_height) {
            $path = $this->getFilePath($name, true);
            list ($canvas_width, $canvas_height) = getimagesize($path);
        }
        return "width=\"{$canvas_width}\" height=\"{$canvas_height}\" data-presized onload=\"presized(this)\"";
    }

    private function isSvg($path)
    {
        return Tools::strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'svg';
    }

    public static function deleteAllByProduct($id_product)
    {
        $product_images = self::getProductImages($id_product);
        foreach ($product_images as $product_image) {
            $product_image->delete();
        }
    }
}
