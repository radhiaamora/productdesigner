<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use Db;

class DesignerProductFont extends DesignerObject
{

    public $id_product;

    public $id_font;

    public static $definition = array(
        'table' => 'productdesigner_product_font',
        'primary' => 'id_product_font',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_font' => array('type' => self::TYPE_INT)
        )
    );

    public function __construct($id_product_font = null, $id_lang = null)
    {
        parent::__construct($id_product_font, $id_lang);
    }

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerProductFont[]
     */
    public static function getProductEntries($id_product)
    {
        $product_fonts = array();
        $sql = self::getProductQuery($id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_product_font = $result[self::$definition['primary']];
                $product_fonts[$id_product_font] = new DesignerProductFont((int)$id_product_font);
            }
        }
        return $product_fonts;
    }

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerFont[]
     */
    public static function getProductFonts($id_product, $id_lang = null)
    {
        $product_fonts = array();
        $sql = self::getProductQuery($id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_font = $result['id_font'];
                $product_fonts[$id_font] = new DesignerFont((int)$id_font, $id_lang);
            }
        }
        return $product_fonts;
    }

    public static function getValuesByProduct($id_product)
    {
        $values = array();
        $product_fonts = self::getProductFonts($id_product);
        foreach ($product_fonts as $product_font) {
            $values[$product_font->id] = true;
        }
        return $values;
    }
}
