<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use Db;
use DbQuery;

class DesignerProductTab extends DesignerObject
{

    public $id_product;

    public $id_tab;

    public static $definition = array(
        'table'     => 'productdesigner_product_tab',
        'primary'   => 'id_product_tab',
        'multilang' => false,
        'fields'    => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_tab'     => array('type' => self::TYPE_INT)
        )
    );

    public function __construct($id_product_tab = null, $id_lang = null)
    {
        parent::__construct($id_product_tab, $id_lang);
    }

    /**
     * @param $id_product
     * @return DesignerProductTab[]
     */
    public static function getProductEntries($id_product)
    {
        $product_tabs = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_product = ' . (int)$id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_product_tab = $result[self::$definition['primary']];
                $product_tabs[$id_product_tab] = new DesignerProductTab((int)$id_product_tab);
            }
        }
        return $product_tabs;
    }

    /**
     * @param $id_product
     * @param null $id_lang
     */
    public static function getProductTabs($id_product)
    {
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $sql->where('id_product = ' . (int)$id_product);
        $result = Db::getInstance()->executeS($sql);
        return $result ?: array();
    }

    public static function getValuesByProduct($id_product)
    {
        $values = array();
        $product_tabs = self::getProductTabs($id_product);
        foreach ($product_tabs as $product_tab) {
            $values[$product_tab['id_tab']] = true;
        }
        return $values;
    }
}
