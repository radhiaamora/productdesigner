<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use Db;
use DbQuery;

class RealSize extends DesignerObject
{

    public $id_product;

    public $id_side;

    // props with default values
    public $x = 0;
    public $y = 0;
    public $width = 100;
    public $size = 10;

    private static $cache_sides = array();

    public static $definition = array(
        'table' => 'productdesigner_real_size',
        'primary' => 'id_real_size',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_side' => array('type' => self::TYPE_INT),
            'x' => array('type' => self::TYPE_FLOAT),
            'y' => array('type' => self::TYPE_FLOAT),
            'width' => array('type' => self::TYPE_FLOAT),
            'size' => array('type' => self::TYPE_FLOAT)
        )
    );

    public function __construct($id_real_size = null, $id_lang = null)
    {
        parent::__construct($id_real_size, $id_lang);
    }

    /**
     * @param $id_product
     * @return RealSize[]
     */
    public static function getProductRealSizes($id_product)
    {
        $areas = array();
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = '.(int)$id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_real_size = $result['id_real_size'];
                $areas[$id_real_size] = new RealSize((int)$id_real_size);
            }
        }
        return $areas;
    }

    /**
     * @param $id_product
     * @param $id_side
     * @return RealSize
     */
    public static function getSideRealSize($id_product, $id_side)
    {
        $key = "{$id_product}_{$id_side}";
        if (isset(self::$cache_sides[$key])) {
            return self::$cache_sides[$key];
        }
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = '.(int)$id_product);
        $sql->where('`id_side` = '.(int)$id_side);
        $id_real_size = Db::getInstance()->getValue($sql);
        $real_size = new RealSize((int)$id_real_size);
        $real_size->id_product = (int)$id_product;
        $real_size->id_side = (int)$id_side;
        return self::$cache_sides[$key] = $real_size;
    }

    /**
     * @param $id_product
     * @return RealSize[]
     */
    public static function getRealSizesWithDefaults($id_product)
    {
        $areas = array();
        $product_sides = DesignerProductSide::getProductSidesWithDefault($id_product);
        foreach ($product_sides as $product_side) {
            $areas[(int)$product_side->id] = RealSize::getSideRealSize($id_product, $product_side->id);
        }
        return $areas;
    }

    public function getFullWidth()
    {
        return $this->size / $this->width * 100;
    }

    public function getFullHeight($ratio)
    {
        return $this->getFullWidth() / $ratio;
    }

    public function getArea($ratio)
    {
        return $this->getFullWidth() * $this->getFullHeight($ratio) / 10000;
    }
}
