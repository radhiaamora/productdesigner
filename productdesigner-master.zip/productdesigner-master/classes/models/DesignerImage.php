<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\components\ComponentDesign;
use classes\DesignerTools;
use Configuration;
use Db;
use DbQuery;

class DesignerImage extends DesignerObject
{

    public $label;

    public $id_image_group;

    public $file;

    public $price;

    public $width;

    public $height;

    public $position;

    public $active = true;

    protected $dir = 'image';

    public static $definition = array(
        'table' => 'productdesigner_image',
        'primary' => 'id_image',
        'multilang' => true,
        'fields' => array(
            'id_image_group' => array('type' => self::TYPE_INT),
            'file' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'thumb' => array('height' => 128),
                'required' => true,
                'rename' => true,
            ),
            'price' => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'required' => true),
            'width' => array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat'),
            'height' => array('type' => self::TYPE_FLOAT, 'validate' => 'isUnsignedFloat'),
            'active' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'position' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            /* Lang fields */
            'label' => array(
                'type' => self::TYPE_STRING,
                'lang' => true,
                'validate' => 'isGenericName',
                'size' => 64,
                'required' => true
            ),
        ),
        'associations' => array(
            'image_group' => array(
                'type' => self::HAS_ONE,
                'field' => 'id_image_group',
                'object' => 'DesignerImageGroup'
            ),
        )
    );

    public function __construct($id_image = null, $id_lang = null)
    {
        parent::__construct($id_image, $id_lang);

        $this->price = (float)$this->price;
    }

    /** @noinspection PhpUnused */
    public static function getImageMarkup($file, $params)
    {
        $id_image = (int)$params['id'];
        $image = new DesignerImage($id_image);
        $ui = new ComponentDesign(DesignerTools::getModule(), DesignerTools::getContext());
        $ui->setComponents(array(
           array(
               'type' => 'img',
               'src' => $image->getThumbUri(),
               'height' => 50
           )
        ));
        return $ui->render($file);
    }

    public static function getByImageGroup($id_image_group, $id_lang = null)
    {
        $images = array();
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $sql->where('`id_image_group` = '.(int)$id_image_group);
        $sql->orderBy('position ASC');
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_image = $result['id_image'];
                $images[$id_image] = new DesignerImage((int)$id_image, $id_lang);
            }
        }
        return $images;
    }

    public static function saveFromPath($path, $id_image_group, $price)
    {
        $module = DesignerTools::getModule();

        $designer_image = new DesignerImage();

        $id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $name = pathinfo($path, PATHINFO_FILENAME);
        $designer_image->label = array($id_default_lang => $module->provider->getCleanName($name));

        $designer_image->id_image_group = (int)$id_image_group;
        $designer_image->price = (float)$price;

        $designer_image->file = basename($path);
        copy($path, $designer_image->getPathForCreation());

        $designer_image->position = $designer_image->getHighestPosition() + 1;

        $designer_image->createNewThumbnails();
        return $designer_image->save();
    }

    public function getPrice()
    {
        return (float)$this->price;
    }

    public function displayPrice($id_product)
    {
        $locale = $this->context->getCurrentLocale();
        $display_price_amount = $this->module->calculator->getDisplayPriceAmount($this->price, $id_product);
        return $locale->formatPrice($display_price_amount, $this->context->currency->iso_code);
    }
}
