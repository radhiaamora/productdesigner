<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use classes\components\ComponentDesign;
use classes\DesignerTools;
use Configuration;

class DesignerImageGroup extends DesignerObject
{

    public $label;

    public $file;

    public $position;

    public $active = true;

    public $is_white = false;

    protected $dir = 'image_group';

    public static $definition = array(
        'table' => 'productdesigner_image_group',
        'primary' => 'id_image_group',
        'multilang' => true,
        'fields' => array(
            'file' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'thumb' => array('height' => 128),
                'required' => true,
                'rename' => true,
            ),
            'active' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'is_white' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'position' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            /* Lang fields */
            'label' => array(
                'type' => self::TYPE_STRING,
                'lang' => true,
                'required' => true,
                'validate' => 'isGenericName',
                'size' => 64
            ),
        )
    );

    public static function getName($id_image_group)
    {
        $image_group = new self($id_image_group, DesignerTools::getContext()->language->id);
        return $image_group->label;
    }

    /** @noinspection PhpUnused */
    public static function getImageMarkup($file, $params)
    {
        $id_image_group = (int)$params['id'];
        $image = new self($id_image_group);
        $ui = new ComponentDesign(DesignerTools::getModule(), DesignerTools::getContext());
        $ui->setComponents(array(
            array(
                'type' => 'img',
                'src' => $image->getThumbUri(),
                'height' => 50
            )
        ));
        return $ui->render($file);
    }

    public static function saveFromPath($path)
    {
        $module = DesignerTools::getModule();

        $designer_image_group = new self();

        $id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $name = pathinfo($path, PATHINFO_FILENAME);
        $designer_image_group->label = array($id_default_lang => $module->provider->getCleanName($name));

        $designer_image_group->file = basename($path);
        copy($path, $designer_image_group->getPathForCreation());

        $designer_image_group->position = $designer_image_group->getHighestPosition() + 1;

        $designer_image_group->createNewThumbnails();
        return $designer_image_group->save();
    }
}
