<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\components\ComponentDesign;
use classes\DesignerTools;
use classes\graphics\TextRenderer;
use FontLib\Font;
use TextMeasure\TextMeasure;

class DesignerFont extends DesignerObject
{

    public $name;

    public $family;

    public $file;

    public $position;

    public $active = true;

    protected $dir = 'font';

    public static $definition = array(
        'table'     => 'productdesigner_font',
        'primary'   => 'id_font',
        'multilang' => false,
        'fields'    => array(
            'name'     => array('type' => self::TYPE_STRING, 'required' => true),
            'family'   => array('type' => self::TYPE_STRING),
            'file'     => array(
                'type'       => self::TYPE_STRING,
                'required'   => true,
                'extensions' => array('ttf', 'otf'),
                'rename'     => true,
            ),
            'active'   => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'position' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt')
        )
    );

    /** @noinspection PhpUnused */
    public static function getImageMarkup($file, $params)
    {
        $id_font = (int)$params['id'];
        $font = new self($id_font);
        $preview = $font->getFontPreviewUri('#2eacce');
        $ui = new ComponentDesign(DesignerTools::getModule(), DesignerTools::getContext());
        $ui->setComponents(array(
            array(
                'type'   => 'img',
                'src'    => $preview,
                'height' => 25
            )
        ));
        return $ui->render($file);
    }

    private function getFontPreviewPath($font_color = null)
    {
        $text = $this->name;
        $font_path = $this->getPath();
        $font_size = 40;
        $color_theme = DesignerColorTheme::getColorTheme();
        if (!$font_color) {
            $font_color = $color_theme->getTextColor($color_theme->primary_bg_color);
        }

        $font_preview_cache = $this->getCachedPreviewPath($font_color);

        if ($this->module->cache->isCacheValid($font_preview_cache)) {
            return $font_preview_cache;
        }

        $text_measure = new TextMeasure($text, $font_path, $font_size);
        $measure = $text_measure->measureText();

        $text_renderer = new TextRenderer($this->module, DesignerTools::getContext());
        $gd_image = $text_renderer->renderText($text, $font_path, $font_size, $font_color, $measure);

        $text_renderer->saveImage($gd_image, $font_preview_cache);
        return $font_preview_cache;
    }

    public function getFontPreviewUri($font_color = null)
    {
        if (!$this->getPath()) {
            return $this->module->provider->getPixelImage();
        }
        $font_preview_path = $this->getFontPreviewPath($font_color);
        return $this->module->provider->getDataDirUri('cache') . basename($font_preview_path);
    }

    private function getCachedPreviewPath($font_color)
    {
        $font_preview_cache = $this->module->cache->getCachedFilePath(
            $this->id . '-' . filemtime($this->getPath()) . md5($font_color),
            'png'
        );
        return $font_preview_cache;
    }

    public function getFontFamily()
    {
        $font = Font::load($this->getPath());
        return $font->getFontName();
    }

    public function invalidatePreview()
    {
        $color_theme = DesignerColorTheme::getColorTheme();
        $font_color = $color_theme->getTextColor($color_theme->primary_bg_color);
        $font_preview_path = $this->getCachedPreviewPath($font_color);
        if ($this->module->cache->isCacheValid($font_preview_path)) {
            unlink($font_preview_path);
        }
    }

    public function save($null_values = false, $auto_date = true)
    {
        $this->invalidatePreview();
        return parent::save($null_values, $auto_date);
    }

    public static function saveFromPath($path)
    {
        $module = DesignerTools::getModule();

        $designer_font = new DesignerFont();

        $name = pathinfo($path, PATHINFO_FILENAME);
        $designer_font->name = $module->provider->getCleanName($name);

        $designer_font->file = basename($path);
        copy($path, $designer_font->getPathForCreation());
        $designer_font->family = $designer_font->getFontFamily();

        $designer_font->position = $designer_font->getHighestPosition() + 1;

        $designer_font->save();
    }
}
