<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use Db;
use DbQuery;

class DesignerConfig extends DesignerObject
{

    public $display_base = 1;
    public $display_mask = 1;
    public $display_layers = 1;
    public $preview_in_invoice;
    public $preview_in_email;
    public $hide_cart_button;
    public $show_custom_btn = 1;
    public $show_attributes_in_tabs = 1;
    public $hide_size_input = 1;
    public $hide_style_buttons;
    public $hide_alignment;
    public $hide_outline;
    public $enable_text_precision;
    public $show_in_popup;
    public $auto_show_popup;
    public $show_dimensions;
    public $show_delete_confirmation = 1;
    public $show_download_btn;
    public $field_multiple_items = 1;
    public $min_dpi = 72;
    public $block_min_dpi = 1;
    public $upload_maxsize = 512000;

    public $enable_all_tabs = 1;
    public $initial_tab = 0;

    public static $config_cache = array();

    public static $definition = array(
        'table'     => 'productdesigner_config',
        'primary'   => 'id_config',
        'multilang' => false,
        'fields'    => array(
            'display_base'             => array('type' => self::TYPE_BOOL),
            'display_mask'             => array('type' => self::TYPE_BOOL),
            'display_layers'           => array('type' => self::TYPE_BOOL),
            'preview_in_invoice'       => array('type' => self::TYPE_BOOL),
            'preview_in_email'         => array('type' => self::TYPE_BOOL),
            'hide_cart_button'         => array('type' => self::TYPE_BOOL),
            'show_custom_btn'          => array('type' => self::TYPE_BOOL),
            'show_attributes_in_tabs'  => array('type' => self::TYPE_BOOL),
            'hide_size_input'          => array('type' => self::TYPE_BOOL),
            'hide_style_buttons'       => array('type' => self::TYPE_BOOL),
            'hide_alignment'           => array('type' => self::TYPE_BOOL),
            'hide_outline'             => array('type' => self::TYPE_BOOL),
            'enable_text_precision'    => array('type' => self::TYPE_BOOL),
            'show_in_popup'            => array('type' => self::TYPE_BOOL),
            'auto_show_popup'          => array('type' => self::TYPE_BOOL),
            'show_dimensions'          => array('type' => self::TYPE_BOOL),
            'show_delete_confirmation' => array('type' => self::TYPE_BOOL),
            'show_download_btn'        => array('type' => self::TYPE_BOOL),
            'field_multiple_items'     => array('type' => self::TYPE_BOOL),
            'min_dpi'                  => array('type' => self::TYPE_INT),
            'block_min_dpi'            => array('type' => self::TYPE_BOOL),
            'upload_maxsize'           => array('type' => self::TYPE_INT),
            'enable_all_tabs'          => array('type' => self::TYPE_BOOL),
            'initial_tab'              => array('type' => self::TYPE_INT),
        )
    );

    /**
     * @return DesignerConfig
     */
    public static function getConfig()
    {
        // TODO: simplify this method
        $id_config = 1;
        if (isset(self::$config_cache[$id_config])) {
            return self::$config_cache[$id_config];
        }
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_config` = ' . (int)$id_config);
        $id_config = (int)Db::getInstance()->getValue($sql);
        $product_config = new DesignerConfig($id_config);
        return self::$config_cache[$id_config] = $product_config;
    }

    public static function getConfigValues()
    {
        $config = self::getConfig();
        return json_decode(json_encode($config), true);
    }

    public static function getSettings()
    {
        $config = DesignerConfig::getConfig();
        return $config->getFieldsValues();
    }
}
