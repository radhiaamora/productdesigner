<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use Db;
use DbQuery;

class DesignerField extends DesignerContainer
{

    public $label;

    public $id_product;

    public $id_side;

    // props with default values
    public $x;
    public $y;
    public $width;
    public $height;

    public $is_text_field = false;
    public $is_static = false;
    public $is_limited = true;
    public $include_elements_cost = true;
    public $stretch_image = false;

    public $type;
    public $cost;

    public static $definition = array(
        'table' => 'productdesigner_design_field',
        'primary' => 'id_design_field',
        'multilang' => true,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_side' => array('type' => self::TYPE_INT),
            'x' => array('type' => self::TYPE_FLOAT),
            'y' => array('type' => self::TYPE_FLOAT),
            'width' => array('type' => self::TYPE_FLOAT),
            'height' => array('type' => self::TYPE_FLOAT),
            'is_text_field' => array('type' => self::TYPE_BOOL),
            'is_static' => array('type' => self::TYPE_BOOL),
            'is_limited' => array('type' => self::TYPE_BOOL),
            'include_elements_cost' => array('type' => self::TYPE_BOOL),
            'stretch_image' => array('type' => self::TYPE_BOOL),
            'type' => array('type' => self::TYPE_INT),
            'cost' => array('type' => self::TYPE_FLOAT),
            /* Lang fields */
            'label' => array(
                'type' => self::TYPE_STRING,
                'lang' => true,
                'required' => false,
                'validate' => 'isGenericName',
                'size' => 64
            ),
        )
    );

    /**
     * @param $id_product
     * @return DesignerField[]
     */
    public static function getProductFields($id_product, $id_lang = null)
    {
        $fields = array();
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = '.(int)$id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_design_field = $result['id_design_field'];
                $fields[$id_design_field] = new self((int)$id_design_field, $id_lang);
            }
        }
        return $fields;
    }

    /**
     * @param $id_product
     * @param $id_side
     * @return DesignerField
     */
    public static function getSideField($id_product, $id_side)
    {
        $sql = new DbQuery();
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = '.(int)$id_product);
        $sql->where('`id_side` = '.(int)$id_side);
        $id_design_field = Db::getInstance()->getValue($sql);
        $designer_field = new self((int)$id_design_field);
        $designer_field->id_product = (int)$id_product;
        $designer_field->id_side = (int)$id_side;
        return $designer_field;
    }

    public function getRatio($ratio)
    {
        if (!(float)$this->height) {
            return $ratio;
        }
        return $this->width / $this->height * $ratio;
    }
}
