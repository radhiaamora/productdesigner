<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\DesignerTools;

class DesignerFilter extends DesignerObject
{
    public $label;
    public $name;
    public $min;
    public $max;
    public $initial;
    public $color;

    public static $definition = array(
        'table'   => 'productdesigner_filter',
        'primary' => 'id_filter',
        'fields'  => array(
            'label'   => array('type' => self::TYPE_STRING),
            'name'    => array('type' => self::TYPE_STRING),
            'min'     => array('type' => self::TYPE_INT),
            'max'     => array('type' => self::TYPE_INT),
            'initial' => array('type' => self::TYPE_INT),
            'color'   => array('type' => self::TYPE_STRING),
        )
    );

    public static function getFiltersData()
    {
        $module = DesignerTools::getModule();
        $source = DesignerTools::getSource();
        return array(
            0 => array(
                'id'      => 0,
                'name'    => '',
                'label'   => $module->l('No filter', $source),
                'min'     => 0,
                'max'     => 0,
                'initial' => 0,
                'color'   => '#fff'
            ),
            1 => array(
                'id'      => 1,
                'name'    => 'grayscale',
                'label'   => $module->l('Grayscale', $source),
                'min'     => 0,
                'max'     => 0,
                'initial' => 0,
                'color'   => '#808080'
            ),
            2 => array(
                'id'      => 2,
                'name'    => 'sepia',
                'label'   => $module->l('Sepia', $source),
                'min'     => 0,
                'max'     => 0,
                'initial' => 0,
                'color'   => '#f38e2a'
            ),
            3 => array(
                'id'      => 3,
                'name'    => 'invert',
                'label'   => $module->l('Invert', $source),
                'min'     => 0,
                'max'     => 0,
                'initial' => 0,
                'color'   => '#000000'
            ),
        );
    }

    /**
     * @return DesignerFilter[] array
     */
    public static function getAll($id_lang = null, $filter = null)
    {
        $filters = array();
        $filters_data = self::getFiltersData();
        foreach ($filters_data as $image_filter) {
            $designer_filter = new self();
            $designer_filter->id = $image_filter['id'];
            $designer_filter->copyFromArray($image_filter);
            $filters[$designer_filter->id] = $designer_filter;
        }
        return $filters;
    }

    public static function getList($id_lang = null, $filter = null)
    {
        $select_list = array();
        $filters = self::getAll();
        foreach ($filters as $filter_item) {
            $id_filter = $filter_item->id;
            $select_list[$id_filter] = array(
                'id'    => $id_filter,
                'name'  => $filter_item->label,
                'value' => $id_filter,
                'color' => $filter_item->color,
            );
        }
        return $select_list;
    }
}
