<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use Db;

class DesignerProductImageGroup extends DesignerObject
{

    public $id_product;

    public $id_image_group;

    public static $definition = array(
        'table' => 'productdesigner_product_image_group',
        'primary' => 'id_product_image_group',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_image_group' => array('type' => self::TYPE_INT)
        )
    );

    public function __construct($id_product_image_group = null, $id_lang = null)
    {
        parent::__construct($id_product_image_group, $id_lang);
    }

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerProductImageGroup[]
     */
    public static function getProductEntries($id_product)
    {
        $product_image_groups = array();
        $sql = self::getProductQuery($id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_image_group = $result[self::$definition['primary']];
                $product_image_groups[$id_image_group] = new DesignerProductImageGroup((int)$id_image_group);
            }
        }
        return $product_image_groups;
    }

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerImageGroup[]
     */
    public static function getProductImageGroups($id_product, $id_lang = null)
    {
        $product_image_groups = array();
        $sql = self::getProductQuery($id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_image_group = $result['id_image_group'];
                $product_image_groups[$id_image_group] = new DesignerImageGroup((int)$id_image_group, $id_lang);
            }
        }
        return $product_image_groups;
    }

    public static function getValuesByProduct($id_product)
    {
        $values = array();
        $product_image_groups = self::getProductImageGroups($id_product);
        foreach ($product_image_groups as $product_image_group) {
            $values[$product_image_group->id] = true;
        }
        return $values;
    }
}
