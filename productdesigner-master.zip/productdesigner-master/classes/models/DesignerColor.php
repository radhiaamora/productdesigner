<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use classes\DesignerTools;

class DesignerColor extends DesignerObject
{

    public $label;

    public $color = '#FFFFFF';

    public $file;

    public $position;

    public $active = true;

    protected $dir = 'color';

    public static $definition = array(
        'table' => 'productdesigner_color',
        'primary' => 'id_color',
        'multilang' => true,
        'fields' => array(
            'color' => array('type' => self::TYPE_STRING),
            'file' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('svg', 'png', 'jpg', 'jpeg'),
                'thumb' => array('height' => 24),
                'required' => false,
                'rename' => true,
            ),
            'active' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'position' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            /* Lang fields */
            'label' => array(
                'type' => self::TYPE_STRING,
                'lang' => true,
                'required' => true,
                'validate' => 'isGenericName',
                'size' => 64
            )
        )
    );

    public static function getList($id_lang = null, $filter = null)
    {
        $module = DesignerTools::getModule();
        $list = parent::getList($id_lang, $filter);
        foreach ($list as &$color) {
            $file = $color['file'];
            $texture = $module->provider->getDataFile('color/' . $file);
            if (is_file($texture)) {
                $color['name'] = $color['label'];
                $color['color'] = array('texture' => $module->provider->getDataFileUri('color/' . $file));
            }
        }
        return $list;
    }

    public function isTexture()
    {
        return $this->getPath();
    }

    public static function isTextureStatic($id_color)
    {
        return (new self($id_color))->isTexture();
    }

    public function getTextureWidth()
    {
        list ($width) = getimagesize($this->getPath());
        return $width;
    }

    public function getTextureHeight()
    {
        list (, $height) = getimagesize($this->getPath());
        return $height;
    }

    /** @noinspection PhpUnused */
    public function getRComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['R'] / 255;
    }

    /** @noinspection PhpUnused */
    public function getGComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['G'] / 255;
    }

    /** @noinspection PhpUnused */
    public function getBComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['B'] / 255;
    }

    public function delete()
    {
        if ($this->isTexture()) {
            unlink($this->deleteFile());
        }
        parent::delete();
    }
}
