<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use Db;

class DesignerProductColor extends DesignerObject
{

    public $id_product;

    public $id_color;

    public static $definition = array(
        'table' => 'productdesigner_product_color',
        'primary' => 'id_product_color',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_color' => array('type' => self::TYPE_INT)
        )
    );

    public function __construct($id_product_color = null, $id_lang = null)
    {
        parent::__construct($id_product_color, $id_lang);
    }

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerProductColor[]
     */
    public static function getProductEntries($id_product)
    {
        $product_colors = array();
        $sql = self::getProductQuery($id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_product_color = $result[self::$definition['primary']];
                $product_colors[$id_product_color] = new DesignerProductColor((int)$id_product_color);
            }
        }
        return $product_colors;
    }

    /**
     * @param $id_product
     * @param null $id_lang
     * @return DesignerColor[]
     */
    public static function getColors($id_product, $id_lang = null)
    {
        $product_colors = array();
        $sql = self::getProductQuery($id_product);
        $results = Db::getInstance()->executeS($sql);
        if (is_array($results)) {
            foreach ($results as $result) {
                $id_color = $result['id_color'];
                $product_colors[$id_color] = new DesignerColor((int)$id_color, $id_lang);
            }
        }
        return $product_colors;
    }

    public static function getValuesByProduct($id_product)
    {
        $values = array();
        $product_colors = self::getColors($id_product);
        foreach ($product_colors as $product_color) {
            $values[$product_color->id] = true;
        }
        return $values;
    }
}
