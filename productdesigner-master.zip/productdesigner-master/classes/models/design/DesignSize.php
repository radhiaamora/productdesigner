<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\models\DesignerObject;
use Db;
use DbQuery;

class DesignSize extends DesignerObject
{
    public $id_design;
    public $width;
    public $height;

    public static $definition = array(
        'table'     => 'productdesigner_design_size',
        'primary'   => 'id_design_size',
        'multilang' => false,
        'fields'    => array(
            'id_design' => array('type' => self::TYPE_INT),
            'width'     => array('type' => self::TYPE_FLOAT),
            'height'    => array('type' => self::TYPE_FLOAT),
        )
    );

    /**
     * @param $id_design
     * @return DesignColor
     */
    public static function getByDesign($id_design)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_design = ' . (int)$id_design);
        $id_design = (int)Db::getInstance()->getValue($sql);
        return new self($id_design);
    }

    /** @noinspection PhpUnused */
    public function hasValues()
    {
        return ((float)$this->width !== (float)0) && ((float)$this->height !== (float)0);
    }

    public function getArea()
    {
        return $this->width * $this->height / 10000;
    }
}
