<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\models\DesignerArea;
use classes\models\DesignerColor;
use classes\models\DesignerContainer;
use classes\models\DesignerField;
use classes\models\DesignerObject;
use Db;
use DbQuery;

class DesignContainer extends DesignerObject
{
    public $id_design;

    public $id_container;
    public $container_type;

    public $id_side;

    /** @var DesignerContainer */
    private $container;
    /** @var DesignElement[] */
    public $design_elements;

    public static $definition = array(
        'table' => 'productdesigner_design_container',
        'primary' => 'id_design_container',
        'multilang' => false,
        'fields' => array(
            'id_design' => array('type' => self::TYPE_INT),
            'id_container' => array('type' => self::TYPE_INT),
            'container_type' => array('type' => self::TYPE_STRING),
            'id_side' => array('type' => self::TYPE_INT),
        )
    );

    public function __construct($id_design_container = null, $id_lang = null)
    {
        parent::__construct($id_design_container, $id_lang);
        $this->assignContainer();
        $this->assignDesignElements();
    }

    public static function getDesignSides($id_design)
    {
        $sides = array();
        $sql = new DbQuery();
        $sql->select('DISTINCT id_side');
        $sql->from(self::$definition['table']);
        $sql->where('`id_design` = ' . (int)$id_design);
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $sides[] = $row['id_side'];
        }
        return $sides;
    }

    /**
     * @param $id_design
     * @return DesignContainer[]
     */
    public static function getContainersByDesign($id_design)
    {
        $containers = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_design` = ' . (int)$id_design);
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $containers[] = new DesignContainer($row[self::$definition['primary']]);
        }
        return $containers;
    }

    /**
     * @param $id_design
     * @param $id_side
     * @return DesignContainer[]
     */
    public static function getContainersByDesignSide($id_design, $id_side)
    {
        $containers = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_design` = ' . (int)$id_design);
        $sql->where('`id_side` = ' . (int)$id_side);
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $containers[] = new DesignContainer($row[self::$definition['primary']]);
        }
        return $containers;
    }

    /**
     * @return DesignElement[]
     */
    public function getDesignElements()
    {
        return $this->design_elements;
    }

    /**
     * @param DesignElement[] $design_elements
     */
    public function setDesignElements($design_elements)
    {
        $this->design_elements = $design_elements;
    }

    /**
     * @return DesignerContainer
     */
    public function getContainer()
    {
        return $this->container;
    }

    /**
     * @param DesignerContainer $container
     */
    public function setContainer($container)
    {
        $this->container = $container;
    }

    public function getArea($design_area)
    {
        return $this->getContainer()->getArea($design_area);
    }

    private function assignDesignElements()
    {
        $this->setDesignElements(DesignElement::getDesignElementsByDesignContainer($this->id));
    }

    private function assignContainer()
    {
        if (!$this->getContainer()) {
            if ($this->container_type === 'field') {
                $this->setContainer(new DesignerField($this->id_container));
            }
            if ($this->container_type === 'area') {
                $this->setContainer(new DesignerArea($this->id_container));
            }
        }
    }

    public function getCost()
    {
        if ($this->container_type !== 'field') {
            return 0;
        }

        /** @var DesignerField $container */
        $container = $this->getContainer();
        return (float)$container->cost;
    }

    public function includesElementsCost()
    {
        if ($this->container_type !== 'field') {
            return true;
        }

        /** @var DesignerField $container */
        $container = $this->getContainer();
        return (int)$container->include_elements_cost;
    }

    public static function isEmpty($container)
    {
        return !(isset($container['design_elements']) && count($container['design_elements']));
    }

    private function isContainerEmpty()
    {
        return !count($this->getDesignElements());
    }

    /**
     * @param DesignContainer[] $side_containers
     */
    public static function isSideEmpty($side_containers)
    {
        foreach ($side_containers as $side_container) {
            if (!$side_container->isContainerEmpty()) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param $id_design
     * @param $id_side
     * @return DesignImage[]
     */
    public static function getAssets($id_design, $id_side)
    {
        $assets = array();
        $containers = self::getContainersByDesignSide($id_design, $id_side);
        foreach ($containers as $container) {
            $design_elements = $container->getDesignElements();
            foreach ($design_elements as $design_element) {
                if ($design_element->category === 'image') {
                    $assets[] = $design_element->getDesignItem();
                }
            }
        }
        return $assets;
    }

    /**
     * @param $id_design
     * @param $id_side
     * @return DesignerColor[]
     */
    public static function getTextures($id_design, $id_side)
    {
        $textures = array();
        $containers = self::getContainersByDesignSide($id_design, $id_side);
        foreach ($containers as $container) {
            $design_elements = $container->getDesignElements();
            foreach ($design_elements as $design_element) {
                $design_item = $design_element->getDesignItem();
                $id_color = $design_item->id_color;
                $designer_color = new DesignerColor($id_color);
                if ($designer_color->isTexture()) {
                    $textures[] = $designer_color;
                }
            }
        }
        return $textures;
    }

    public function copyFromArray($values = false)
    {
        parent::copyFromArray($values);
        $this->assignContainer();
    }

    public function delete()
    {
        $this->assignDesignElements();
        foreach ($this->design_elements as $design_element) {
            $design_element->delete();
        }
        parent::delete();
    }
}
