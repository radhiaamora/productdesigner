<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\models\DesignerFont;
use classes\models\DesignerProductPricing;
use classes\pricing\TextPricing;
use Db;
use DbQuery;
use Emoji\Emoji;

class DesignText extends DesignItem
{
    public $id_design_item;

    public $type;
    public $id_side;

    public $text;

    public $x;
    public $y;
    public $width;
    public $height;
    public $angle;

    public $svg_x;
    public $svg_y;
    public $svg_width;
    public $svg_height;
    public $text_x;
    public $text_y;

    public $transparency;
    public $curvature;

    public $id_color;
    public $color;
    public $texture;

    public $id_font;
    /** @var DesignerFont */
    public $design_font;

    public $bold;
    public $italic;
    public $underline;

    public $align;

    public $id_outline_color;
    public $outline_color;
    public $outline_width;

    public $size;

    public $path;

    public static $definition = array(
        'table'     => 'productdesigner_design_text',
        'primary'   => 'id_design_text',
        'multilang' => false,
        'fields'    => array(
            'id_design_item' => array('type' => self::TYPE_INT),

            'type' => array('type' => self::TYPE_STRING),

            'id_side' => array('type' => self::TYPE_INT),

            'x'      => array('type' => self::TYPE_FLOAT),
            'y'      => array('type' => self::TYPE_FLOAT),
            'width'  => array('type' => self::TYPE_FLOAT),
            'height' => array('type' => self::TYPE_FLOAT),
            'angle'  => array('type' => self::TYPE_FLOAT),

            'svg_x'      => array('type' => self::TYPE_FLOAT),
            'svg_y'      => array('type' => self::TYPE_FLOAT),
            'svg_width'  => array('type' => self::TYPE_FLOAT),
            'svg_height' => array('type' => self::TYPE_FLOAT),
            'text_x'     => array('type' => self::TYPE_FLOAT),
            'text_y'     => array('type' => self::TYPE_FLOAT),

            'transparency' => array('type' => self::TYPE_INT),

            'text'             => array('type' => self::TYPE_STRING),
            'id_color'         => array('type' => self::TYPE_INT),
            'color'            => array('type' => self::TYPE_STRING),
            'id_font'          => array('type' => self::TYPE_INT),
            'bold'             => array('type' => self::TYPE_BOOL),
            'italic'           => array('type' => self::TYPE_BOOL),
            'underline'        => array('type' => self::TYPE_BOOL),
            'align'            => array('type' => self::TYPE_STRING),
            'id_outline_color' => array('type' => self::TYPE_INT),
            'outline_color'    => array('type' => self::TYPE_STRING),
            'outline_width'    => array('type' => self::TYPE_INT),
            'size'             => array('type' => self::TYPE_INT),

            'curvature' => array('type' => self::TYPE_INT),
            'path'      => array('type' => self::TYPE_STRING)
        )
    );

    public function __construct($id_design_text = null, $id_lang = null)
    {
        parent::__construct($id_design_text, $id_lang);
        $this->castFields();
        $this->loadFont();
        $this->decodeText();
    }

    private function loadFont()
    {
        $this->design_font = new DesignerFont($this->id_font);
    }

    /**
     * @param $id_design_item
     * @return DesignText
     */
    public static function getByDesignElement($id_design_item)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_design_item` = ' . (int)$id_design_item);
        $id_design_text = (int)Db::getInstance()->getValue($sql);
        return new DesignText($id_design_text);
    }

    /** @noinspection PhpUnused */
    public function getLines()
    {
        return explode("\n", $this->text);
    }

    /** @noinspection PhpUnused */
    public function getSingleLine()
    {
        return str_replace(array("\r", "\n"), '', $this->text);
    }

    /** @noinspection PhpUnused */
    public function isCurved()
    {
        return (int)$this->curvature !== 0;
    }

    /** @noinspection PhpUnused */
    public function getRatio()
    {
        return $this->width / $this->height;
    }

    public function getFontFamily()
    {
        return (new DesignerFont($this->id_font))->family;
    }

    /** @noinspection PhpUnused */
    public function getTextAnchor()
    {
        $text_anchors = array(
            'left'   => 'start',
            'center' => 'middle',
            'right'  => 'end'
        );
        if ((int)$this->curvature) {
            return $text_anchors['center'];
        }
        if (!$this->align) {
            return $text_anchors['center'];
        }
        return $text_anchors[$this->align];
    }

    /** @noinspection PhpUnused */
    public function getSpanOffsetX()
    {
        $offsets = array(
            'left'   => '0%',
            'center' => '50%',
            'right'  => '100%'
        );
        if (!$this->align) {
            return $offsets['center'];
        }
        return $offsets[$this->align];
    }

    /**
     * @param DesignerProductPricing $pricing
     * @param $container_area
     * @return float
     */
    public function getPrice($pricing, $container_area)
    {
        $text_pricing = new TextPricing($this->module, $this->context);
        $text_pricing->setDesignElement($this);
        return $text_pricing->getPrice($pricing, $container_area);
    }

    /** @noinspection PhpUnused */
    public function getSvgX()
    {
        return $this->svg_x;
    }

    /** @noinspection PhpUnused */
    public function getSvgY()
    {
        return $this->svg_y;
    }

    private function decodeText()
    {
        $this->text = Emoji::Decode($this->text);
    }

    private function encodeText()
    {
        $this->text = Emoji::Encode($this->text);
    }

    public function save($null_values = false, $auto_date = true)
    {
        $this->encodeText();
        return parent::save($null_values, $auto_date);
    }
}
