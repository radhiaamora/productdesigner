<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\models\DesignerColor;
use classes\models\DesignerObject;
use classes\models\DesignerProductPricing;

abstract class DesignItem extends DesignerObject
{
    public $id_design_item;

    public $type;

    public $x;
    public $y;
    public $width;
    public $height;

    public $id_color;
    public $color;
    public $texture;

    public $transparency;

    /** @var DesignerColor */
    private $designer_color;

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
        $this->assignTexture();
    }

    protected function castFields()
    {
        $fields = static::$definition['fields'];
        foreach ($fields as $name => $field) {
            if ($field['type'] === self::TYPE_BOOL) {
                $this->{$name} = (bool)$this->{$name};
            }
        }
    }

    /** @noinspection PhpUnused */
    public function getCenterX()
    {
        return $this->x + $this->width / 2;
    }

    /** @noinspection PhpUnused */
    public function getCenterY($ratio)
    {
        return ($this->y / $ratio) + ($this->height / $ratio) / 2;
    }

    /** @noinspection PhpUnused */
    public function getOpacity()
    {
        return (100 - $this->transparency) / 100;
    }

    /**
     * @param DesignerProductPricing $pricing
     * @param $container_area
     * @return float
     */
    abstract public function getPrice($pricing, $container_area);

    public function getArea($container_area)
    {
        return ($this->width * $this->height) / (100 ** 2) * $container_area;
    }

    /**
     * @return DesignerColor
     */
    public function getColor($id_lang = null)
    {
        if ($this->designer_color && !$id_lang) {
            return $this->designer_color;
        }
        return $this->designer_color = new DesignerColor($this->id_color, $id_lang);
    }

    /** @noinspection PhpUnused */
    public function getTextureFill()
    {
        return 'url(#texture' . $this->id . ') ' . $this->color;
    }

    protected function assignTexture()
    {
        $designer_color = $this->getColor();
        if ($designer_color->isTexture()) {
            $this->texture = $designer_color->getFileUrl();
        }
    }
}
