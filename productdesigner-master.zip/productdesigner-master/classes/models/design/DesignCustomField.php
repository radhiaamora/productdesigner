<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\DesignerTools;
use classes\models\DesignerObject;
use classes\models\DesignerProductConfig;
use classes\module\Translator;
use Configuration;
use CustomizationField;
use Db;
use DbQuery;
use Language;
use Product;

class DesignCustomField extends DesignerObject
{
    public $id_product;
    public $id_customization_field;

    public static $definition = array(
        'table' => 'productdesigner_custom_field',
        'primary' => 'id_custom_field',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'id_customization_field' => array('type' => self::TYPE_INT)
        )
    );

    /**
     * @param $id_product
     * @return DesignCustomField
     */
    public static function getByProduct($id_product)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = ' . (int)$id_product);
        $id_custom_field = (int)Db::getInstance()->getValue($sql);
        $custom_field = new self($id_custom_field);
        $custom_field->id_product = (int)$id_product;
        return $custom_field;
    }

    /**
     * @param $id_product
     * @return DesignCustomField
     */
    public static function getOrCreateCustomField($id_product)
    {
        $custom_field = self::getByProduct($id_product);
        if ((int)$custom_field->id_customization_field) {
            /** @noinspection NestedPositiveIfStatementsInspection */
            if ($custom_field->checkCustomizationFieldExists()) {
                return $custom_field;
            }
        }

        $product_config = DesignerProductConfig::getByProductID($id_product);
        $customization_field = new CustomizationField();
        $customization_field->name = self::getCustomizationFieldName();
        $customization_field->id_product = (int)$id_product;
        $customization_field->type = (int)Product::CUSTOMIZE_TEXTFIELD;
        $customization_field->required = (bool)$product_config->required;
        $customization_field->is_module = true;
        $customization_field->save();

        DesignerProductConfig::makeProductCustomizable($id_product);

        $custom_field->id_customization_field = (int)$customization_field->id;
        self::reserveCustomField((int)$customization_field->id);
        $custom_field->save();

        Configuration::updateGlobalValue('PS_CUSTOMIZATION_FEATURE_ACTIVE', true);

        return $custom_field;
    }

    public static function reserveCustomField($id_customization_field)
    {
        $product_designer = DesignerTools::getModule();
        $key = "TN_CUSTOM_FIELD_$id_customization_field";
        Configuration::updateValue($key, $product_designer->id);
    }

    private static function getCustomizationFieldName()
    {
        $field_name = array();
        $module = DesignerTools::getModule();
        $context = DesignerTools::getContext();
        $translator = new Translator($module, $context);
        $languages = Language::getLanguages();
        foreach ($languages as $language) {
            $field_name[$language['id_lang']] = $translator->getTranslation(
                'Design',
                $language['iso_code']
            );
        }
        return $field_name;
    }

    public static function setFieldRequired($id_product, $value)
    {
        $custom_field = self::getOrCreateCustomField($id_product);
        $customization_field = $custom_field->getCustomizationField();
        $customization_field->required = (int)$value;
        $customization_field->save();
    }

    public function checkCustomizationFieldExists()
    {
        $customization_field = $this->getCustomizationFieldRow();
        if (!$customization_field || !is_array($customization_field)) {
            return false;
        }
        if (isset($customization_field['is_deleted']) && (int)$customization_field['is_deleted']) {
            return false;
        }
        $customization_field_lang = $this->getCustomizationFieldLangRow($this->context->language->id);
        if (!$customization_field_lang) {
            return false;
        }
        return true;
    }

    /**
     * @return CustomizationField
     */
    public function getCustomizationField()
    {
        return new CustomizationField($this->id_customization_field);
    }

    public function getCustomizationFieldRow()
    {
        $sql = new DbQuery();
        $sql->from('customization_field');
        $sql->where('id_customization_field = ' . (int)$this->id_customization_field);
        return Db::getInstance()->getRow($sql);
    }

    public function getCustomizationFieldLangRow($id_lang)
    {
        $sql = new DbQuery();
        $sql->from('customization_field_lang');
        $sql->where('id_customization_field = ' . (int)$this->id_customization_field);
        $sql->where('id_lang = ' . (int)$id_lang);
        return Db::getInstance()->getRow($sql);
    }
}
