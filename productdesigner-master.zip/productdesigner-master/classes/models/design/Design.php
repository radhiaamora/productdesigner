<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\DesignerTools;
use classes\helpers\DesignHelper;
use classes\models\DesignerColor;
use classes\models\DesignerConfig;
use classes\models\DesignerFont;
use classes\models\DesignerObject;
use classes\models\DesignerProductConfig;
use classes\models\DesignerProductImage;
use classes\models\DesignerProductSide;
use classes\models\DesignerSide;
use classes\models\layers\DesignLayer;
use classes\models\layers\Layer;
use classes\models\layers\LayerGroup;
use classes\models\RealSize;
use classes\pricing\DesignPricing;
use classes\svg\AdminSvgHelper;
use classes\svg\ClientSvgHelper;
use Configuration;
use Customization;
use Db;
use DbQuery;
use Product;
use Validate;

/** @noinspection PhpInconsistentReturnPointsInspection */

class Design extends DesignerObject
{
    public $id_cart;
    public $id_product;
    public $id_product_attribute;
    public $id_customization;
    public $quantity;

    public $id_customer;
    public $id_guest;

    public $is_initial;

    /** @var DesignContainer[] */
    public $containers;

    /** @var DesignColor */
    public $design_color;

    /** @var DesignSize */
    public $design_size;

    /** @var DesignLayer[] */
    public $design_layers;

    public static $definition = array(
        'table'     => 'productdesigner_design',
        'primary'   => 'id_design',
        'multilang' => false,
        'fields'    => array(
            'id_cart'              => array('type' => self::TYPE_INT),
            'id_product'           => array('type' => self::TYPE_INT),
            'id_product_attribute' => array('type' => self::TYPE_INT),
            'id_customization'     => array('type' => self::TYPE_INT),
            'quantity'             => array('type' => self::TYPE_INT),
            'id_customer'          => array('type' => self::TYPE_INT),
            'id_guest'             => array('type' => self::TYPE_INT),
            'is_initial'           => array('type' => self::TYPE_BOOL),
        )
    );

    public function __construct($id_design = null, $id_lang = null)
    {
        parent::__construct($id_design, $id_lang);
        $this->assignDesignSize();
        $this->assignDesignColor();
        $this->assignDesignLayers();
    }

    /**
     * @param $id_cart
     * @return Design[]
     */
    public static function getDesignsByCart($id_cart)
    {
        $designs = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_cart` = ' . (int)$id_cart);
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $designs[] = new Design($row[self::$definition['primary']]);
        }
        return $designs;
    }

    /**
     * @param $id_product
     * @return Design
     */
    public static function getInitialDesign($id_product)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`is_initial` = 1');
        $sql->where('`id_product` = ' . (int)$id_product);
        $id_design = (int)Db::getInstance()->getValue($sql, false);
        if ($id_design) {
            $design = DesignHelper::loadDesign($id_design);
            if (Validate::isLoadedObject($design)) {
                return $design;
            }
        }
        return self::loadDefaultDesign($id_product);
    }

    public static function loadDefaultDesign($id_product)
    {
        $product_config = DesignerProductConfig::getByProductID($id_product);
        $design = new Design();

        $design_color = new DesignerColor($product_config->initial_product_color);
        $design_color->id = $product_config->initial_product_color;
        /** @noinspection PhpUndefinedFieldInspection */
        $design_color->id_color = $product_config->initial_product_color;
        $design->setDesignColor($design_color);

        $design_size = new DesignSize();
        $design_size->width = $product_config->initial_width;
        $design_size->height = $product_config->initial_height;
        $design->setDesignSize($design_size);

        return $design;
    }

    public function assignContainers()
    {
        if ($this->containers !== null) {
            return $this->containers;
        }
        $containers = DesignContainer::getContainersByDesign($this->id);
        foreach ($containers as $container) {
            $this->containers[] = $container;
        }
        return $this->containers;
    }

    public function assignDesignSize()
    {
        if ($this->design_size !== null) {
            return $this->design_size;
        }
        return $this->design_size = DesignSize::getByDesign($this->id);
    }

    public function assignDesignColor()
    {
        if ($this->design_color !== null) {
            return $this->design_color;
        }
        return $this->design_color = DesignColor::getByDesign($this->id);
    }

    public function setDesignSize($design_size)
    {
        $this->design_size = $design_size;
    }

    public function setDesignColor($design_color)
    {
        $this->design_color = $design_color;
    }

    public function assignDesignLayers()
    {
        if ($this->design_layers !== null) {
            return $this->design_layers;
        }
        return $this->design_layers = DesignLayer::getByDesign($this->id);
    }

    public function setDesignLayers($layers)
    {
        $this->design_layers = $layers;
    }

    /**
     * @param $containers
     * @return bool
     */
    public static function isEmpty($containers)
    {
        $is_empty = true;
        foreach ($containers as $container) {
            if (!DesignContainer::isEmpty($container)) {
                $is_empty = false;
            }
        }
        return $is_empty;
    }

    /**
     * @return DesignPreview[]
     */
    public function getPreviews()
    {
        return DesignPreview::getDesignPreviews($this->id);
    }

    /** @noinspection PhpUnused */
    public function getEmptyPreview()
    {
        return $this->module->provider->getModuleImageUri('empty.jpg');
    }

    /**
     * @return DesignerFont[]
     */
    public function getFonts()
    {
        $design_fonts = array();
        $this->assignContainers();
        if (is_array($this->containers)) {
            foreach ($this->containers as $container) {
                $desing_elements = $container->getDesignElements();
                foreach ($desing_elements as $desing_element) {
                    if ($desing_element->category === 'text') {
                        /** @var DesignText $design_text */
                        $design_text = $desing_element->getDesignItem();
                        if (!isset($design_fonts[$design_text->id_font])) {
                            $design_font = new DesignerFont($design_text->id_font);
                            if (Validate::isLoadedObject($design_font)) {
                                $design_fonts[$design_text->id_font] = $design_font;
                            }
                        }
                    }
                }
            }
        }
        return $design_fonts;
    }

    /**
     * @param $id_side
     * @return DesignContainer[]
     */
    public function getContainersBySide($id_side)
    {
        return DesignContainer::getContainersByDesignSide($this->id, $id_side);
    }

    /**
     * @param $id_side
     * @return RealSize
     */
    public function getRealSize($id_side)
    {
        return RealSize::getSideRealSize($this->id_product, $id_side);
    }

    public function addToCart($id_customization, $id_customization_field)
    {
        $cart = $this->module->handler->getOrCreateCart();

        if (!$id_customization) {
            Db::getInstance()->insert('customization', array(
                'id_product'           => (int)$this->id_product,
                'id_product_attribute' => (int)$this->id_product_attribute,
                'id_cart'              => (int)$cart->id,
                'id_address_delivery'  => (int)$cart->id_address_delivery
            ));

            $id_customization = (int)Db::getInstance()->Insert_ID();
        }

        if (!$id_customization_field) {
            $custom_field = DesignCustomField::getOrCreateCustomField($this->id_product);
            $id_customization_field = (int)$custom_field->id_customization_field;
        }

        Db::getInstance()->insert('customized_data', array(
            'id_customization' => (int)$id_customization,
            'index'            => $id_customization_field,
            'type'             => Product::CUSTOMIZE_TEXTFIELD,
            'value'            => (int)$this->id,
            'id_module'        => (int)$this->module->id,
            'price'            => (float)$this->getPrice()
        ));

        $this->id_customization = $id_customization;
        $this->id_cart = (int)$cart->id;
        $this->save();
    }

    /**
     * @return array
     */
    public function getSvgCodes($encode = false)
    {
        $svg_helper = new ClientSvgHelper($this->module, DesignerTools::getContext());
        return $svg_helper->getSvgCodes($this, $encode);
    }

    public function saveSvg()
    {
        $svg_helper = new AdminSvgHelper($this->module, DesignerTools::getContext());
        return $svg_helper->saveSvg($this);
    }

    public function archiveSvg()
    {
        $svg_helper = new AdminSvgHelper($this->module, DesignerTools::getContext());
        return $svg_helper->archiveSvg($this);
    }

    /**
     * @param $id_side
     * @return DesignImage[]
     */
    public function getAssets($id_side)
    {
        return DesignContainer::getAssets($this->id, $id_side);
    }

    /**
     * @param $id_side
     * @return DesignerColor[]
     */
    public function getTextures($id_side)
    {
        return DesignContainer::getTextures($this->id, $id_side);
    }

    /**
     * @param $id_side
     * @return DesignerProductImage
     */
    public function getProductImage($id_side)
    {
        return DesignerProductImage::getByAttributeAndSide(
            $this->id_product,
            $this->id_product_attribute,
            $id_side
        );
    }

    /**
     * @return DesignContainer[]
     */
    public function getContainers()
    {
        return $this->containers;
    }

    /**
     * @param DesignContainer[] $containers
     */
    public function setContainers($containers)
    {
        $this->containers = $containers;
    }

    public function saveAll()
    {
        $this->save();

        foreach ($this->getContainers() as $container) {
            $container->id_design = $this->id;
            $container->save();
            foreach ($container->getDesignElements() as $design_item) {
                $design_item->id_design_container = $container->id;
                $design_item->save();
                $design_element = $design_item->getDesignItem();
                $design_element->id_design_item = $design_item->id;
                $design_element->save();
            }
        }

        $this->design_size->id_design = (int)$this->id;
        $this->design_size->save();

        $this->design_color->id_design = (int)$this->id;
        $this->design_color->save();

        foreach ($this->design_layers as $design_layer) {
            $design_layer->id_design = $this->id;
            $design_layer->save();
        }
    }

    public function getPrice()
    {
        $design_pricing = new DesignPricing($this->module, $this->context);
        $design_pricing->setDesign($this);
        return $design_pricing->getPrice();
    }

    public function getReducedPrice()
    {
        return $this->module->calculator->getDesignReducedPrice($this);
    }

    public function getArea($id_side)
    {
        $product_image = $this->getProductImage($id_side);
        return $this->getRealSize($id_side)->getArea($product_image->getRatio());
    }

    /** @noinspection PhpUnused */
    public function getDesignAdminLink()
    {
        $dsn_svg_link = $this->module->provider->getControllerAdminLink('DsnSvg');
        return DesignerTools::addQueryToUrl($dsn_svg_link, array(
            'id_design' => $this->id
        ));
    }

    public function validateCustomerPermission()
    {
        if ($this->module->provider->isAdmin()) {
            return true;
        }
        $id_customer = $this->module->provider->getCustomer();
        $id_guest = $this->module->provider->getGuest();
        if ($id_customer) {
            return (int)$this->id_customer === $id_customer;
        }
        if ($id_guest) {
            return (int)$this->id_guest === $id_guest;
        }
        return false;
    }

    public function deleteFromCart()
    {
        $id_customization = $this->id_customization;
        if ($id_customization) {
            $customization = new Customization($id_customization);
            $this->context->cart->deleteProduct(
                $customization->id_product,
                $customization->id_product_attribute,
                $customization->id,
                $customization->id_address_delivery
            );
            if (method_exists($customization, 'delete')) {
                $customization->delete();
            }
        }
    }

    public function delete()
    {
        foreach ($this->containers as $container) {
            $container->delete();
        }
        $this->design_size->delete();
        $this->design_color->delete();
        parent::delete();
    }

    public function duplicate()
    {
        $id_design_old = $this->id;
        $this->assignContainers();
        $this->assignDesignSize();
        $this->assignDesignColor();
        $this->assignDesignLayers();
        $this->add();
        $id_design_new = $this->id;
        foreach ($this->containers as $container) {
            $design_elements = $container->getDesignElements();
            $container->id_design = $id_design_new;
            $container->add();
            foreach ($design_elements as $design_element) {
                $design_item = $design_element->getDesignItem();
                $design_element->id_design_container = (int)$container->id;
                $design_element->add();
                $design_item->id_design_item = $design_element->id;
                $design_item->add();
            }
        }

        $previews = DesignPreview::getDesignPreviews($id_design_old);
        foreach ($previews as $preview) {
            $preview->id_design = $id_design_new;
            $preview->add();
        }

        $this->design_size->id_design = $id_design_new;
        $this->design_size->add();

        $this->design_color->id_design = $id_design_new;
        $this->design_color->add();
    }

    public function saveSvgCodes($encode)
    {
        $design_previews = array();
        $svg_codes = $this->getSvgCodes($encode);
        foreach ($svg_codes as $svg_code) {
            $design_preview = new DesignPreview();
            $design_preview->id_design = (int)$this->id;
            $design_preview->id_side = (int)$svg_code['id_side'];
            $design_preview->save();

            $design_preview->file = "{$design_preview->id}-{$design_preview->id_side}.svg";
            $file = $design_preview->getPathForCreation();
            $data = $svg_code['code'];
            $design_preview->code = $data;
            file_put_contents($file, $data);
            $design_preview->save();
            $design_previews[] = $design_preview;
        }
        return $design_previews;
    }

    public function getSummary()
    {
        $source = DesignerTools::getSource();
        $summary = array(
            'size'    => array(),
            'color'   => array(),
            'sides'   => array(),
            'layers'  => array(),
        );

        if ($this->design_size->hasValues()) {
            $summary['size'] = array(
                'width'  => $this->design_size->width . ' cm',
                'height' => $this->design_size->height . ' cm',
            );
        }

        if (!$this->design_color->isEmpty()) {
            if ($this->design_color->isColorized()) {
                $summary['color']['color'] = $this->design_color->getColor()->color;
            }
            if ($this->design_color->isTexture()) {
                $summary['color']['texture'] = $this->design_color->getColor()->getUrl();
            }
        }

        $id_lang = $this->context->language->id;
        $sides = DesignerProductSide::getProductSidesWithDefault($this->id_product, $id_lang);
        foreach ($sides as $side) {
            $id_side = $side->id;
            $designer_side = new DesignerSide($id_side, (int)Configuration::get('PS_LANG_DEFAULT'));
            $items_summary = array();
            $side_containers = $this->getContainersBySide($id_side);
            if (!DesignContainer::isSideEmpty($side_containers)) {
                foreach ($side_containers as $design_container) {
                    $design_elements = $design_container->getDesignElements();
                    foreach ($design_elements as $design_element) {
                        /** @var DesignText | DesignImage $design_item */
                        $design_item = $design_element->getDesignItem();
                        if ($design_element->category === 'text') {
                            $designer_font = new DesignerFont($design_item->id_font);
                            $designer_color = $design_item->getColor($id_lang);
                            $items_summary[] = array(
                                $this->module->l('Type', $source)  => $this->module->l('text', $source),
                                $this->module->l('Text', $source)  => $design_item->text,
                                $this->module->l('Font', $source)  => "{$designer_font->name} ($designer_font->family)",
                                $this->module->l('Color', $source) =>
                                    "{$designer_color->color} ({$designer_color->label})",
                            );
                        }
                        if ($design_element->category === "image") {
                            $items_summary[] = array(
                                $this->module->l('Type', $source)  => $this->module->l('image', $source),
                                $this->module->l('Label', $source) => $design_item->getImage($id_lang)->label,
                            );
                        }
                    }
                }
                $summary['sides'][$id_side] = array(
                    'name'  => $designer_side->label,
                    'items' => $items_summary
                );
            }
        }

        if (count($this->design_layers)) {
            $layers_labels = array();
            foreach ($this->design_layers as $design_layer) {
                $layer_group = new LayerGroup($design_layer->id_layer_group, $id_lang);
                $layer = new Layer($design_layer->id_layer, $id_lang);
                $layers_labels[$layer_group->label] = $layer->label;
            }
            $summary['layers'] = $layers_labels;
        }

        return $summary;
    }

    public function getCustomizationPrices()
    {
        $price_ht_nr = $this->getPrice();
        $price_ht = $this->getReducedPrice();

        $price_ttc_nr = $this->module->calculator->applyTax(
            $price_ht_nr,
            $this->id_product
        );

        $price_ttc = $this->module->calculator->applyTax(
            $price_ht,
            $this->id_product
        );

        return array(
            'price_ht'     => $price_ht,
            'price_ht_nr'  => $price_ht_nr,
            'price_ttc'    => $price_ttc,
            'price_ttc_nr' => $price_ttc_nr,
        );
    }

    public function shouldDisplayPreview($is_email)
    {
        if ($is_email) {
            return DesignerConfig::getConfig()->preview_in_email;
        }
        return true;
    }
}
