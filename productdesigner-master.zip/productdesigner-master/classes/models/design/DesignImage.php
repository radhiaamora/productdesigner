<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\DesignerTools;
use classes\helpers\SvgImageHelper;
use classes\models\DesignerColor;
use classes\models\DesignerImage;
use classes\models\DesignerProductPricing;
use classes\models\DesignerUserUpload;
use classes\pricing\ImagePricing;
use classes\svg\SvgHelper;
use Db;
use DbQuery;

class DesignImage extends DesignItem
{

    public $id_design_item;

    public $type;
    public $id_side;

    public $x;
    public $y;
    public $width;
    public $height;
    public $angle;

    public $transparency;
    public $brightness;
    public $contrast;

    public $id_color;
    public $color;
    public $texture;

    public $filter;
    public $id_filter;
    public $filter_percent;

    public $id_image;
    public $upload;

    public $svg_width;
    public $svg_height;

    public $flip_horizontal;
    public $flip_vertical;

    public $uri;

    const ORIGINAL_COLOR = -1;
    const ORIGINAL_FILTER = 0;

    public static $definition = array(
        'table'     => 'productdesigner_design_image',
        'primary'   => 'id_design_image',
        'multilang' => false,
        'fields'    => array(
            'id_design_item' => array('type' => self::TYPE_INT),

            'type' => array('type' => self::TYPE_STRING),

            'id_side' => array('type' => self::TYPE_INT),

            'x'      => array('type' => self::TYPE_FLOAT),
            'y'      => array('type' => self::TYPE_FLOAT),
            'width'  => array('type' => self::TYPE_FLOAT),
            'height' => array('type' => self::TYPE_FLOAT),
            'angle'  => array('type' => self::TYPE_FLOAT),

            'transparency' => array('type' => self::TYPE_INT),
            'brightness'   => array('type' => self::TYPE_INT),
            'contrast'     => array('type' => self::TYPE_INT),

            'id_color' => array('type' => self::TYPE_INT),
            'color'    => array('type' => self::TYPE_STRING),

            'filter'         => array('type' => self::TYPE_STRING),
            'id_filter'      => array('type' => self::TYPE_INT),
            'filter_percent' => array('type' => self::TYPE_INT),

            'id_image' => array('type' => self::TYPE_INT),
            'upload'   => array('type' => self::TYPE_BOOL),

            'svg_width'  => array('type' => self::TYPE_FLOAT),
            'svg_height' => array('type' => self::TYPE_FLOAT),

            'flip_horizontal' => array('type' => self::TYPE_BOOL),
            'flip_vertical'   => array('type' => self::TYPE_BOOL),
        )
    );

    public function __construct($id_design_image = null, $id_lang = null)
    {
        parent::__construct($id_design_image, $id_lang);
        $this->castFields();
        $this->setUri();
    }

    /**
     * @param $id_design_item
     * @return DesignImage
     */
    public static function getByDesignElement($id_design_item)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_design_item` = ' . (int)$id_design_item);
        $id_design_image = (int)Db::getInstance()->getValue($sql);
        return new DesignImage($id_design_image);
    }

    public function getUri()
    {
        $image = $this->getImage();
        return $image->getFileUri();
    }

    public function getUrl($encode = false, $name = 'file')
    {
        $image = $this->getImage();
        return $image->getUrl($encode, $name);
    }

    public function getImagePath()
    {
        $image = $this->getImage();
        return $image->getPath();
    }

    /**
     * @return DesignerImage|DesignerUserUpload
     */
    public function getImage($id_lang = null)
    {
        if (!(int)$this->upload) {
            $image = new DesignerImage($this->id_image, $id_lang);
        } else {
            $image = new DesignerUserUpload($this->id_image, $id_lang);
        }
        return $image;
    }

    /** @noinspection PhpUnused */
    public function getSvgSize()
    {
        $image = $this->getImage();
        return SvgImageHelper::getSvgSize($image->getPath());
    }

    /** @noinspection PhpUnused */
    public function getCleanSvgPath()
    {
        $image_path = $this->getImagePath();
        return SvgHelper::getCleanSvgPath($image_path);
    }

    /**
     * @param DesignerProductPricing $pricing
     * @param $container_area
     * @return float
     */
    public function getPrice($pricing, $container_area)
    {
        $image_pricing = new ImagePricing($this->module, $this->context);
        $image_pricing->setDesignElement($this);
        return $image_pricing->getPrice($pricing, $container_area);
    }

    /**
     * @param DesignerProductPricing $pricing
     */
    public function getImagePriceByArea($pricing)
    {
        if ($this->upload) {
            return (float)$pricing->upload_cost_per_area;
        }
        return (float)$this->getImage()->getPrice();
    }

    /**
     * @param DesignerProductPricing $pricing
     */
    public function getImagePrice($pricing)
    {
        if ($this->upload) {
            return (float)$pricing->upload_cost;
        }
        return (float)$this->getImage()->getPrice();
    }

    private function setUri()
    {
        $this->uri = $this->getUri();
    }

    /** @noinspection PhpUnused */
    public function isColorized()
    {
        return
            (int)$this->id_color !== self::ORIGINAL_COLOR &&
            !empty($this->color) &&
            !DesignerColor::isTextureStatic($this->id_color);
    }

    /** @noinspection PhpUnused */
    public function isTexturized()
    {
        return DesignerColor::isTextureStatic($this->id_color);
    }

    /** @noinspection PhpUnused */
    public function hasFilter()
    {
        return (int)$this->id_filter !== self::ORIGINAL_FILTER;
    }

    /** @noinspection PhpUnused */
    public function getRComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['R'] / 255;
    }

    /** @noinspection PhpUnused */
    public function getGComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['G'] / 255;
    }

    /** @noinspection PhpUnused */
    public function getBComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['B'] / 255;
    }

    /** @noinspection PhpUnused */
    public function hasBrightness()
    {
        return (float)$this->brightness !== (float)0;
    }

    /** @noinspection PhpUnused */
    public function hasContrast()
    {
        return (float)$this->contrast !== (float)0;
    }

    /** @noinspection PhpUnused */
    public function getBrightnessAmount()
    {
        return (float)$this->brightness / 100 + 1;
    }

    /** @noinspection PhpUnused */
    public function getContrastAmount()
    {
        return (float)$this->contrast / 100 + 1;
    }

    /** @noinspection PhpUnused */
    public function getContrastIntercept()
    {
        return -(0.5 * $this->getContrastAmount()) + 0.5;
    }

    /** @noinspection PhpUnused */
    public function getScaleX()
    {
        return $this->flip_horizontal ? -1 : 1;
    }

    /** @noinspection PhpUnused */
    public function getScaleY()
    {
        return $this->flip_vertical ? -1 : 1;
    }

    /** @noinspection PhpUnused */
    public function getTransformCenterX()
    {
        return $this->flip_horizontal ? $this->getCenterX() * 2 : 0;
    }

    /** @noinspection PhpUnused */
    public function getTransformCenterY($ratio)
    {
        return $this->flip_vertical ? $this->getCenterY($ratio) * 2 : 0;
    }
}
