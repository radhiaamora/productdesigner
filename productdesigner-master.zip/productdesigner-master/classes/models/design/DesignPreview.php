<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\models\DesignerObject;
use Db;
use DbQuery;

class DesignPreview extends DesignerObject
{
    public $id_design;
    public $id_side;

    public $file;
    public $preview;

    public $date_add;

    public $code;

    protected $dir = 'design_preview';

    public static $definition = array(
        'table' => 'productdesigner_design_preview',
        'primary' => 'id_design_preview',
        'multilang' => false,
        'fields' => array(
            'id_design' => array('type' => self::TYPE_INT),
            'id_side' => array('type' => self::TYPE_INT),
            'file' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('svg'),
                'rename' => true,
                'randomize' => true
            ),
            'preview' => array(
                'type' => self::TYPE_STRING,
                'extensions' => array('jpg'),
                'rename' => true,
                'randomize' => true,
                'thumb' => array('width' => 100)
            ),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDate')
        )
    );

    /**
     * @param $id_design
     * @return DesignPreview[]
     */
    public static function getDesignPreviews($id_design)
    {
        $design_previews = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_design` = ' . (int)$id_design);
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $design_previews[] = new self($row[self::$definition['primary']]);
        }
        return $design_previews;
    }
}
