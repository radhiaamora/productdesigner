<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\DesignerTools;
use classes\models\DesignerColor;
use classes\models\DesignerObject;
use Db;
use DbQuery;

class DesignColor extends DesignerObject
{
    public $id_design;
    public $id_color = -1;
    public $color;
    public $texture;

    /** @var DesignerColor */
    private $designer_color;

    public static $definition = array(
        'table'     => 'productdesigner_design_color',
        'primary'   => 'id_design_color',
        'multilang' => false,
        'fields'    => array(
            'id_design' => array('type' => self::TYPE_INT),
            'id_color'  => array('type' => self::TYPE_INT),
            'color'     => array('type' => self::TYPE_STRING),
        )
    );

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
        $this->assignTexture();
    }

    /**
     * @param $id_design
     * @return DesignColor
     */
    public static function getByDesign($id_design)
    {
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_design = ' . (int)$id_design);
        $id_design = (int)Db::getInstance()->getValue($sql);
        return new self($id_design);
    }

    public function isTexture()
    {
        if ($this->id_color) {
            $designer_color = new DesignerColor($this->id_color);
            return $designer_color->isTexture();
        }
        return false;
    }

    /** @noinspection PhpUnused */
    public function isColorized()
    {
        return $this->color && (int)$this->id_color !== -1 && !$this->isTexture();
    }

    public function isEmpty()
    {
        return !$this->isColorized() && !$this->isTexture();
    }

    /**
     * @return DesignerColor
     */
    public function getColor()
    {
        return $this->designer_color = new DesignerColor($this->id_color);
    }

    /** @noinspection PhpUnused */
    public function getRComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['R'] / 255;
    }

    /** @noinspection PhpUnused */
    public function getGComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['G'] / 255;
    }

    /** @noinspection PhpUnused */
    public function getBComponent()
    {
        $rgb = DesignerTools::hexToRgb($this->color);
        return $rgb['B'] / 255;
    }

    private function assignTexture()
    {
        $designer_color = $this->getColor();
        if ($designer_color->isTexture()) {
            $this->texture = $designer_color->getFileUrl();
        }
    }
}
