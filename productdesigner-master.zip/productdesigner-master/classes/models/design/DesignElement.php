<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models\design;

use classes\models\DesignerObject;
use classes\models\DesignerProductPricing;
use Db;
use DbQuery;

class DesignElement extends DesignerObject
{
    public $id_design_container;

    public $category;

    public $id_side;

    /** @var DesignItem */
    public $design_item;

    public static $definition = array(
        'table' => 'productdesigner_design_element',
        'primary' => 'id_design_element',
        'multilang' => false,
        'fields' => array(
            'id_design_container' => array('type' => self::TYPE_INT),
            'category' => array('type' => self::TYPE_STRING),
            'id_side' => array('type' => self::TYPE_INT)
        )
    );

    public function __construct($id_design_element = null, $id_lang = null)
    {
        parent::__construct($id_design_element, $id_lang);
        $this->assignDesignItem();
    }

    public static function getDesignElementsByDesignContainer($id_design_container)
    {
        $design_elements = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_design_container` = ' . (int)$id_design_container);
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $design_elements[] = new DesignElement($row[self::$definition['primary']]);
        }
        return $design_elements;
    }

    /**
     * @return DesignItem
     */
    public function getDesignItem()
    {
        return $this->design_item;
    }

    /**
     * @param DesignElement $design_item
     */
    public function setDesignItem($design_item)
    {
        $this->design_item = $design_item;
    }

    /**
     * @param DesignerProductPricing $pricing
     * @param $container_area
     * @return float
     */
    public function getPrice($pricing, $container_area)
    {
        return $this->getDesignItem()->getPrice($pricing, $container_area);
    }

    private function assignDesignItem()
    {
        if ($this->category === 'text') {
            $this->setDesignItem(DesignText::getByDesignElement($this->id));
        }
        if ($this->category === 'image') {
            $this->setDesignItem(DesignImage::getByDesignElement($this->id));
        }
    }

    public function delete()
    {
        $this->assignDesignItem();
        $this->design_item->delete();
        parent::delete();
    }
}
