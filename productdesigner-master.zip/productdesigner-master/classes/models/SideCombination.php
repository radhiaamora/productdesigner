<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\DesignerTools;
use Db;
use DbQuery;

class SideCombination extends DesignerObject
{

    public $id_product;
    public $cost;

    public $sides;
    /** @var SideCombinationItem[] */
    public $items;

    public static $definition = array(
        'table'     => 'productdesigner_side_combination',
        'primary'   => 'id_side_combination',
        'multilang' => false,
        'fields'    => array(
            'id_product' => array('type' => self::TYPE_INT),
            'cost'       => array('type' => self::TYPE_FLOAT),
        )
    );

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
        $this->setSides($id_lang);
    }

    /**
     * @param $id_product
     * @return SideCombination[]
     */
    public static function getByProduct($id_product, $id_lang)
    {
        $combinations = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_product = ' . (int)$id_product);
        $db = Db::getInstance();
        $result = $db->executeS($sql, false);
        while ($row = $db->nextRow($result)) {
            $id_side_combination = (int)$row['id_side_combination'];
            $combinations[] = new self($id_side_combination, $id_lang);
        }
        return $combinations;
    }

    public function setSides($id_lang)
    {
        $result = array();
        $sides = DesignerProductSide::getProductSides($this->id_product, $id_lang);
        $items = SideCombinationItem::getByCombination($this->id);
        foreach ($sides as $side) {
            $result[] = array(
                'id_side'  => $side->id,
                'name'     => $side->name,
                'selected' => isset($items[$side->id])
            );
        }
        $this->sides = $result;
        $this->items = $items;
    }

    public function deleteItems()
    {
        return SideCombinationItem::deleteByCombination($this->id);
    }

    /**
     * @param $id_product
     * @param $sides
     * @return SideCombination
     */
    public static function getCombinationWithSides($id_product, $sides)
    {
        $id_side_combination = 0;
        $prefix = _DB_PREFIX_ . DesignerTools::getModuleName();
        $sql = 'SELECT ci.`id_side_combination`, count(ci.`id_side`) as sides FROM `' . $prefix . '_side_combination` sc
                JOIN `' . $prefix . '_side_combination_item` ci
                ON ci.`id_side_combination` = sc.`id_side_combination`
                WHERE ci.`id_side` IN (' . pSQL(implode(',', $sides)) . ')
                AND sc.`id_product` = ' . (int)$id_product . '
                GROUP BY sc.`id_side_combination`';
        $result = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($result)) {
            $id = $row['id_side_combination'];
            $side_combination = new SideCombination($id);
            if (count($side_combination->items) === count($sides)) {
                $id_side_combination = $id;
            }
        }
        return new self($id_side_combination);
    }
}
