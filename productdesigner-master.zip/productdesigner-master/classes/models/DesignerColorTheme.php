<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use classes\DesignerTools;
use Configuration;
use Db;
use DbQuery;

class DesignerColorTheme extends DesignerObject
{

    public $primary_color;
    public $secondary_color;
    public $primary_bg_color;
    public $secondary_bg_color;

    const HASH = 'fbc3e476961b985ecc55b7c49f55ee48';

    public static $color_theme_cache = array();

    public static $definition = array(
        'table' => 'productdesigner_color_theme',
        'primary' => 'id_color_theme',
        'multilang' => false,
        'fields' => array(
            'primary_color' => array('type' => self::TYPE_STRING),
            'secondary_color' => array('type' => self::TYPE_STRING),
            'primary_bg_color' => array('type' => self::TYPE_STRING),
            'secondary_bg_color' => array('type' => self::TYPE_STRING)
        )
    );

    /**
     * @return DesignerColorTheme
     */
    public static function getColorTheme()
    {
        $id_color_theme = 1;
        if (isset(self::$color_theme_cache[$id_color_theme])) {
            return self::$color_theme_cache[$id_color_theme];
        }
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        /** @noinspection UnnecessaryCastingInspection */
        $sql->where('`id_color_theme` = ' . (int)$id_color_theme);
        $id_color_theme = (int)Db::getInstance()->getValue($sql);
        $product_color_theme = new DesignerColorTheme($id_color_theme);
        return self::$color_theme_cache[$id_color_theme] = $product_color_theme;
    }

    public static function getColorThemeValues()
    {
        $product_color_theme = self::getColorTheme();
        $values = json_decode(json_encode($product_color_theme), true);
        $result = array();
        foreach ($values as $key => $value) {
            if (isset(self::$definition['fields'][$key])) {
                $result[$key] = $value;
            }
        }
        return $result;
    }

    public static function getName($variables_hash)
    {
        return 'color_theme' . self::HASH . '_' . $variables_hash . '.css';
    }

    public static function deleteOldFile($current_filename)
    {
        $module = DesignerTools::getModule();
        $filename = Configuration::get(self::getConfigName());
        if ($filename === $current_filename) {
            return false;
        }
        $target_file = $module->provider->getModuleFile('views/css/front/' . $filename);
        if (is_file($target_file)) {
            return unlink($target_file);
        }
        return true;
    }

    public static function saveNewFile($filename)
    {
        Configuration::updateGlobalValue(self::getConfigName(), $filename);
    }

    private static function getConfigName()
    {
        return DesignerTools::getModuleName() . '_theme_color_file';
    }

    public function getTextColor($color)
    {
        $rgb = DesignerTools::hexToRgb($color);
        return $rgb['R'] + $rgb['G'] + $rgb['B'] < 400 ? '#fff' : '#000';
    }

    public function reset()
    {
        $this->delete();
        $this->module->handler->execSQLCode('INSERT INTO `__PREFIX_color_theme` (`id_color_theme`) VALUES (1);');
    }
}
