<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

use Db;
use DbQuery;

class DesignerProductConfig extends DesignerObject
{

    public $id_product;

    public $active;
    public $required;

    public $tabs_use_global_config = 1;
    public $enable_all_tabs = 1;
    public $initial_tab = 0;

    public $enable_all_text_colors = 1;
    public $enable_all_image_colors = 1;
    public $enable_all_image_filters = 1;
    public $enable_all_product_colors = 1;

    public $enable_all_fonts = 1;
    public $enable_all_image_groups = 1;
    public $small_image_groups = 0;

    public $enable_text_colorpickers = 1;
    public $enable_text_transparency = 1;
    public $enable_text_curvature = 1;

    public $text_maxlength;
    public $text_default_align;

    public $enable_image_colors;
    public $enable_image_colorpickers;
    public $enable_image_transparency = 1;
    public $enable_image_brightness = 0;
    public $enable_image_contrast = 0;
    public $enable_image_flip = 0;
    public $initial_image_color = -1;

    public $enable_image_filters;

    public $enable_product_colors;
    public $enable_product_colorpickers = 1;
    public $initial_product_color = -1;

    public $allow_upload = 1;

    public $enable_design_fields;

    public $enable_layers;

    public $single_color;
    public $enable_resize_image = 1;
    public $enable_drag_image = 1;
    public $enable_resize_text = 1;
    public $enable_drag_text = 1;
    public $min_text_size;
    public $min_image_size;

    public $enable_product_size;
    public $allow_change_product_size_aspect = 1;
    public $product_size_aspect_locked_default = 1;
    public $initial_width;
    public $initial_height;
    public $min_width;
    public $min_height;
    public $max_width;
    public $max_height;

    public static $config_cache = array();
    public static $values_cache = array();

    public static $definition = array(
        'table'     => 'productdesigner_product_config',
        'primary'   => 'id_product_config',
        'multilang' => false,
        'fields'    => array(
            'id_product' => array('type' => self::TYPE_INT),

            'active'   => array('type' => self::TYPE_BOOL),
            'required' => array('type' => self::TYPE_BOOL),

            'tabs_use_global_config' => array('type' => self::TYPE_BOOL),
            'enable_all_tabs'        => array('type' => self::TYPE_BOOL),
            'initial_tab'            => array('type' => self::TYPE_INT),

            'enable_all_text_colors'    => array('type' => self::TYPE_BOOL),
            'enable_all_image_colors'   => array('type' => self::TYPE_BOOL),
            'enable_all_image_filters'  => array('type' => self::TYPE_BOOL),
            'enable_all_product_colors' => array('type' => self::TYPE_BOOL),

            'enable_all_fonts'        => array('type' => self::TYPE_BOOL),
            'enable_all_image_groups' => array('type' => self::TYPE_BOOL),

            'small_image_groups' => array('type' => self::TYPE_BOOL),

            'enable_text_colorpickers' => array('type' => self::TYPE_BOOL),
            'enable_text_transparency' => array('type' => self::TYPE_BOOL),
            'enable_text_curvature'    => array('type' => self::TYPE_BOOL),
            'text_maxlength'           => array('type' => self::TYPE_INT, 'allow_null' => true),
            'text_default_align'       => array('type' => self::TYPE_STRING),

            'enable_image_colors'       => array('type' => self::TYPE_BOOL),
            'enable_image_colorpickers' => array('type' => self::TYPE_BOOL),
            'enable_image_transparency' => array('type' => self::TYPE_BOOL),
            'enable_image_brightness'   => array('type' => self::TYPE_BOOL),
            'enable_image_contrast'     => array('type' => self::TYPE_BOOL),
            'enable_image_flip'         => array('type' => self::TYPE_BOOL),
            'initial_image_color'       => array('type' => self::TYPE_INT),

            'enable_image_filters' => array('type' => self::TYPE_BOOL),

            'enable_product_colors'       => array('type' => self::TYPE_BOOL),
            'enable_product_colorpickers' => array('type' => self::TYPE_BOOL),
            'initial_product_color'       => array('type' => self::TYPE_INT),

            'allow_upload' => array('type' => self::TYPE_BOOL),

            'enable_design_fields' => array('type' => self::TYPE_BOOL),

            'enable_layers' => array('type' => self::TYPE_BOOL),

            'single_color'        => array('type' => self::TYPE_BOOL),
            'enable_resize_image' => array('type' => self::TYPE_BOOL),
            'enable_drag_image'   => array('type' => self::TYPE_BOOL),
            'enable_resize_text'  => array('type' => self::TYPE_BOOL),
            'enable_drag_text'    => array('type' => self::TYPE_BOOL),
            'min_text_size'       => array('type' => self::TYPE_FLOAT),
            'min_image_size'      => array('type' => self::TYPE_FLOAT),

            'enable_product_size'                => array('type' => self::TYPE_BOOL),
            'allow_change_product_size_aspect'   => array('type' => self::TYPE_BOOL),
            'product_size_aspect_locked_default' => array('type' => self::TYPE_BOOL),
            'initial_width'                      => array('type' => self::TYPE_FLOAT),
            'initial_height'                     => array('type' => self::TYPE_FLOAT),
            'min_width'                          => array('type' => self::TYPE_FLOAT),
            'min_height'                         => array('type' => self::TYPE_FLOAT),
            'max_width'                          => array('type' => self::TYPE_FLOAT),
            'max_height'                         => array('type' => self::TYPE_FLOAT),
        )
    );

    /**
     * @param $id_product
     * @return DesignerProductConfig
     */
    public static function getByProductID($id_product)
    {
        if (isset(self::$config_cache[$id_product])) {
            return self::$config_cache[$id_product];
        }
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('`id_product` = ' . (int)$id_product);
        $id_product_config = (int)Db::getInstance()->getValue($sql);
        $product_config = new self($id_product_config);
        $product_config->id_product = (int)$id_product;
        return self::$config_cache[$id_product] = $product_config;
    }

    public static function getProductValues($id_product)
    {
        if (isset(self::$values_cache[$id_product])) {
            return self::$values_cache[$id_product];
        }
        $product_config = self::getByProductID($id_product);
        return self::$values_cache[$id_product] = json_decode(json_encode($product_config), true);
    }

    public static function isActive($id_product)
    {
        return self::getByProductID($id_product)->active;
    }

    public static function shouldHideCartButton($id_product)
    {
        $config = DesignerConfig::getConfig();
        $product_config = self::getByProductID($id_product);
        return $product_config->required && $config->hide_cart_button;
    }

    public static function makeProductCustomizable($id_product)
    {
        Db::getInstance()->update(
            'product',
            array('customizable' => 1),
            'id_product = ' . (int)$id_product
        );

        Db::getInstance()->update(
            'product_shop',
            array('customizable' => 1),
            'id_product = ' . (int)$id_product
        );
    }

    public static function getEnabledProducts()
    {
        $enabled_products = array();
        $sql = new DbQuery();
        $sql->select('id_product');
        $sql->from(self::$definition['table']);
        $sql->where('active = 1');
        $rows = Db::getInstance()->executeS($sql, false);
        while ($row = Db::getInstance()->nextRow($rows)) {
            $enabled_products[(int)$row['id_product']] = true;
        }
        return $enabled_products;
    }

    public static function getSettings($id_product)
    {
        $product_config = self::getByProductID($id_product);
        return $product_config->getFieldsValues();
    }

    public static function deleteByProduct($id_target_product)
    {
        $product_config = self::getByProductID($id_target_product);
        $product_config->delete();
    }

    /** @noinspection PhpUnused */
    public function canSetMaxWidth()
    {
        return (float)$this->max_width > (float)$this->min_width;
    }

    /** @noinspection PhpUnused */
    public function canSetMaxHeight()
    {
        return (float)$this->max_height > (float)$this->min_height;
    }
}
