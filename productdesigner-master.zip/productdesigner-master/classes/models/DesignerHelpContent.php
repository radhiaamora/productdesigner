<?php
/**
 * 2010-2014 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to tunisoft.solutions@gmail.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft <tunisoft.solutions@gmail.com>
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\models;

class DesignerHelpContent extends DesignerObject
{

    public $image_upload_help;
    public $text_help;

    public static $definition = array(
        'table'     => 'productdesigner_help_content',
        'primary'   => 'id_help_content',
        'forced_id' => 1,
        'multilang' => true,
        'fields'    => array(
            /* Lang fields */
            'image_upload_help' => array(
                'type' => self::TYPE_HTML,
                'lang' => true,
            ),
            'text_help'         => array(
                'type' => self::TYPE_HTML,
                'lang' => true,
            ),
        )
    );

    public function __construct($id = 1, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
    }

    public static function getHelpContent($id_lang = null)
    {
        return new self(1, $id_lang);
    }

    public static function getContentValues()
    {
        $help_content = self::getHelpContent();
        return self::getValues($help_content);
    }
}
