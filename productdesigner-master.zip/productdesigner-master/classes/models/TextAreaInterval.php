<?php
/**
* 2010-2014 Tuni-Soft
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* It is available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to tunisoft.solutions@gmail.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize the module for your
* needs please refer to
* http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
* for more information.
*
* @author    Tunis-Soft <tunisoft.solutions@gmail.com>
* @copyright 2010-2020 Tuni-Soft
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

namespace classes\models;

use Db;
use DbQuery;

class TextAreaInterval extends DesignerObject
{

    public $id_product;

    public $from;
    public $to;
    public $cost;

    public static $definition = array(
        'table' => 'productdesigner_text_area_interval',
        'primary' => 'id_text_area_interval',
        'multilang' => false,
        'fields' => array(
            'id_product' => array('type' => self::TYPE_INT),
            'from' => array('type' => self::TYPE_FLOAT),
            'to' => array('type' => self::TYPE_FLOAT),
            'cost' => array('type' => self::TYPE_FLOAT),
        )
    );

    /**
     * @param $id_product
     * @return TextAreaInterval[]
     */
    public static function getProductIntervals($id_product)
    {
        $rows = array();
        $sql = new DbQuery();
        $sql->select(self::$definition['primary']);
        $sql->from(self::$definition['table']);
        $sql->where('id_product = ' . (int)$id_product);
        $results = Db::getInstance()->executeS($sql);
        if (\is_array($results)) {
            foreach ($results as $result) {
                $id = $result[self::$definition['primary']];
                $rows[$id] = new TextAreaInterval((int)$id);
            }
        }
        return $rows;
    }
}
