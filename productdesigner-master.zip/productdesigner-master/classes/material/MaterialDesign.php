<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\material;

use Context;
use interfaces\DesignerUI;
use ProductDesigner;

class MaterialDesign implements DesignerUI
{
    /** @var ProductDesigner $module */
    public $module = null;
    /** @var Context $context */
    public $context;

    private $components = array();
    private $values = array();

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @return array
     */
    public function getComponents()
    {
        return $this->components;
    }

    /**
     * @param array $components
     */
    public function setComponents($components)
    {
        $this->components = $components;
    }

    /**
     * @return array
     */
    public function getValues()
    {
        return $this->values;
    }

    /**
     * @param array $values
     */
    public function setValues($values)
    {
        $this->values = $values;
    }

    public function render()
    {
        $template_path = $this->module->getDir() . 'views/templates/api/material/material.tpl';
        $this->context->smarty->assign(array(
            'module_dir' => $this->module->provider->getModuleDirUri(),
            'components' => $this->getComponents(),
            'values' => $this->getValues()
        ));
        $output = $this->context->smarty->fetch($template_path);
        return $this->injectTabsContent($output);
    }

    private function injectTabsContent($output)
    {
        if (strpos($output, '<tab_content') === -1) {
            return $output;
        }
        $components = $this->getComponents();
        if (!isset($components['tabs'])) {
            return $output;
        }
        $tabs = $components['tabs']['tabs'];
        foreach ($tabs as $tab_name => $tab) {
            $output = str_replace("<tab_content name=\"$tab_name\"/>", $tab['content'], $output);
        }
        return $output;
    }
}
