<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\svg;

use classes\DesignerTools;
use classes\helpers\EmojiHelper;
use classes\helpers\ProductSizeHelper;
use classes\models\design\Design;
use classes\models\design\DesignContainer;
use classes\models\DesignerConfig;
use classes\models\DesignerProductSide;
use Context;
use DOMDocument;
use ProductDesigner;
use Tools;

abstract class SvgHelper
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    /**
     * @param Design $design
     */
    public function getSvgCodes($design, $encode = false)
    {
        $svg_codes = array();
        $id_lang = $this->context->language->id;
        $size_helper = new ProductSizeHelper($this->module, $this->context);
        $sides = DesignerProductSide::getProductSidesWithDefault($design->id_product, $id_lang);
        $has_product_color = !$design->design_color->isEmpty();
        $has_product_size = $design->design_size->hasValues();
        foreach ($sides as $side) {
            $id_side = (int)$side->id;
            $product_image = $design->getProductImage($id_side);
            $ratio = $product_image->getRatio();
            $side_containers = $design->getContainersBySide($id_side);
            $is_design_empty = DesignContainer::isSideEmpty($side_containers) &&
                !count($design->design_layers) &&
                !$has_product_color &&
                !$has_product_size;
            if (!$is_design_empty) {
                $real_size = $design->getRealSize($id_side);
                $full_size = $size_helper->getFullSize($design->id_product, $design, $real_size, $ratio);
                $svg_codes[] = array(
                    'id_design' => $design->id,
                    'id_side'   => $id_side,
                    'code'      => $this->fetchSvgCode(array(
                        'design'        => $design,
                        'encode'        => $encode,
                        'id_side'       => $id_side,
                        'product_image' => $product_image,
                        'ratio'         => $ratio,
                        'full_size'     => $full_size,
                        'containers'    => $side_containers,
                        'real_size'     => $real_size,
                        'dsn_config'    => DesignerConfig::getConfig(),
                    )),
                    'size'      => array(
                        'width'  => $full_size['width'],
                        'height' => $full_size['height']
                    )
                );
            }
        }
        return $svg_codes;
    }

    abstract protected function fetchSvgCode($variables);

    protected function includeCleanSVGs($svg_code)
    {
        preg_match_all("/<clean-svg\s+path=\"(.*?)\"\s*\/>/", $svg_code, $matches);
        if (is_array($matches) && count($matches) === 2) {
            list($lines, $paths) = $matches;
            foreach ($lines as $index => $line) {
                $path = $paths[$index];
                $svg_code = str_replace($line, $this->getCleanSvgContent($path), $svg_code);
            }
        }
        return $svg_code;
    }

    public static function getCleanSvgPath($image_path, $dest = false)
    {
        $module = DesignerTools::getModule();
        $dest_path = $module->provider->getDataDir('svg') . ($dest ?: basename($image_path));
        if (is_file($dest_path)) {
            return $dest_path;
        }

        $t_xml = new DOMDocument();
        $t_xml->load($image_path);
        $document = self::cleanSVGDimensions($t_xml);
        $xml_out = $t_xml->saveXML($document);
        file_put_contents($dest_path, $xml_out);
        return $dest_path;
    }

    private function getCleanSvgContent($path)
    {
        return Tools::file_get_contents($path);
    }

    /**
     * @param DOMDocument $t_xml
     * @return mixed
     */
    private static function cleanSVGDimensions($t_xml)
    {
        $document = $t_xml->documentElement;
        $width = $document->getAttribute('width');
        if ($width) {
            $document->setAttribute('width', preg_replace('/[^0-9,.]/', '', $width));
        }

        $height = $document->getAttribute('height');
        if ($height) {
            $document->setAttribute('height', preg_replace('/[^0-9,.]/', '', $height));
        }
        return $document;
    }
}
