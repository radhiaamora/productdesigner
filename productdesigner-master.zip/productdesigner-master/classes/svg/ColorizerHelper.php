<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\svg;

use classes\helpers\SvgImageHelper;
use classes\models\DesignerColor;

class ColorizerHelper extends SvgHelper
{
    public function colorize($image_path, $id_color, $save_path)
    {

        $designer_color = new DesignerColor($id_color);
        $variables = array(
            'image_path'     => $image_path,
            'type'           => SvgImageHelper::getType($image_path),
            'size'           => SvgImageHelper::getSize($image_path),
            'designer_color' => $designer_color,
        );
        $svg_code = $this->fetchSvgCode($variables);
        file_put_contents($save_path, $svg_code);
        return $save_path;
    }

    protected function fetchSvgCode($variables = array())
    {
        $template_path = $this->module->getDir() . 'views/templates/api/svg/colorizer/colorizer.tpl';
        $this->context->smarty->assign($variables);
        $svg_code = $this->context->smarty->fetch($template_path);
        $svg_code = $this->includeCleanSVGs($svg_code);
        return $svg_code;
    }
}
