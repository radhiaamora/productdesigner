<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\svg;

use classes\models\design\Design;
use classes\models\layers\Layer;
use ExtendedZip\ExtendedZip;
use Order;
use Tools;
use Validate;
use ZipArchive;

class AdminSvgHelper extends SvgHelper
{
    /**
     * @param Design $design
     */
    public function archiveSvg($design)
    {
        $svg_info = $this->saveSvg($design);
        $svg_dir = $svg_info['output_dir'];
        $svg_dir_name = basename($svg_dir);
        $output_dir = $this->module->provider->getDataDir('output');
        $order = Order::getByCartId($design->id_cart);
        $id_order = Validate::isLoadedObject($order) ? $order->id : 0;
        $zip_path = $output_dir . $id_order . '_' . md5($svg_dir_name) . '.zip';
        if (is_file($zip_path)) {
            unlink($zip_path);
        }
        ExtendedZip::zipTree($svg_dir, $zip_path, $svg_dir_name, ZipArchive::CREATE);
        return $zip_path;
    }

    /**
     * @param Design $design
     */
    public function saveSvg($design)
    {
        $output_dir = $this->getOutputFolder($design->id);
        $svg_info = array(
            'output_dir' => $output_dir,
            'svg_files' => array(

            )
        );

        if (is_dir($output_dir)) {
            Tools::deleteDirectory($output_dir, false);
        }
        $fonts_dir = $this->getFontsFolder($output_dir);
        $this->createFolder($fonts_dir);

        $svg_codes = $this->getSvgCodes($design);
        foreach ($svg_codes as $svg_code) {
            $id_side = $svg_code['id_side'];

            $side_dir = $this->getSideFolder($id_side, $output_dir);
            $files_dir = $this->getFilesDir($side_dir);
            $this->createFolder($files_dir);

            $svg_path = $this->getSvgPath($design->id, $id_side, $side_dir);
            $this->saveSvgCode($svg_path, $svg_code['code']);
            $svg_info['svg_files'][] = $svg_path;

            $this->copyAssets($design, $id_side, $files_dir);
            $this->copyProductImages($design, $id_side, $files_dir);
            $this->copyLayersImages($design, $id_side, $files_dir);

            $textures_dir = $this->getTexturesDir($side_dir);
            $this->createFolder($textures_dir);
            $this->copyTextures($design, $id_side, $textures_dir);
        }

        $this->copyFonts($design, $fonts_dir);

        return $svg_info;
    }

    protected function fetchSvgCode($variables = array())
    {
        $template_path = $this->module->getDir() . 'views/templates/api/svg/admin_svg_code.tpl';
        $this->context->smarty->assign($variables);
        $svg_code = $this->context->smarty->fetch($template_path);
        $svg_code = $this->includeCleanSVGs($svg_code);
        return $svg_code;
    }

    private function getOutputFolder($id_design)
    {
        $data_dir = $this->module->provider->getDataDir('output');
        return "{$data_dir}{$id_design}-design{$id_design}/";
    }

    private function getSideFolder($id_side, $output_dir)
    {
        return "{$output_dir}{$id_side}-side{$id_side}/";
    }

    private function getFontsFolder($output_dir)
    {
        return "{$output_dir}fonts/";
    }

    private function getFilesDir($side_dir)
    {
        return $side_dir . 'files/';
    }

    private function getTexturesDir($side_dir)
    {
        return $side_dir . 'textures/';
    }

    private function getSvgPath($id_design, $id_side, $side_dir)
    {
        return "{$side_dir}design-$id_design-$id_side.svg";
    }

    private function createFolder($files_dir)
    {
        if (!is_dir($files_dir)) {
            /** @noinspection MkdirRaceConditionInspection */
            mkdir($files_dir, 0777, true);
        }
    }

    private function saveSvgCode($svg_path, $code)
    {
        file_put_contents($svg_path, $code);
    }

    /**
     * @param Design $design
     * @param $id_side
     * @param $files_dir
     */
    private function copyAssets($design, $id_side, $files_dir)
    {
        $assets = $design->getAssets($id_side);
        foreach ($assets as $asset) {
            $asset_path = $asset->getImagePath();
            copy($asset_path, $files_dir . basename($asset_path));
        }
    }

    /**
     * @param Design $design
     * @param $id_side
     * @param $texture_dir
     */
    private function copyTextures($design, $id_side, $texture_dir)
    {
        $textures = $design->getTextures($id_side);
        if ($design->design_color->isTexture()) {
            $textures[] = $design->design_color->getColor();
        }
        foreach ($textures as $texture) {
            $asset_path = $texture->getPath();
            copy($asset_path, $texture_dir . basename($asset_path));
        }
    }

    /**
     * @param Design $design
     * @param $id_side
     * @param $files_dir
     */
    private function copyFonts($design, $dir)
    {
        $fonts = $design->getFonts();
        foreach ($fonts as $font) {
            $font_path = $font->getPath();
            copy($font_path, $dir . basename($font_path));
        }
    }

    /**
     * @param Design $design
     * @param $id_side
     * @param $files_dir
     */
    private function copyProductImages($design, $id_side, $files_dir)
    {
        $product_image = $design->getProductImage($id_side);

        $canvas_path = $product_image->getFilePath('canvas', true);
        copy($canvas_path, $files_dir . basename($canvas_path));

        $mask_path = $product_image->getFilePath('mask');
        copy($mask_path, $files_dir . basename($mask_path));
    }

    /**
     * @param Design $design
     * @param $id_side
     * @param $files_dir
     */
    private function copyLayersImages($design, $id_side, $files_dir)
    {
        foreach ($design->design_layers as $design_layer) {
            $layer = new Layer($design_layer->id_layer);
            $layer_image = $layer->getLayerImage($id_side);
            $image_path = $layer_image->getPath('image');
            if ($image_path) {
                copy($image_path, $files_dir . basename($image_path));
            }
        }
    }
}
