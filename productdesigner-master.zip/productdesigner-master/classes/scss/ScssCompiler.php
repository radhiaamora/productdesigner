<?php
/**
 * 2010-2020 Tuni-Soft
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize the module for your
 * needs please refer to
 * http://doc.prestashop.com/display/PS15/Overriding+default+behaviors
 * for more information.
 *
 * @author    Tunis-Soft
 * @copyright 2010-2020 Tuni-Soft
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

namespace classes\scss;

use classes\DesignerTools;
use classes\models\DesignerColorTheme;
use Context;
use Leafo\ScssPhp\Compiler;
use ProductDesigner;
use Tools;

class ScssCompiler
{
    /** @var ProductDesigner $module */
    public $module;
    /** @var Context $context */
    public $context;

    public function __construct($module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function compileColorTheme($refresh = false, $variables = null, $return_string = false)
    {
        if (!$variables) {
            $variables = DesignerColorTheme::getColorThemeValues();
        }
        $hash = md5(json_encode($variables));

        $filename = DesignerColorTheme::getName($hash);
        $target_file = $this->module->provider->getModuleFile('views/css/front/' . $filename);
        $target_uri = $this->module->provider->getModuleDirUri('views/css/front') . $filename;

        $source_file = 'views/css/front/color_theme.scss';

        if (DesignerTools::isModuleDevMode()) {
            $refresh = true;
            $source_file = 'views/scss/front/color_theme.scss';
        }

        if (!$return_string) {
            if (!$refresh && Tools::file_exists_cache($target_file)) {
                return $target_uri;
            }
        }

        $scss = new Compiler();
        $scss->setVariables($variables);

        $code = Tools::file_get_contents($this->module->provider->getModuleFile($source_file));

        $css = $scss->compile($code);

        if ($return_string) {
            return $css;
        }

        file_put_contents($target_file, $css);
        DesignerColorTheme::deleteOldFile($filename);
        DesignerColorTheme::saveNewFile($filename);
        return $target_uri;
    }
}
